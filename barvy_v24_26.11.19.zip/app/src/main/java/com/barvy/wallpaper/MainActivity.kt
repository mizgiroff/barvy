package com.barvy.wallpaper

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

private val UkraineBlue = Color(0xFF0057B7)
private val UkraineGold = Color(0xFFFFD700)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val repo = WallpaperRepository(applicationContext)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = UkraineBlue,
                    secondary = UkraineGold,
                    background = Color(0xFFF6F8FB)
                )
            ) {
                BarvyScreen(repo)
            }
        }
    }
}

@Composable
fun BarvyScreen(repo: WallpaperRepository) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val catalog = remember { repo.loadCatalog() }
    val cities = remember(catalog) { listOf("Все") + catalog.map { it.city }.distinct() }

    var status by remember { mutableStateOf(repo.getStatus()) }
    var selectedCity by remember { mutableStateOf("Все") }
    var busyItemId by remember { mutableStateOf<Int?>(null) }
    var isCheckingLocation by remember { mutableStateOf(false) }

    val bgPermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ ->
        repo.setAutoEnabled(true)
        WallpaperWorker.schedulePeriodic(context)
        status = repo.getStatus()
    }

    val fgPermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        val granted = perms[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            perms[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (granted) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val hasBg = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.ACCESS_BACKGROUND_LOCATION
                ) == PackageManager.PERMISSION_GRANTED
                if (!hasBg) {
                    bgPermLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
                    return@rememberLauncherForActivityResult
                }
            }
            repo.setAutoEnabled(true)
            WallpaperWorker.schedulePeriodic(context)
            status = repo.getStatus()
        } else {
            repo.recordCheckMessage("Для автосмены нужно разрешение на геолокацию")
            status = repo.getStatus()
        }
    }

    val filteredItems = remember(catalog, selectedCity) {
        if (selectedCity == "Все") catalog else catalog.filter { it.city == selectedCity }
    }

    Scaffold { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(14.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(UkraineBlue)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Box(
                        modifier = Modifier
                            .size(14.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(UkraineGold)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Барви • Львов и область",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Автосмена (радиус 1 км)",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "Только экран блокировки • v24_26.11.19",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.Gray
                                )
                            }
                            Switch(
                                checked = status.autoEnabled,
                                onCheckedChange = { enable ->
                                    if (enable) {
                                        fgPermLauncher.launch(
                                            arrayOf(
                                                Manifest.permission.ACCESS_FINE_LOCATION,
                                                Manifest.permission.ACCESS_COARSE_LOCATION
                                            )
                                        )
                                    } else {
                                        repo.setAutoEnabled(false)
                                        WallpaperWorker.cancelPeriodic(context)
                                        status = repo.getStatus()
                                    }
                                }
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = status.lastMessage,
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            text = "Последняя проверка: ${status.lastCheckedTime}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray
                        )

                        if (status.lastAppliedFileId.isNotEmpty()) {
                            val cachedFile = repo.getCachedFile(status.lastAppliedFileId)
                            if (cachedFile.exists()) {
                                val bmp = remember(status.lastAppliedFileId) {
                                    BitmapFactory.decodeFile(cachedFile.absolutePath)
                                }
                                if (bmp != null) {
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Image(
                                        bitmap = bmp.asImageBitmap(),
                                        contentDescription = status.lastAppliedDesc,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(180.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = {
                                if (isCheckingLocation) return@Button
                                val hasPerm = ContextCompat.checkSelfPermission(
                                    context,
                                    Manifest.permission.ACCESS_FINE_LOCATION
                                ) == PackageManager.PERMISSION_GRANTED ||
                                    ContextCompat.checkSelfPermission(
                                        context,
                                        Manifest.permission.ACCESS_COARSE_LOCATION
                                    ) == PackageManager.PERMISSION_GRANTED
                                if (!hasPerm) {
                                    fgPermLauncher.launch(
                                        arrayOf(
                                            Manifest.permission.ACCESS_FINE_LOCATION,
                                            Manifest.permission.ACCESS_COARSE_LOCATION
                                        )
                                    )
                                    return@Button
                                }
                                isCheckingLocation = true
                                scope.launch {
                                    withContext(Dispatchers.IO) {
                                        val loc = WallpaperWorker.getBestLocation(context)
                                        if (loc == null) {
                                            repo.recordCheckMessage("Не удалось определить GPS-координаты")
                                        } else {
                                            val match = GeoMatcher.findNearestWithinRadius(
                                                lat = loc.latitude,
                                                lon = loc.longitude,
                                                catalog = catalog,
                                                radiusMeters = GeoMatcher.DEFAULT_RADIUS_METERS,
                                                lastAppliedId = status.lastAppliedId.takeIf { it > 0 }
                                            )
                                            if (match == null) {
                                                val nearest = GeoMatcher.findNearestAny(loc.latitude, loc.longitude, catalog)
                                                val msg = if (nearest != null) {
                                                    val km = String.format("%.1f", nearest.distanceMeters / 1000.0)
                                                    "В радиусе 1 км объектов нет. Ближайший: ${nearest.item.city} ($km км)"
                                                } else {
                                                    "Объекты не найдены"
                                                }
                                                repo.recordCheckMessage(msg)
                                            } else {
                                                val ok = repo.applyLockScreenWallpaper(
                                                    match.item,
                                                    match.distanceMeters.roundToInt()
                                                )
                                                if (!ok) {
                                                    repo.recordCheckMessage("Не удалось скачать заставку для ${match.item.city}")
                                                }
                                            }
                                        }
                                    }
                                    status = repo.getStatus()
                                    isCheckingLocation = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = UkraineBlue),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            if (isCheckingLocation) {
                                CircularProgressIndicator(
                                    color = Color.White,
                                    modifier = Modifier.size(18.dp),
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                            }
                            Text("Проверить геолокацию сейчас")
                        }
                    }
                }
            }

            item {
                Text(
                    text = "Каталог (${filteredItems.size} из ${catalog.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    cities.forEach { city ->
                        FilterChip(
                            selected = selectedCity == city,
                            onClick = { selectedCity = city },
                            label = { Text(city) }
                        )
                    }
                }
            }

            items(filteredItems, key = { it.id }) { item ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "${item.city} • №${item.id}",
                            style = MaterialTheme.typography.labelLarge,
                            color = UkraineBlue,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = item.description,
                            style = MaterialTheme.typography.bodyMedium,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "GPS: ${item.lat}, ${item.lon}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = {
                                if (busyItemId != null) return@OutlinedButton
                                busyItemId = item.id
                                scope.launch {
                                    val ok = withContext(Dispatchers.IO) {
                                        repo.applyLockScreenWallpaper(item, 0)
                                    }
                                    if (!ok) {
                                        repo.recordCheckMessage("Ошибка скачивания: ${item.filename}")
                                    }
                                    status = repo.getStatus()
                                    busyItemId = null
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            if (busyItemId == item.id) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                            }
                            Text("Поставить на экран блокировки")
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(16.dp)) }
        }
    }
}
