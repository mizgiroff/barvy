package com.barvy.wallpaper

import org.json.JSONArray
import org.json.JSONObject

data class WallpaperItem(
    val id: Int,
    val city: String,
    val description: String,
    val fileId: String,
    val filename: String,
    val lat: Double,
    val lon: Double,
    val cityEn: String = city,
    val descriptionEn: String = description,
    val oblast: String = "Львівська область",
    val oblastEn: String = "Lviv Oblast",
    val countryCode: String = "UA",
    val country: String = "Україна",
    val countryEn: String = "Ukraine",
    val region: String = oblast,
    val regionEn: String = oblastEn,
    val imageUrl: String = ""
) {
    fun cityFor(lang: AppLang): String = if (lang == AppLang.UK || lang == AppLang.RU) city else cityEn

    fun descriptionFor(lang: AppLang): String = if (lang == AppLang.UK || lang == AppLang.RU) description else descriptionEn

    fun oblastFor(lang: AppLang): String = if (lang == AppLang.UK || lang == AppLang.RU) region else regionEn

    fun regionFor(lang: AppLang): String = oblastFor(lang)

    fun downloadUrls(): List<String> {
        val list = mutableListOf<String>()
        if (imageUrl.isNotBlank()) list.add(imageUrl)
        if (fileId.isNotBlank()) {
            list.add("https://drive.google.com/uc?export=download&id=$fileId")
            list.add("https://lh3.googleusercontent.com/d/$fileId=w1440")
        }
        return list
    }

    fun primaryDownloadUrl(): String = downloadUrls().firstOrNull() ?: ""

    fun fallbackDownloadUrl(): String = downloadUrls().getOrElse(1) { primaryDownloadUrl() }

    fun toJsonObject(): JSONObject = JSONObject().apply {
        put("id", id)
        put("countryCode", countryCode)
        put("country", country)
        put("countryEn", countryEn)
        put("region", region)
        put("regionEn", regionEn)
        put("oblast", region)
        put("oblastEn", regionEn)
        put("city", city)
        put("cityEn", cityEn)
        put("description", description)
        put("descriptionEn", descriptionEn)
        put("lat", lat)
        put("lon", lon)
        put("filename", filename)
        put("fileId", fileId)
        put("imageUrl", imageUrl)
    }

    companion object {
        fun parseJson(jsonText: String): List<WallpaperItem> {
            val array = JSONArray(jsonText)
            val result = ArrayList<WallpaperItem>(array.length())
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val cityUk = obj.getString("city")
                val descUk = obj.getString("description")
                val regUk = obj.optString("region", "").ifBlank {
                    obj.optString("oblast", "Львівська область")
                }
                val regEn = obj.optString("regionEn", "").ifBlank {
                    obj.optString("oblastEn", "Lviv Oblast")
                }
                result.add(
                    WallpaperItem(
                        id = obj.getInt("id"),
                        city = cityUk,
                        description = descUk,
                        fileId = obj.optString("fileId", ""),
                        filename = obj.getString("filename"),
                        lat = obj.getDouble("lat"),
                        lon = obj.getDouble("lon"),
                        cityEn = obj.optString("cityEn", cityUk),
                        descriptionEn = obj.optString("descriptionEn", descUk),
                        oblast = regUk,
                        oblastEn = regEn,
                        countryCode = obj.optString("countryCode", "UA"),
                        country = obj.optString("country", "Україна"),
                        countryEn = obj.optString("countryEn", "Ukraine"),
                        region = regUk,
                        regionEn = regEn,
                        imageUrl = obj.optString("imageUrl", "")
                    )
                )
            }
            return result
        }
    }
}
