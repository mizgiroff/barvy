package com.medassist.app.sync

import com.medassist.app.util.AppLogger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

class HomeAssistantClient {
    private val client = OkHttpClient()
    private val jsonMedia = "application/json; charset=utf-8".toMediaType()

    suspend fun pushSensor(
        baseUrl: String,
        token: String,
        entityId: String,
        state: String,
        unit: String
    ): Boolean = withContext(Dispatchers.IO) {
        if (baseUrl.isBlank() || token.isBlank()) {
            AppLogger.log("HA", "URL или токен не заданы")
            return@withContext false
        }
        val cleanUrl = baseUrl.trimEnd('/')
        val bodyJson = JSONObject().apply {
            put("state", state)
            put("attributes", JSONObject().apply {
                put("unit_of_measurement", unit)
                put("source", "MedAssist")
            })
        }
        val request = Request.Builder()
            .url("$cleanUrl/api/states/$entityId")
            .addHeader("Authorization", "Bearer $token")
            .post(bodyJson.toString().toRequestBody(jsonMedia))
            .build()

        return@withContext try {
            client.newCall(request).execute().use { resp ->
                val ok = resp.isSuccessful
                AppLogger.log("HA", "POST $entityId=$state -> HTTP ${resp.code}")
                ok
            }
        } catch (e: Exception) {
            AppLogger.log("HA", "Ошибка отправки: ${e.message}")
            false
        }
    }
}
