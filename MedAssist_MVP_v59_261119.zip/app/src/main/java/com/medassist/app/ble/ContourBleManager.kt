package com.medassist.app.ble

import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCharacteristic
import android.content.Context
import android.os.Handler
import android.os.Looper
import com.medassist.app.util.AppLogger
import no.nordicsemi.android.ble.BleManager
import no.nordicsemi.android.ble.observer.ConnectionObserver
import java.util.Calendar
import java.util.UUID
import kotlin.math.pow
import kotlin.math.roundToInt

object BpDedupCache {
    private const val PREF = "medassist_bp_dedup"
    private const val KEY_MAP = "seen_48h"
    private const val TTL_MS = 48 * 60 * 60_000L

    @Synchronized
    fun isSeen(context: Context, dateKey: String, sys: Double, dia: Double, pulse: Int?): Boolean {
        val prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val token = "${sys.toInt()}/${dia.toInt()}/${pulse ?: -1}"
        val raw = prefs.getString(KEY_MAP, "") ?: ""
        return raw.split(";").any { entry ->
            val parts = entry.split("@")
            parts.size == 2 && parts[0] == token && (now - (parts[1].toLongOrNull() ?: 0L)) < TTL_MS
        }
    }

    @Synchronized
    fun markSeen(context: Context, dateKey: String, sys: Double, dia: Double, pulse: Int?) {
        val prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val token = "${sys.toInt()}/${dia.toInt()}/${pulse ?: -1}"
        val raw = prefs.getString(KEY_MAP, "") ?: ""
        val kept = raw.split(";").mapNotNull { entry ->
            val parts = entry.split("@")
            if (parts.size == 2 && parts[0] != token && (now - (parts[1].toLongOrNull() ?: 0L)) < TTL_MS) entry else null
        }.toMutableList()
        kept.add("$token@$now")
        prefs.edit().putString(KEY_MAP, kept.takeLast(30).joinToString(";")).apply()
    }
}

enum class BleDeviceRole(val label: String) {
    GLUCOSE("Глюкометр"),
    BP("Тонометр"),
    SCALE("Весы")
}

class ContourBleManager(
    context: Context,
    private val onGlucoseRead: (mmolPerL: Double, timestampMs: Long) -> Unit,
    private val onBpRead: (sys: Double, dia: Double, pulse: Int?, timestampMs: Long) -> Unit,
    private val onWeightRead: (kg: Double) -> Unit,
    private val onDisconnected: ((BleDeviceRole, Boolean) -> Unit)? = null
) : BleManager(context) {

    companion object {
        val GLUCOSE_SERVICE_UUID: UUID = UUID.fromString("00001808-0000-1000-8000-00805f9b34fb")
        val GLUCOSE_MEASUREMENT_CHAR: UUID = UUID.fromString("00002a18-0000-1000-8000-00805f9b34fb")
        val RACP_CHAR: UUID = UUID.fromString("00002a52-0000-1000-8000-00805f9b34fb")

        val BP_SERVICE_UUID: UUID = UUID.fromString("00001810-0000-1000-8000-00805f9b34fb")
        val BP_MEASUREMENT_CHAR: UUID = UUID.fromString("00002a35-0000-1000-8000-00805f9b34fb")

        val WEIGHT_SERVICE_UUID: UUID = UUID.fromString("0000181d-0000-1000-8000-00805f9b34fb")
        val WEIGHT_MEASUREMENT_CHAR: UUID = UUID.fromString("00002a9d-0000-1000-8000-00805f9b34fb")
    }

    private var currentRole = BleDeviceRole.GLUCOSE
    private var dataReceivedInSession = false
    private var glucoseChar: BluetoothGattCharacteristic? = null
    private var racpChar: BluetoothGattCharacteristic? = null
    private var bpChar: BluetoothGattCharacteristic? = null
    private var weightChar: BluetoothGattCharacteristic? = null

    private data class PendingBp(val sys: Double, val dia: Double, val pulse: Int?, val tsMs: Long, val hasValidTime: Boolean)
    private val pendingBpList = mutableListOf<PendingBp>()
    private var pendingWeightKg: Double? = null
    private val bpHandler = Handler(Looper.getMainLooper())
    private fun flushPendingBp() {
        if (pendingBpList.isEmpty()) return
        val items = pendingBpList.toList()
        pendingBpList.clear()
        val allSameBurstTime = items.isNotEmpty() && items.all { kotlin.math.abs(it.tsMs - items.last().tsMs) < 2 * 60_000L }
        val toEmit = if (items.size > 1 && (items.none { it.hasValidTime } || allSameBurstTime)) {
            AppLogger.log("BLE", "Очередь АД (${items.size} шт в одном сеансе): беру только последний")
            listOf(items.last())
        } else {
            items
        }
        toEmit.forEach { bp -> onBpRead(bp.sys, bp.dia, bp.pulse, bp.tsMs) }
    }
    private val bpDisconnectRunnable = Runnable {
        flushPendingBp()
        AppLogger.log("BLE", "Очередь АД принята, отключаюсь")
        disconnect().enqueue()
    }
    private val weightCommitRunnable = Runnable {
        pendingWeightKg?.let { kg ->
            pendingWeightKg = null
            dataReceivedInSession = true
            AppLogger.log("BLE", "Вес зафиксирован: $kg кг")
            onWeightRead(kg)
        }
        disconnect().enqueue()
    }

    init {
        setConnectionObserver(object : ConnectionObserver {
            override fun onDeviceConnecting(device: BluetoothDevice) {
                dataReceivedInSession = false
            }
            override fun onDeviceConnected(device: BluetoothDevice) {
                dataReceivedInSession = false
            }
            override fun onDeviceFailedToConnect(device: BluetoothDevice, reason: Int) {
                bpHandler.removeCallbacks(bpDisconnectRunnable); flushPendingBp(); bpHandler.removeCallbacks(weightCommitRunnable); pendingWeightKg = null
                val hadData = dataReceivedInSession
                dataReceivedInSession = false
                onDisconnected?.invoke(currentRole, hadData)
            }
            override fun onDeviceReady(device: BluetoothDevice) {}
            override fun onDeviceDisconnecting(device: BluetoothDevice) {}
            override fun onDeviceDisconnected(device: BluetoothDevice, reason: Int) {
                bpHandler.removeCallbacks(bpDisconnectRunnable); flushPendingBp(); bpHandler.removeCallbacks(weightCommitRunnable); pendingWeightKg = null
                val hadData = dataReceivedInSession
                dataReceivedInSession = false
                onDisconnected?.invoke(currentRole, hadData)
            }
        })
    }

    override fun getGattCallback(): BleManagerGattCallback = object : BleManagerGattCallback() {
        override fun isRequiredServiceSupported(gatt: BluetoothGatt): Boolean {
            val serviceList = gatt.services.joinToString { it.uuid.toString().substring(4, 8) }
            AppLogger.log("BLE", "Сервисы (${currentRole.label}): [$serviceList]")
            glucoseChar = null; racpChar = null; bpChar = null; weightChar = null

            return when (currentRole) {
                BleDeviceRole.GLUCOSE -> {
                    val s = gatt.getService(GLUCOSE_SERVICE_UUID) ?: return false
                    glucoseChar = s.getCharacteristic(GLUCOSE_MEASUREMENT_CHAR)
                    racpChar = s.getCharacteristic(RACP_CHAR)
                    glucoseChar != null && racpChar != null
                }
                BleDeviceRole.BP -> {
                    val s = gatt.getService(BP_SERVICE_UUID)
                    if (s == null) {
                        AppLogger.log("BLE", "Профиль 0x1810 не найден (возможно закрытый протокол Omron)")
                        return false
                    }
                    bpChar = s.getCharacteristic(BP_MEASUREMENT_CHAR)
                    bpChar != null
                }
                BleDeviceRole.SCALE -> {
                    val s = gatt.getService(WEIGHT_SERVICE_UUID) ?: return false
                    weightChar = s.getCharacteristic(WEIGHT_MEASUREMENT_CHAR)
                    weightChar != null
                }
            }
        }

        override fun initialize() {
            when (currentRole) {
                BleDeviceRole.GLUCOSE -> {
                    setNotificationCallback(glucoseChar).with { _, data ->
                        data.value?.let { parseGlucoseMeasurement(it) }
                    }
                    enableNotifications(glucoseChar).enqueue()
                    setIndicationCallback(racpChar).with { _, data ->
                        AppLogger.log("BLE", "RACP: ${data.value?.joinToString(" ") { "%02X".format(it) }}")
                        disconnect().enqueue()
                    }
                    enableIndications(racpChar).enqueue()
                    writeCharacteristic(racpChar, byteArrayOf(0x01, 0x06), BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT)
                        .done { AppLogger.log("BLE", "Запрос сахара RACP отправлен") }
                        .fail { _, status -> AppLogger.log("BLE", "Ошибка RACP: $status") }
                        .enqueue()
                }
                BleDeviceRole.BP -> {
                    setIndicationCallback(bpChar).with { _, data ->
                        data.value?.let { parseBpMeasurement(it) }
                        bpHandler.removeCallbacks(bpDisconnectRunnable); bpHandler.removeCallbacks(weightCommitRunnable); pendingWeightKg = null
                        bpHandler.postDelayed(bpDisconnectRunnable, 3000L)
                    }
                    enableIndications(bpChar).enqueue()
                    AppLogger.log("BLE", "Ожидаю всю очередь тонометра 0x2A35...")
                }
                BleDeviceRole.SCALE -> {
                    setIndicationCallback(weightChar).with { _, data ->
                        data.value?.let { parseWeightMeasurement(it) }
                    }
                    enableIndications(weightChar).enqueue()
                    setNotificationCallback(weightChar).with { _, data ->
                        data.value?.let { parseWeightMeasurement(it) }
                    }
                    enableNotifications(weightChar).enqueue()
                    AppLogger.log("BLE", "Ожидаю стабилизацию веса 0x2A9D...")
                }
            }
        }

        override fun onServicesInvalidated() {
            bpHandler.removeCallbacks(bpDisconnectRunnable); bpHandler.removeCallbacks(weightCommitRunnable); pendingWeightKg = null
            glucoseChar = null; racpChar = null; bpChar = null; weightChar = null
        }
    }

    private fun parseGlucoseMeasurement(bytes: ByteArray) {
        if (bytes.size < 12) return
        val flags = bytes[0].toInt() and 0xFF
        val timeOffsetPresent = (flags and 0x01) != 0
        val concentrationPresent = (flags and 0x02) != 0
        val unitIsMolPerL = (flags and 0x04) != 0
        if (!concentrationPresent) return
        var tsMs = System.currentTimeMillis()
        if (bytes.size >= 10) {
            val year = (bytes[3].toInt() and 0xFF) or ((bytes[4].toInt() and 0xFF) shl 8)
            val month = bytes[5].toInt() and 0xFF
            val day = bytes[6].toInt() and 0xFF
            val hour = bytes[7].toInt() and 0xFF
            val min = bytes[8].toInt() and 0xFF
            val sec = bytes[9].toInt() and 0xFF
            var timeOffsetMin = 0
            if (timeOffsetPresent && bytes.size >= 12) {
                val rawOff = (bytes[10].toInt() and 0xFF) or ((bytes[11].toInt() and 0xFF) shl 8)
                timeOffsetMin = if (rawOff >= 0x8000) rawOff - 0x10000 else rawOff
            }
            if (year in 2020..2100 && month in 1..12 && day in 1..31) {
                val cal = Calendar.getInstance().apply {
                    set(year, month - 1, day, hour, min, sec)
                    set(Calendar.MILLISECOND, 0)
                    if (timeOffsetMin != 0) add(Calendar.MINUTE, timeOffsetMin)
                }
                tsMs = cal.timeInMillis
            }
        }
        var offset = 1 + 2 + 7
        if (timeOffsetPresent) offset += 2
        if (bytes.size < offset + 2) return
        val rawSfloat = (bytes[offset].toInt() and 0xFF) or ((bytes[offset + 1].toInt() and 0xFF) shl 8)
        val value = decodeSfloat(rawSfloat)
        val mmol = if (unitIsMolPerL) value * 1000.0 else value / 18.0182
        val rounded = kotlin.math.round(mmol * 10.0) / 10.0
        dataReceivedInSession = true
        AppLogger.log("BLE", "Сахар получен: $rounded ммоль/л")
        onGlucoseRead(rounded, tsMs)
    }

    private fun parseBpMeasurement(bytes: ByteArray) {
        if (bytes.size < 7) return
        val flags = bytes[0].toInt() and 0xFF
        val isKpa = (flags and 0x01) != 0
        val hasTime = (flags and 0x02) != 0
        val hasPulse = (flags and 0x04) != 0
        val factor = if (isKpa) 7.50062 else 1.0
        val sys = decodeSfloat((bytes[1].toInt() and 0xFF) or ((bytes[2].toInt() and 0xFF) shl 8)) * factor
        val dia = decodeSfloat((bytes[3].toInt() and 0xFF) or ((bytes[4].toInt() and 0xFF) shl 8)) * factor
        var offset = 7
        var hasValidTime = false
        var tsMs = System.currentTimeMillis()
        if (hasTime && bytes.size >= offset + 7) {
            val year = (bytes[offset].toInt() and 0xFF) or ((bytes[offset + 1].toInt() and 0xFF) shl 8)
            val month = bytes[offset + 2].toInt() and 0xFF
            val day = bytes[offset + 3].toInt() and 0xFF
            val hour = bytes[offset + 4].toInt() and 0xFF
            val minute = bytes[offset + 5].toInt() and 0xFF
            val second = bytes[offset + 6].toInt() and 0xFF
            if (year in 2020..2099 && month in 1..12 && day in 1..31 && hour in 0..23 && minute in 0..59 && second in 0..59) {
                val cal = Calendar.getInstance().apply {
                    set(year, month - 1, day, hour, minute, second)
                    set(Calendar.MILLISECOND, 0)
                }
                tsMs = cal.timeInMillis
                hasValidTime = true
            }
            offset += 7
        }
        var pulse: Int? = null
        if (hasPulse && bytes.size >= offset + 2) {
            pulse = decodeSfloat((bytes[offset].toInt() and 0xFF) or ((bytes[offset + 1].toInt() and 0xFF) shl 8)).roundToInt()
        }
        dataReceivedInSession = true
        AppLogger.log("BLE", "АД получено: ${sys.roundToInt()}/${dia.roundToInt()}-${pulse ?: 0} (hasTime=$hasValidTime)")
        pendingBpList.add(PendingBp(sys.roundToInt().toDouble(), dia.roundToInt().toDouble(), pulse, tsMs, hasValidTime))
    }

    private fun parseWeightMeasurement(bytes: ByteArray) {
        if (bytes.size < 3) return
        val flags = bytes[0].toInt() and 0xFF
        val isImperial = (flags and 0x01) != 0
        val rawWeight = (bytes[1].toInt() and 0xFF) or ((bytes[2].toInt() and 0xFF) shl 8)
        val kg = if (isImperial) (rawWeight * 0.01) * 0.453592 else rawWeight * 0.005
        val rounded = (kg * 10.0).roundToInt() / 10.0
        if (rounded > 10.0) {
            pendingWeightKg = rounded
            bpHandler.removeCallbacks(weightCommitRunnable)
            bpHandler.postDelayed(weightCommitRunnable, 2000L)
        }
    }

    private fun decodeSfloat(raw: Int): Double {
        var mantissa = raw and 0x0FFF
        if (mantissa >= 0x0800) mantissa -= 0x1000
        var exponent = (raw shr 12) and 0x0F
        if (exponent >= 0x08) exponent -= 0x10
        return mantissa * 10.0.pow(exponent.toDouble())
    }

    fun connectAuto(device: BluetoothDevice, role: BleDeviceRole) {
        currentRole = role
        connect(device).useAutoConnect(true).enqueue()
    }

    fun connectMeter(device: BluetoothDevice, role: BleDeviceRole) {
        currentRole = role
        AppLogger.log("BLE", "Подключаюсь (${role.label}) к ${device.address}...")
        connect(device)
            .useAutoConnect(false)
            .timeout(12000)
            .retry(2, 500)
            .done { AppLogger.log("BLE", "GATT подключен (${role.label})") }
            .fail { _, status -> AppLogger.log("BLE", "Сбой GATT (${role.label}): код $status") }
            .enqueue()
    }
}
