package com.medassist.app.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.BaselineShift
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.medassist.app.R
import com.medassist.app.ble.BleDeviceRole
import com.medassist.app.service.MedReminderReceiver
import com.medassist.app.data.*
import com.medassist.app.sync.FoodAnalysis
import com.medassist.app.sync.PlateAnalysis
import com.medassist.app.util.*
import com.medassist.app.weather.WeatherForecastDay
import java.io.ByteArrayOutputStream
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

data class ScannedBleDevice(val name: String, val address: String, val rssi: Int)
data class PinnedBleDevice(val role: BleDeviceRole, val name: String, val address: String)

val LocalLargeUi = compositionLocalOf { false }

private val ColorHigh = Color(0xFFD32F2F)

private fun pluralIntake(n: Int): String {
    val mod100 = n % 100
    val mod10 = n % 10
    return when {
        mod100 in 11..14 -> "$n приёмов"
        mod10 == 1 -> "$n приём"
        mod10 in 2..4 -> "$n приёма"
        else -> "$n приёмов"
    }
}

private fun stripMealPrefix(note: String): String {
    var clean = note.trim()
    listOf("Завтрак:", "Обед:", "Ужин:", "Перекус:").forEach { pfx ->
        if (clean.startsWith(pfx, ignoreCase = true)) clean = clean.removeRange(0, pfx.length).trim()
    }
    return clean
}
private val ColorLow = Color(0xFF1565C0)

private fun shortSourceLabel(src: DataSource): String = when (src) {
    DataSource.BLE_CONTOUR, DataSource.BLE_SCALE, DataSource.BLE_BP -> "BLE"
    DataSource.HEALTH_CONNECT -> "HC"
    DataSource.MANUAL -> "Ручн."
    DataSource.HA -> "HA"
}

@Composable
fun SplashScreen(progress: Float, statusText: String) {
    val scale by animateFloatAsState(
        targetValue = if (progress < 0.5f) 1.08f else 1.0f,
        animationSpec = tween(700),
        label = "logoPulse"
    )
    Box(
        modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.padding(32.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.ic_medassist_logo),
                contentDescription = "MedAssist Logo",
                modifier = Modifier.size(96.dp).scale(scale)
            )
            Text("MedAssist", fontSize = 26.sp, fontWeight = FontWeight.Bold)
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth(0.65f).height(6.dp))
            Text("$statusText · ${(progress * 100).toInt()}%", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun MainScreen(
    dateKey: String,
    canGoNextDay: Boolean = false,
    onPrevDay: () -> Unit = {},
    onNextDay: () -> Unit = {},
    vitals: List<VitalEntry>,
    allHistoryVitals: List<VitalEntry>,
    dailyContext: DailyContext?,
    allDailyContexts: List<DailyContext>,
    weatherLogs: List<WeatherLog>,
    weatherForecast: List<WeatherForecastDay>,
    foodPlates: List<FoodPlate>,
    foodDishes: List<FoodDish>,
    medicationsList: List<MedicationItem>,
    packagesList: List<MedPackage>,
    medEvents: List<MedicationEvent>,
    initialHaUrl: String,
    initialHaToken: String,
    initialGeminiKey: String,
    lastInsulinDose: Double,
    userProfile: UserProfile,
    userNorms: UserNorms,
    appLang: AppLang,
    tileOrder: List<Int>,
    customTiles: List<CustomTileDef>,
    pinnedDevices: Map<BleDeviceRole, PinnedBleDevice>,
    bleDevices: List<ScannedBleDevice>,
    isScanningBle: Boolean,
    initialThemeMode: Int = 0,
    initialLargeUi: Boolean = false,
    initialNotifSound: String = "chime",
    initialNotifRepeatMin: Int = 0,
    initialNotifVolume: Int = 80,
    initialDailyCheckEnabled: Boolean = true,
    initialDailyCheckTime: String = "21:00",
    initialBleSound: String = "ping",
    initialBleVolume: Int = 80,
    initialAiAdviceEnabled: Boolean = true,
    initialNotifGapMs: Int = 250,
    onSaveUiPrefs: (Int, Boolean, String, Int, Int, Boolean, String, String, Int, Boolean, Int) -> Unit = { _, _, _, _, _, _, _, _, _, _, _ -> },
    onSaveSettings: (String, String, String, UserProfile, UserNorms, AppLang) -> Unit,
    onSaveTileOrder: (List<Int>) -> Unit,
    onSaveCustomTiles: (List<CustomTileDef>) -> Unit,
    onUpdateStepsSleep: (Long, Long) -> Unit,
    onUpdateVital: (VitalEntry) -> Unit,
    onDeleteVital: (VitalEntry) -> Unit,
    onUpdateMedEvent: (MedicationEvent) -> Unit,
    onDeleteMedEvent: (MedicationEvent) -> Unit,
    onAddVital: (VitalType, Double, Double?, Int?, String) -> Unit,
    onTakeMedItem: (MedicationItem, Double) -> Unit,
    onTakePackage: (MedPackage) -> Unit,
    onSaveMedItem: (MedicationItem) -> Unit,
    onDeleteMedItem: (MedicationItem) -> Unit,
    onSavePackage: (MedPackage) -> Unit,
    onDeletePackage: (MedPackage) -> Unit,
    onAskGeminiMed: suspend (String) -> MedSuggestion?,
    onAskDailyAdvice: suspend (String) -> String? = { null },
    onAskAdviceChat: suspend (String, List<Pair<Boolean, String>>, String) -> String? = { _, _, _ -> null },
    onAnalyzeFoodPhoto: suspend (String, List<FoodPlate>, Int?, String) -> FoodAnalysis?,
    onAnalyzeFoodText: suspend (String, Int?, String) -> FoodAnalysis?,
    onIdentifyPlatePhoto: suspend (String) -> PlateAnalysis?,
    onRefreshWeather: () -> Unit,
    onSaveFoodPlate: (FoodPlate) -> Unit,
    onDeleteFoodPlate: (FoodPlate) -> Unit,
    onSaveFoodDish: (FoodDish) -> Unit,
    onDeleteFoodDish: (FoodDish) -> Unit,
    onSyncHealthConnect: () -> Unit,
    onSyncHa: () -> Unit,
    onStartBleScan: () -> Unit,
    onPinAndConnectDevice: (BleDeviceRole, String, String) -> Unit,
    onReadPinnedDevice: (BleDeviceRole) -> Unit,
    onUnpinDevice: (BleDeviceRole) -> Unit,
    onExportBackup: () -> Unit,
    onImportBackup: () -> Unit,
    onForceExit: () -> Unit
) {
    val s = remember(appLang) { stringsFor(appLang) }
    val haptic = LocalHapticFeedback.current

    var showAddDialog by remember { mutableStateOf(false) }
    var showFoodDialog by remember { mutableStateOf(false) }
    var showMedsTodayDialog by remember { mutableStateOf(false) }
    var showAdviceChatDialog by remember { mutableStateOf(false) }
    var adviceChatInitialText by remember { mutableStateOf("") }
    var adviceChatContext by remember { mutableStateOf("") }
    var showLargeMenuDialog by remember { mutableStateOf(false) }
    var showFoodDirectoryDialog by remember { mutableStateOf(false) }
    var showNoteDialog by remember { mutableStateOf(false) }
    var showDirectoriesMenuDialog by remember { mutableStateOf(false) }
    var returnToAddOnBack by remember { mutableStateOf(false) }
    var showInsulinDialog by remember { mutableStateOf(false) }
    var quickTileInputType by remember { mutableStateOf<String?>(null) }
    var deletingVital by remember { mutableStateOf<VitalEntry?>(null) }
    var deletingMedEvent by remember { mutableStateOf<MedicationEvent?>(null) }
    var showLogsDialog by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }
    var settingsInitialTab by remember { mutableStateOf(0) }
    var showBleDialog by remember { mutableStateOf(false) }
    var showChangelogDialog by remember { mutableStateOf(false) }
    var showWeatherDialog by remember { mutableStateOf(false) }
    var viewingPackage by remember { mutableStateOf<MedPackage?>(null) }
    var showTileConstructor by remember { mutableStateOf(false) }
    var customEntryTarget by remember { mutableStateOf<Triple<String, String, String>?>(null) }
    var customHistoryTile by remember { mutableStateOf<CustomTileDef?>(null) }
    var showMedDirectoryDialog by remember { mutableStateOf(false) }
    var editingMed by remember { mutableStateOf<MedicationItem?>(null) }
    var showQuickTakePicker by remember { mutableStateOf(false) }
    var historyCategory by remember { mutableStateOf<Int?>(null) }
    var movingTileId by remember { mutableStateOf<Int?>(null) }

    val shimmerAnim = remember { Animatable(0f) }
    var shimmerActive by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(3000)
            shimmerAnim.snapTo(0f)
            shimmerActive = true
            shimmerAnim.animateTo(1f, animationSpec = tween(durationMillis = 1400))
            shimmerActive = false
            delay(25600)
        }
    }

    val latestGlucose = vitals.firstOrNull { it.type == VitalType.GLUCOSE }
    val latestInsulin = vitals.firstOrNull { it.type == VitalType.INSULIN }
    val latestBp = vitals.firstOrNull { it.type == VitalType.BP }
    val latestWeight = vitals.firstOrNull { it.type == VitalType.WEIGHT }
        ?: allHistoryVitals.firstOrNull { it.type == VitalType.WEIGHT }
    val latestWater = vitals.firstOrNull { it.type == VitalType.WATER }
    val totalWater = vitals.filter { it.type == VitalType.WATER }.sumOf { it.value1 }.toInt()
    val totalInsulin = vitals.filter { it.type == VitalType.INSULIN }.sumOf { it.value1 }.toInt()
    val foodVitalsToday = vitals.filter { it.type == VitalType.FOOD }
    val latestFood = foodVitalsToday.firstOrNull()
    val totalXeToday = foodVitalsToday.sumOf { it.value1 }
    val timeFmt = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    val clipboard = LocalClipboardManager.current
    var copiedDayLog by remember { mutableStateOf(false) }
    val chronoRows = remember(vitals, medEvents) {
        val list = mutableListOf<Triple<Long, VitalEntry?, MedicationEvent?>>()
        vitals.forEach { list.add(Triple(it.timestamp, it, null)) }
        medEvents.forEach { list.add(Triple(it.takenAt, null, it)) }
        list.sortedBy { it.first }
    }
    fun copyDailyLog() {
        val sb = StringBuilder()
        sb.append("$dateKey | ${userProfile.city.ifBlank { s.cityDefault }} ${dailyContext?.weatherPressureMmHg ?: "-"}мм ${dailyContext?.weatherTempC ?: "-"}°C | ")
        val xeStr = if (totalXeToday > 0) " ХЕ:${"%.1f".format(Locale.US, totalXeToday)}" else ""
        sb.append("Шаги:${dailyContext?.steps ?: 0} Сон:${(dailyContext?.sleepMinutes ?: 0) / 60}ч${(dailyContext?.sleepMinutes ?: 0) % 60}м Вода:${totalWater}мл Инс:${totalInsulin}ЕД$xeStr\n")
        chronoRows.forEach { (ts, v, me) ->
            val tStr = timeFmt.format(Date(ts))
            if (v != null) {
                val (rowTxt, _, _) = formatVitalRow(v, userNorms, s)
                val wxPart = if (v.type == VitalType.BP && v.weatherSummary.isNotBlank()) " · ${v.weatherSummary}" else ""
                val nTxt = if (v.note.isNotBlank() && v.type != VitalType.FOOD && v.type != VitalType.NOTE) " (${v.note})" else ""
                sb.append("$tStr · $rowTxt$wxPart$nTxt [${shortSourceLabel(v.source)}]\n")
            } else if (me != null) {
                val mNote = if (me.note.isNotBlank()) " (${me.note})" else ""
                sb.append("$tStr · Принял: ${me.medName} ${me.dose}$mNote [Табл.]\n")
            }
        }
        clipboard.setText(AnnotatedString(sb.toString().trim()))
        copiedDayLog = true
    }

    val isBpLowForMeds = latestBp != null && latestBp.value1 < 125.0
    val shortTimeFmt = remember { SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()) }

    fun normStyle(value: Double?, min: Double, max: Double): Pair<Color?, FontWeight> {
        if (value == null) return null to FontWeight.Bold
        return when {
            value > max -> ColorHigh to FontWeight.Bold
            value < min -> ColorLow to FontWeight.Bold
            else -> null to FontWeight.Bold
        }
    }

    Scaffold(
        topBar = {
            Surface(color = MaterialTheme.colorScheme.surface) {
                val latestWx = weatherLogs.firstOrNull()
                val condText = (latestWx?.condition?.takeIf { it.isNotBlank() } ?: dailyContext?.weatherCondition?.trim()?.takeIf { it.isNotEmpty() })?.let { "·$it" } ?: ""
                val shortDate = if (dateKey.length >= 10) "${dateKey.substring(8, 10)}.${dateKey.substring(5, 7)}" else dateKey
                val extraWx = if (latestWx != null) "(ощущ.${latestWx.feelsLikeC}°C)·${latestWx.humidity}%·${latestWx.windKmh}км/ч" else ""
                Row(
                    Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 6.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onPrevDay, modifier = Modifier.size(20.dp)) {
                        Icon(Icons.Default.ChevronLeft, contentDescription = "Предыдущий день", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(15.dp))
                    }
                    Text(
                        shortDate,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 1.dp)
                    )
                    IconButton(onClick = onNextDay, enabled = canGoNextDay, modifier = Modifier.size(20.dp)) {
                        Icon(
                            Icons.Default.ChevronRight,
                            contentDescription = "Следующий день",
                            tint = if (canGoNextDay) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.28f),
                            modifier = Modifier.size(15.dp)
                        )
                    }
                    Text(
                        "·${userProfile.city.ifBlank { s.cityDefault }} ${latestWx?.pressureMmHg ?: dailyContext?.weatherPressureMmHg ?: "—"}мм·${latestWx?.tempC ?: dailyContext?.weatherTempC ?: "—"}°C$extraWx$condText",
                        fontSize = 11.sp,
                        maxLines = 1,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.weight(1f).basicMarquee().clickable { showWeatherDialog = true }
                    )
                }
            }
        },
        bottomBar = {
            Surface(color = MaterialTheme.colorScheme.surface, tonalElevation = 3.dp) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(3.dp),
                        modifier = Modifier
                            .graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen)
                            .drawWithContent {
                                drawContent()
                                if (shimmerActive) {
                                    val w = size.width
                                    val x = shimmerAnim.value * (w + 160f) - 80f
                                    drawRect(
                                        brush = Brush.linearGradient(
                                            colors = listOf(
                                                Color.Transparent,
                                                Color(0xFF0057B7).copy(alpha = 0.85f),
                                                Color(0xFFFFDD00).copy(alpha = 0.9f),
                                                Color.Transparent
                                            ),
                                            start = Offset(x - 70f, 0f),
                                            end = Offset(x + 70f, size.height)
                                        ),
                                        blendMode = BlendMode.SrcAtop
                                    )
                                }
                            }
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.ic_medassist_logo),
                            contentDescription = "Logo",
                            modifier = Modifier.size(19.dp)
                        )
                        Text("MedAssist", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                        Text(
                            text = buildAnnotatedString {
                                withStyle(
                                    SpanStyle(
                                        fontSize = 10.sp,
                                        baselineShift = BaselineShift.Superscript,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                ) { append("v59 by mizgiroff") }
                            },
                            modifier = Modifier.clickable { showChangelogDialog = true }
                        )
                    }
                    if (initialLargeUi) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilledTonalButton(
                                onClick = { showLargeMenuDialog = true },
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                modifier = Modifier.heightIn(min = 40.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                                    Icon(Icons.Default.Menu, contentDescription = "Меню", modifier = Modifier.size(20.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("Меню", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
                                }
                            }
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.primaryContainer,
                                modifier = Modifier.size(40.dp).clip(RoundedCornerShape(10.dp)).clickable { showAddDialog = true }
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.Add, contentDescription = s.newEntry, tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(24.dp))
                                }
                            }
                        }
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                            IconButton(onClick = { showBleDialog = true }, modifier = Modifier.size(30.dp)) { Icon(Icons.Default.Bluetooth, contentDescription = "BLE", modifier = Modifier.size(19.dp)) }
                            IconButton(onClick = onSyncHealthConnect, modifier = Modifier.size(30.dp)) { Icon(Icons.Default.Sync, contentDescription = "HC", modifier = Modifier.size(19.dp)) }
                            IconButton(onClick = { showLogsDialog = true }, modifier = Modifier.size(30.dp)) { Icon(Icons.Default.BugReport, contentDescription = "Logs", modifier = Modifier.size(19.dp)) }
                            IconButton(onClick = { showSettingsDialog = true }, modifier = Modifier.size(30.dp)) { Icon(Icons.Default.Settings, contentDescription = s.settings, modifier = Modifier.size(19.dp)) }
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.primaryContainer,
                                modifier = Modifier.size(30.dp).clip(RoundedCornerShape(8.dp)).clickable { showAddDialog = true }
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.Add, contentDescription = s.newEntry, tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(19.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .then(if (initialLargeUi) Modifier.verticalScroll(rememberScrollState()) else Modifier)
                .padding(horizontal = 12.dp, vertical = 4.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            if (movingTileId != null) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(s.moveHint, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f))
                    TextButton(onClick = { movingTileId = null; showTileConstructor = true }, contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp), modifier = Modifier.height(24.dp)) {
                        Text("Конструктор плиток", fontSize = 11.sp)
                    }
                }
            }

            val rows = if (initialLargeUi) tileOrder.chunked(1) else tileOrder.chunked(2)
            rows.forEach { rowTiles ->
                Row(
                    Modifier.fillMaxWidth().height(if (initialLargeUi) 152.dp else 134.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    rowTiles.forEach { tileId ->
                        val isMoving = movingTileId == tileId
                        val tileScale by animateFloatAsState(if (isMoving) 1.04f else 1.0f, label = "tileScale")
                        val tileElev by animateDpAsState(if (isMoving) 8.dp else 1.dp, label = "tileElev")

                        when (tileId) {
                            0 -> {
                                val (gColor, gWeight) = normStyle(latestGlucose?.value1, userNorms.glucoseMin, userNorms.glucoseMax)
                                MetricTile(
                                    modifier = Modifier.weight(1f).fillMaxHeight().scale(tileScale),
                                    elevation = tileElev,
                                    isSelected = isMoving,
                                    topActionLabel = "+${s.sugar}",
                                    onTopAction = { quickTileInputType = "GLU" },
                                    topStamp = latestGlucose?.let { "${shortTimeFmt.format(Date(it.timestamp))} · ${shortSourceLabel(it.source)}" } ?: "",
                                    value = "${latestGlucose?.value1 ?: "—"} ммоль",
                                    valueColor = null,
                                    valueWeight = gWeight,
                                    bottomActionLabel = "+${s.insulin}",
                                    onBottomAction = { showInsulinDialog = true },
                                    bottomStamp = latestInsulin?.let { "${shortTimeFmt.format(Date(it.timestamp))} · ${shortSourceLabel(it.source)}" } ?: "",
                                    sub = "$totalInsulin ЕД",
                                    highlightBg = (gColor != null),
                                    onOpenDevices = { movingTileId = null; showBleDialog = true },
                                    onClick = {
                                        if (movingTileId != null) {
                                            onSaveTileOrder(swapTiles(tileOrder, movingTileId!!, 0)); movingTileId = null
                                        } else historyCategory = 0
                                    },
                                    onLongClick = {
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        movingTileId = if (isMoving) null else 0
                                    }
                                )
                            }
                            1 -> {
                                val isHigh = (latestBp != null && latestBp.value1 > userNorms.sysMax) || (latestBp?.value2 != null && latestBp.value2 > userNorms.diaMax)
                                val isLow = (latestBp != null && latestBp.value1 < userNorms.sysMin) || (latestBp?.value2 != null && latestBp.value2 < userNorms.diaMin)
                                val bpColor = when { isHigh -> ColorHigh; isLow -> ColorLow; else -> null }
                                val (pColor, _) = normStyle(latestBp?.pulse?.toDouble(), userNorms.pulseMin.toDouble(), userNorms.pulseMax.toDouble())
                                val bpStamp = latestBp?.let { "${shortTimeFmt.format(Date(it.timestamp))} · ${shortSourceLabel(it.source)}" } ?: ""
                                MetricTile(
                                    modifier = Modifier.weight(1f).fillMaxHeight().scale(tileScale),
                                    elevation = tileElev,
                                    isSelected = isMoving,
                                    topActionLabel = "+Давление",
                                    onTopAction = { quickTileInputType = "BP" },
                                    topStamp = bpStamp,
                                    value = if (latestBp != null) "${latestBp.value1.toInt()}/${latestBp.value2?.toInt() ?: 0}" else "—",
                                    valueColor = null,
                                    valueWeight = FontWeight.Bold,
                                    bottomActionLabel = "+${s.pulseLabel}",
                                    onBottomAction = { quickTileInputType = "BP" },
                                    bottomStamp = bpStamp,
                                    sub = "${latestBp?.pulse ?: "—"} уд/мин",
                                    subColor = null,
                                    subWeight = if (pColor != null) FontWeight.Bold else FontWeight.SemiBold,
                                    highlightBg = isBpLowForMeds || (bpColor != null) || (pColor != null),
                                    onOpenDevices = { movingTileId = null; showBleDialog = true },
                                    onClick = {
                                        if (movingTileId != null) {
                                            onSaveTileOrder(swapTiles(tileOrder, movingTileId!!, 1)); movingTileId = null
                                        } else historyCategory = 1
                                    },
                                    onLongClick = {
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        movingTileId = if (isMoving) null else 1
                                    }
                                )
                            }
                            2 -> {
                                MetricTile(
                                    modifier = Modifier.weight(1f).fillMaxHeight().scale(tileScale),
                                    elevation = tileElev,
                                    isSelected = isMoving,
                                    topActionLabel = "+Вес",
                                    onTopAction = { quickTileInputType = "WEIGHT" },
                                    topStamp = latestWeight?.let { "${shortTimeFmt.format(Date(it.timestamp))} · ${shortSourceLabel(it.source)}" } ?: "",
                                    value = "${latestWeight?.value1 ?: "—"} кг",
                                    bottomActionLabel = "+250 мл",
                                    onBottomAction = { onAddVital(VitalType.WATER, 250.0, null, null, "") },
                                    bottomStamp = latestWater?.let { "${shortTimeFmt.format(Date(it.timestamp))} · ${shortSourceLabel(it.source)}" } ?: "",
                                    sub = "$totalWater мл",
                                    onOpenDevices = { movingTileId = null; showBleDialog = true },
                                    onClick = {
                                        if (movingTileId != null) {
                                            onSaveTileOrder(swapTiles(tileOrder, movingTileId!!, 2)); movingTileId = null
                                        } else historyCategory = 2
                                    },
                                    onLongClick = {
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        movingTileId = if (isMoving) null else 2
                                    }
                                )
                            }
                            3 -> {
                                val dcStamp = if (dailyContext != null && dailyContext.updatedAt > 0L) {
                                    "${shortTimeFmt.format(Date(dailyContext.updatedAt))} · ${dailyContext.updatedSource}"
                                } else {
                                    "${if (dateKey.length >= 10) "${dateKey.substring(8, 10)}.${dateKey.substring(5, 7)}" else dateKey} · HC"
                                }
                                MetricTile(
                                    modifier = Modifier.weight(1f).fillMaxHeight().scale(tileScale),
                                    elevation = tileElev,
                                    isSelected = isMoving,
                                    topActionLabel = "+Шаги",
                                    onTopAction = { quickTileInputType = "STEPS" },
                                    topStamp = dcStamp,
                                    value = "${dailyContext?.steps ?: 0}",
                                    bottomActionLabel = "+${s.sleepLabel}",
                                    onBottomAction = { quickTileInputType = "SLEEP" },
                                    bottomStamp = dcStamp,
                                    sub = "${(dailyContext?.sleepMinutes ?: 0) / 60}ч ${(dailyContext?.sleepMinutes ?: 0) % 60}м",
                                    onOpenDevices = { movingTileId = null; showBleDialog = true },
                                    onClick = {
                                        if (movingTileId != null) {
                                            onSaveTileOrder(swapTiles(tileOrder, movingTileId!!, 3)); movingTileId = null
                                        } else historyCategory = 3
                                    },
                                    onLongClick = {
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        movingTileId = if (isMoving) null else 3
                                    }
                                )
                            }
                            4 -> {
                                MetricTile(
                                    modifier = Modifier.weight(1f).fillMaxHeight().scale(tileScale),
                                    elevation = tileElev,
                                    isSelected = isMoving,
                                    topActionLabel = "+Еда",
                                    onTopAction = { showFoodDialog = true },
                                    topStamp = latestFood?.let { "${shortTimeFmt.format(Date(it.timestamp))} · ${shortSourceLabel(it.source)}" } ?: "",
                                    value = "${"%.1f".format(Locale.US, totalXeToday)} ХЕ",
                                    bottomActionLabel = "Питание",
                                    onBottomAction = { historyCategory = 4 },
                                    bottomStamp = if (foodVitalsToday.isNotEmpty()) pluralIntake(foodVitalsToday.size) else "",
                                    sub = latestFood?.note?.let { stripMealPrefix(it).take(18) }?.ifBlank { "—" } ?: "—",
                                    onOpenDevices = { movingTileId = null; showFoodDialog = true },
                                    onClick = {
                                        if (movingTileId != null) {
                                            onSaveTileOrder(swapTiles(tileOrder, movingTileId!!, 4)); movingTileId = null
                                        } else historyCategory = 4
                                    },
                                    onLongClick = {
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        movingTileId = if (isMoving) null else 4
                                    }
                                )
                            }
                            else -> {
                                val lastMedEv = medEvents.firstOrNull()
                                MetricTile(
                                    modifier = Modifier.weight(1f).fillMaxHeight().scale(tileScale),
                                    elevation = tileElev,
                                    isSelected = isMoving,
                                    topActionLabel = "+Приём",
                                    onTopAction = { showQuickTakePicker = true },
                                    topStamp = lastMedEv?.let { "${timeFmt.format(Date(it.takenAt))} · Табл." } ?: "",
                                    value = pluralIntake(medEvents.size),
                                    bottomActionLabel = "Лекарства",
                                    onBottomAction = { showMedsTodayDialog = true },
                                    bottomStamp = if (isBpLowForMeds) "АД<125" else "Сегодня",
                                    sub = lastMedEv?.medName?.take(18) ?: "—",
                                    highlightBg = isBpLowForMeds,
                                    onOpenDevices = { movingTileId = null; showMedDirectoryDialog = true },
                                    onClick = {
                                        if (movingTileId != null) {
                                            onSaveTileOrder(swapTiles(tileOrder, movingTileId!!, 5)); movingTileId = null
                                        } else showMedsTodayDialog = true
                                    },
                                    onLongClick = {
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        movingTileId = if (isMoving) null else 5
                                    }
                                )
                            }
                        }
                    }
                    if (!initialLargeUi && rowTiles.size == 1) Spacer(Modifier.weight(1f))
                }
            }

            if (customTiles.isNotEmpty()) {
                customTiles.chunked(2).forEach { pair ->
                    Row(Modifier.fillMaxWidth().height(if (initialLargeUi) 152.dp else 134.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        pair.forEach { ct ->
                            val topKey = "${ct.id}_TOP"
                            val botKey = "${ct.id}_BOT"
                            val latestTop = vitals.firstOrNull { it.type == VitalType.CUSTOM && it.note.startsWith("$topKey|") }
                            val latestBot = vitals.firstOrNull { it.type == VitalType.CUSTOM && it.note.startsWith("$botKey|") }
                            val topCol = if (latestTop != null && ct.topMax != null && latestTop.value1 > ct.topMax) ColorHigh
                                else if (latestTop != null && ct.topMin != null && latestTop.value1 < ct.topMin) ColorLow else null
                            MetricTile(
                                modifier = Modifier.weight(1f).fillMaxHeight(),
                                topActionLabel = "+${ct.topLabel}",
                                onTopAction = { customEntryTarget = Triple(topKey, ct.topLabel, ct.topUnit) },
                                topStamp = latestTop?.let { "${shortTimeFmt.format(Date(it.timestamp))} · ${shortSourceLabel(it.source)}" } ?: "",
                                value = "${latestTop?.value1 ?: "—"} ${ct.topUnit}".trim(),
                                valueColor = topCol,
                                bottomActionLabel = if (ct.bottomLabel.isNotBlank()) "+${ct.bottomLabel}" else "Настр.",
                                onBottomAction = {
                                    if (ct.bottomLabel.isNotBlank()) customEntryTarget = Triple(botKey, ct.bottomLabel, ct.bottomUnit)
                                    else showTileConstructor = true
                                },
                                bottomStamp = latestBot?.let { "${shortTimeFmt.format(Date(it.timestamp))} · ${shortSourceLabel(it.source)}" } ?: "",
                                sub = if (ct.bottomLabel.isNotBlank()) "${latestBot?.value1 ?: "—"} ${ct.bottomUnit}".trim() else "",
                                onOpenDevices = { showTileConstructor = true },
                                onClick = { customHistoryTile = ct },
                                onLongClick = {
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    showTileConstructor = true
                                }
                            )
                        }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(s.chronology, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                TactileTileAction(
                    label = if (copiedDayLog) "Скопировано ✓" else "Копировать",
                    onClick = { copyDailyLog() }
                )
            }
            val chronoListState = rememberLazyListState()
            LaunchedEffect(chronoRows.size, dateKey) {
                if (chronoRows.isNotEmpty()) {
                    chronoListState.animateScrollToItem(chronoRows.lastIndex)
                }
            }
            LazyColumn(
                state = chronoListState,
                modifier = if (initialLargeUi) Modifier.fillMaxWidth().heightIn(min = 180.dp, max = 380.dp) else Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(0.dp)
            ) {
                items(chronoRows) { (ts, item, me) ->
                    if (item != null) {
                        val (rowText, rowColor, rowWeight) = formatVitalRow(item, userNorms, s)
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .combinedClickable(
                                    onClick = {},
                                    onLongClick = {
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        deletingVital = item
                                    }
                                )
                                .padding(vertical = 0.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "${timeFmt.format(Date(ts))} · $rowText${if (item.type == VitalType.BP && item.weatherSummary.isNotBlank()) " · ${item.weatherSummary}" else ""}${if (item.note.isNotBlank() && item.type != VitalType.FOOD && item.type != VitalType.NOTE) " (${item.note})" else ""}",
                                fontSize = 12.sp,
                                lineHeight = 14.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f).padding(end = 8.dp),
                                color = rowColor ?: MaterialTheme.colorScheme.onSurface,
                                fontWeight = rowWeight
                            )
                            Text(shortSourceLabel(item.source), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    } else if (me != null) {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .combinedClickable(
                                    onClick = {},
                                    onLongClick = {
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        deletingMedEvent = me
                                    }
                                )
                                .padding(vertical = 0.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${timeFmt.format(Date(ts))} · Принял: ${me.medName} · ${me.dose}${if (me.note.isNotBlank()) " (${me.note})" else ""}", fontSize = 12.sp, lineHeight = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f).padding(end = 8.dp))
                            Text("Табл.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
            if (initialGeminiKey.isNotBlank() && initialAiAdviceEnabled) {
                var aiAdvice by remember(dateKey) { mutableStateOf("") }
                var aiAdviceLoading by remember { mutableStateOf(false) }
                val adviceTriggerKey = "${dateKey}_${vitals.size}_${medEvents.size}_${dailyContext?.steps ?: 0}"
                val scopeAdvice = rememberCoroutineScope()
                fun buildSummary(): String {
                    val bpTxt = latestBp?.let { "АД ${it.value1.toInt()}/${it.value2?.toInt() ?: 0}" } ?: "АД нет"
                    val gluTxt = latestGlucose?.let { "Сахар ${it.value1}" } ?: "Сахар нет"
                    val foodTxt = latestFood?.note?.let { stripMealPrefix(it) } ?: "еда нет"
                    val medsTxt = if (medEvents.isNotEmpty()) medEvents.joinToString(", ") { it.medName } else "нет"
                    return "$bpTxt, $gluTxt, инсулин $totalInsulin ЕД, ХЕ ${"%.1f".format(Locale.US, totalXeToday)}, шаги ${dailyContext?.steps ?: 0}, вода $totalWater мл, последняя еда: $foodTxt, принятые лекарства: $medsTxt"
                }
                fun loadAdvice() {
                    if (aiAdviceLoading) return
                    aiAdviceLoading = true
                    val sum = buildSummary()
                    scopeAdvice.launch {
                        val res = onAskDailyAdvice(sum)
                        if (!res.isNullOrBlank()) aiAdvice = res
                        aiAdviceLoading = false
                    }
                }
                LaunchedEffect(adviceTriggerKey) {
                    if (vitals.isNotEmpty() || medEvents.isNotEmpty()) loadAdvice()
                }
                if (aiAdvice.isNotBlank() || aiAdviceLoading) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f),
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).combinedClickable(
                            onClick = { loadAdvice() },
                            onLongClick = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                adviceChatContext = buildSummary()
                                adviceChatInitialText = aiAdvice
                                showAdviceChatDialog = true
                            }
                        )
                    ) {
                        Text(
                            text = if (aiAdviceLoading && aiAdvice.isBlank()) "ИИ-совет: анализирую день..." else "ИИ: $aiAdvice",
                            fontSize = 11.sp,
                            lineHeight = 14.sp,
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }
    }

    if (showAdviceChatDialog) {
        AiAdviceChatDialog(
            dayContext = adviceChatContext,
            initialAdvice = adviceChatInitialText,
            onAskChat = onAskAdviceChat,
            onDismiss = { showAdviceChatDialog = false }
        )
    }

    if (showLargeMenuDialog) {
        FullScreenDialog(title = "Меню", onDismiss = { showLargeMenuDialog = false }) { innerPad ->
            Column(Modifier.fillMaxSize().padding(innerPad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                FilledTonalButton(
                    onClick = { showLargeMenuDialog = false; showBleDialog = true },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                        Icon(Icons.Default.Bluetooth, contentDescription = null); Spacer(Modifier.width(10.dp)); Text("Приборы (BLE)", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
                    }
                }
                FilledTonalButton(
                    onClick = { showLargeMenuDialog = false; onSyncHealthConnect() },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                        Icon(Icons.Default.Sync, contentDescription = null); Spacer(Modifier.width(10.dp)); Text("Синхронизация (Health Connect)", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
                    }
                }
                FilledTonalButton(
                    onClick = { showLargeMenuDialog = false; showLogsDialog = true },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                        Icon(Icons.Default.BugReport, contentDescription = null); Spacer(Modifier.width(10.dp)); Text("Журнал отладки", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
                    }
                }
                FilledTonalButton(
                    onClick = { showLargeMenuDialog = false; showSettingsDialog = true },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                        Icon(Icons.Default.Settings, contentDescription = null); Spacer(Modifier.width(10.dp)); Text(s.settings, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
                    }
                }
            }
        }
    }

    if (showMedsTodayDialog) {
        FullScreenDialog(
            title = s.medsToday,
            onDismiss = { showMedsTodayDialog = false },
            actions = {
                TextButton(onClick = { showMedsTodayDialog = false; showMedDirectoryDialog = true }) { Text("Таблетки") }
                TextButton(onClick = { showMedsTodayDialog = false; showQuickTakePicker = true }) { Text("+Приём", fontWeight = FontWeight.SemiBold) }
            }
        ) { innerPad ->
            LazyColumn(
                Modifier.fillMaxSize().padding(innerPad).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (medEvents.isEmpty()) {
                    item { Text("Сегодня приёмов ещё не отмечено", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                } else {
                    items(medEvents) { ev ->
                        val linkedMed = medicationsList.firstOrNull { it.id == ev.medId }
                        Row(
                            Modifier.fillMaxWidth().combinedClickable(
                                onClick = {
                                    if (linkedMed != null) { showMedsTodayDialog = false; editingMed = linkedMed }
                                    else if (ev.slot.startsWith("PKG_")) {
                                        val pkgId = ev.slot.removePrefix("PKG_").toLongOrNull()
                                        viewingPackage = packagesList.firstOrNull { it.id == pkgId }
                                    }
                                },
                                onLongClick = {
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    deletingMedEvent = ev
                                }
                            ).padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${timeFmt.format(Date(ev.takenAt))} · ${ev.medName} ${ev.dose} ✓", fontSize = 14.sp, fontWeight = FontWeight.Medium)
                        }
                        HorizontalDivider()
                    }
                }
            }
        }
    }

    if (showFoodDirectoryDialog) {
        FoodDirectoryDialog(
            s = s,
            hasGeminiKey = initialGeminiKey.isNotBlank(),
            foodDishes = foodDishes,
            foodPlates = foodPlates,
            onOpenGeminiSettings = { showFoodDirectoryDialog = false; settingsInitialTab = 2; showSettingsDialog = true },
            onSaveDish = onSaveFoodDish,
            onDeleteDish = onDeleteFoodDish,
            onSavePlate = onSaveFoodPlate,
            onDeletePlate = onDeleteFoodPlate,
            onIdentifyPlatePhoto = onIdentifyPlatePhoto,
            useBackArrow = returnToAddOnBack,
            onDismiss = { showFoodDirectoryDialog = false; if (returnToAddOnBack) showDirectoriesMenuDialog = true }
        )
    }

    var pickingDoseMed by remember { mutableStateOf<MedicationItem?>(null) }
    if (showQuickTakePicker) {
        FullScreenDialog(title = "Отметить приём", onDismiss = { showQuickTakePicker = false }) { innerPad ->
            LazyColumn(
                Modifier.fillMaxSize().padding(innerPad).padding(horizontal = 12.dp, vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                if (packagesList.isNotEmpty()) {
                    item { Text("Пакеты:", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    items(packagesList) { pkg ->
                        val takenPkg = medEvents.any { it.slot == "PKG_${pkg.id}" }
                        Button(
                            onClick = { onTakePackage(pkg); showQuickTakePicker = false },
                            enabled = !takenPkg,
                            modifier = Modifier.fillMaxWidth().height(34.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp)
                        ) {
                            Text(if (takenPkg) "${pkg.name} ✓" else pkg.name, fontSize = 12.sp, maxLines = 1)
                        }
                    }
                }
                if (medicationsList.isNotEmpty()) {
                    item { Text("Отдельные препараты (выбор дозы):", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp)) }
                    items(medicationsList) { med ->
                        FilledTonalButton(
                            onClick = { pickingDoseMed = med },
                            modifier = Modifier.fillMaxWidth().height(34.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp)
                        ) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text("${med.name} ${med.dosage}".trim(), fontSize = 12.sp, maxLines = 1)
                                Text("ост: ${"%.1f".format(Locale.US, med.stockLeft).removeSuffix(".0")}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
    }

    if (pickingDoseMed != null) {
        val m = pickingDoseMed!!
        var doseStr by remember(m.id) { mutableStateOf(m.countPerIntake.toString().removeSuffix(".0")) }
        val doseNum = (doseStr.replace(",", ".").toDoubleOrNull() ?: m.countPerIntake).coerceIn(0.25, 10.0)
        AlertDialog(
            onDismissRequest = { pickingDoseMed = null },
            title = { Text("${m.name} ${m.dosage}".trim(), fontSize = 16.sp) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Количество (табл. / ед.): $doseStr", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("0.25", "0.5", "1", "1.5", "2").forEach { d ->
                            FilterChip(
                                selected = doseStr.replace(",", ".") == d,
                                onClick = { doseStr = d },
                                label = { Text("$d шт", fontSize = 12.sp) }
                            )
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(-0.5, -0.25, 0.25, 0.5).forEach { st ->
                            OutlinedButton(
                                onClick = {
                                    val nv = (doseNum + st).coerceAtLeast(0.25)
                                    doseStr = "%.2f".format(Locale.US, nv).trimEnd('0').trimEnd('.')
                                },
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(0.dp)
                            ) { Text(if (st > 0) "+$st" else "$st", fontSize = 11.sp) }
                        }
                    }
                    OutlinedTextField(
                        value = doseStr,
                        onValueChange = { doseStr = it },
                        label = { Text("Количество") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val cnt = doseStr.replace(",", ".").toDoubleOrNull() ?: m.countPerIntake
                    onTakeMedItem(m, cnt)
                    pickingDoseMed = null
                    showQuickTakePicker = false
                }) { Text("Принять", fontWeight = FontWeight.SemiBold) }
            },
            dismissButton = {
                TextButton(onClick = { pickingDoseMed = null }) { Text(s.cancel) }
            }
        )
    }

    if (deletingVital != null) {
        val v = deletingVital!!
        val (txt, _, _) = formatVitalRow(v, userNorms, s)
        var noteText by remember(v.id) { mutableStateOf(v.note) }
        AlertDialog(
            onDismissRequest = { deletingVital = null },
            title = { Text("Запись в хронике", fontSize = 16.sp) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("${shortTimeFmt.format(Date(v.timestamp))} · $txt", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    OutlinedTextField(
                        value = noteText,
                        onValueChange = { noteText = it },
                        label = { Text("Короткое примечание") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (v.type == VitalType.GLUCOSE) {
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("Натощак", "До еды", "30 мин после еды", "1 ч после еды", "1.5 ч после еды", "2 ч после еды", "3 ч после еды").forEach { tag ->
                                FilterChip(
                                    selected = noteText.trim() == tag,
                                    onClick = { noteText = if (noteText.trim() == tag) "" else tag },
                                    label = { Text(tag, fontSize = 11.sp) }
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Row {
                    TextButton(onClick = {
                        clipboard.setText(AnnotatedString("${shortTimeFmt.format(Date(v.timestamp))} · $txt${if (noteText.isNotBlank()) " ($noteText)" else ""}"))
                    }) { Text("Копировать") }
                    TextButton(onClick = {
                        onUpdateVital(v.copy(note = noteText.trim()))
                        deletingVital = null
                    }) { Text(s.save) }
                }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { onDeleteVital(v); deletingVital = null }) {
                        Text("Удалить", color = ColorHigh)
                    }
                    TextButton(onClick = { deletingVital = null }) { Text(s.cancel) }
                }
            }
        )
    }

    if (deletingMedEvent != null) {
        val me = deletingMedEvent!!
        var medNoteText by remember(me.id) { mutableStateOf(me.note) }
        AlertDialog(
            onDismissRequest = { deletingMedEvent = null },
            title = { Text("Приём препарата", fontSize = 16.sp) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("${shortTimeFmt.format(Date(me.takenAt))} · ${me.medName} · ${me.dose}", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    OutlinedTextField(
                        value = medNoteText,
                        onValueChange = { medNoteText = it },
                        label = { Text("Короткое примечание") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Row {
                    TextButton(onClick = {
                        clipboard.setText(AnnotatedString("${shortTimeFmt.format(Date(me.takenAt))} · ${me.medName} · ${me.dose}${if (medNoteText.isNotBlank()) " ($medNoteText)" else ""}"))
                    }) { Text("Копировать") }
                    TextButton(onClick = {
                        onUpdateMedEvent(me.copy(note = medNoteText.trim()))
                        deletingMedEvent = null
                    }) { Text(s.save) }
                }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { onDeleteMedEvent(me); deletingMedEvent = null }) {
                        Text("Удалить", color = ColorHigh)
                    }
                    TextButton(onClick = { deletingMedEvent = null }) { Text(s.cancel) }
                }
            }
        )
    }

    if (showInsulinDialog) {
        var insVal by remember { mutableStateOf(lastInsulinDose.toInt().toString()) }
        val insNum = (insVal.replace(",", ".").toDoubleOrNull() ?: lastInsulinDose).coerceIn(0.0, 60.0)
        FullScreenDialog(
            title = "Инсулин (ЕД)",
            onDismiss = { showInsulinDialog = false },
            actions = {
                TextButton(onClick = {
                    val v = insVal.replace(",", ".").toDoubleOrNull() ?: return@TextButton
                    onAddVital(VitalType.INSULIN, v, null, null, "")
                    showInsulinDialog = false
                }) { Text(s.save, fontWeight = FontWeight.SemiBold) }
            }
        ) { innerPad ->
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(innerPad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("${insNum.toInt()} ЕД", fontSize = 36.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.align(Alignment.CenterHorizontally))
                Slider(
                    value = insNum.toFloat(),
                    onValueChange = { insVal = kotlin.math.round(it).toInt().toString() },
                    valueRange = 0f..60f
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(-5, -1, 1, 5).forEach { step ->
                        OutlinedButton(
                            onClick = { insVal = (insNum.toInt() + step).coerceIn(0, 100).toString() },
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(0.dp)
                        ) { Text(if (step > 0) "+$step" else "$step", fontSize = 13.sp) }
                    }
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(4, 6, 8, 10, 38, 40).forEach { d ->
                        AssistChip(onClick = { insVal = d.toString() }, label = { Text("$d ЕД", fontSize = 12.sp) })
                    }
                }
                OutlinedTextField(value = insVal, onValueChange = { insVal = it }, label = { Text("Количество ЕД") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            }
        }
    }

    if (quickTileInputType != null) {
        val init1 = remember(quickTileInputType) {
            when (quickTileInputType) {
                "GLU" -> "%.1f".format(Locale.US, latestGlucose?.value1 ?: 6.5)
                "BP" -> (latestBp?.value1?.toInt() ?: 120).toString()
                "WEIGHT" -> "%.1f".format(Locale.US, latestWeight?.value1 ?: 85.0)
                "STEPS" -> (dailyContext?.steps ?: 4000L).toString()
                else -> ((dailyContext?.sleepMinutes ?: 420L) / 60L).toString()
            }
        }
        val init2 = remember(quickTileInputType) {
            when (quickTileInputType) {
                "BP" -> (latestBp?.value2?.toInt() ?: 80).toString()
                "SLEEP" -> (((dailyContext?.sleepMinutes ?: 420L) % 60L) / 15L * 15L).toString()
                else -> ""
            }
        }
        val init3 = remember(quickTileInputType) {
            if (quickTileInputType == "BP") (latestBp?.pulse ?: 70).toString() else ""
        }
        var f1 by remember(quickTileInputType) { mutableStateOf(init1) }
        var f2 by remember(quickTileInputType) { mutableStateOf(init2) }
        var f3 by remember(quickTileInputType) { mutableStateOf(init3) }
        var gluNote by remember(quickTileInputType) { mutableStateOf("") }
        val qTitle = when (quickTileInputType) {
            "GLU" -> "Сахар (ммоль/л)"
            "BP" -> "Давление и пульс"
            "WEIGHT" -> "Вес (кг)"
            "STEPS" -> "Шаги за день"
            else -> "Сон (часы и минуты)"
        }
        fun saveQuick() {
            when (quickTileInputType) {
                "GLU" -> f1.replace(",", ".").toDoubleOrNull()?.let { onAddVital(VitalType.GLUCOSE, it, null, null, gluNote) }
                "BP" -> {
                    val sys = f1.toDoubleOrNull()
                    val dia = f2.toDoubleOrNull()
                    if (sys != null && dia != null) onAddVital(VitalType.BP, sys, dia, f3.toIntOrNull(), "")
                }
                "WEIGHT" -> f1.replace(",", ".").toDoubleOrNull()?.let { onAddVital(VitalType.WEIGHT, it, null, null, "") }
                "STEPS" -> f1.toLongOrNull()?.let { onUpdateStepsSleep(it, -1L) }
                "SLEEP" -> {
                    val h = f1.toLongOrNull() ?: 0L
                    val m = f2.toLongOrNull() ?: 0L
                    onUpdateStepsSleep(-1L, h * 60L + m)
                }
            }
            quickTileInputType = null
        }
        FullScreenDialog(
            title = qTitle,
            onDismiss = { quickTileInputType = null },
            actions = { TextButton(onClick = { saveQuick() }) { Text(s.save, fontWeight = FontWeight.SemiBold) } }
        ) { innerPad ->
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(innerPad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                when (quickTileInputType) {
                    "GLU" -> {
                        val gVal = (f1.replace(",", ".").toDoubleOrNull() ?: 6.5).coerceIn(2.0, 20.0)
                        val (gCol, _) = normStyle(gVal, userNorms.glucoseMin, userNorms.glucoseMax)
                        Text("${"%.1f".format(Locale.US, gVal)} ммоль/л", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = gCol ?: MaterialTheme.colorScheme.primary, modifier = Modifier.align(Alignment.CenterHorizontally))
                        Slider(
                            value = gVal.toFloat().coerceIn(3f, 15f),
                            onValueChange = { f1 = "%.1f".format(Locale.US, kotlin.math.round(it * 10.0) / 10.0) },
                            valueRange = 3f..15f
                        )
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(-0.5, -0.1, 0.1, 0.5).forEach { st ->
                                OutlinedButton(
                                    onClick = { f1 = "%.1f".format(Locale.US, (gVal + st).coerceIn(2.0, 25.0)) },
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(0.dp)
                                ) { Text(if (st > 0) "+$st" else "$st", fontSize = 13.sp) }
                            }
                        }
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("5.5", "6.0", "7.0", "8.0", "9.0", "10.0").forEach { v ->
                                AssistChip(onClick = { f1 = v }, label = { Text(v, fontSize = 12.sp) })
                            }
                        }
                        OutlinedTextField(value = f1, onValueChange = { f1 = it }, label = { Text("Ммоль/л (напр. 6.4)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("Натощак", "До еды", "30 мин после еды", "1 ч после еды", "1.5 ч после еды", "2 ч после еды", "3 ч после еды").forEach { tag ->
                                FilterChip(
                                    selected = gluNote == tag,
                                    onClick = { gluNote = if (gluNote == tag) "" else tag },
                                    label = { Text(tag, fontSize = 11.sp) }
                                )
                            }
                        }
                    }
                    "BP" -> {
                        val sVal = (f1.toIntOrNull() ?: 120).coerceIn(70, 230)
                        val dVal = (f2.toIntOrNull() ?: 80).coerceIn(40, 140)
                        val pVal = (f3.toIntOrNull() ?: 70).coerceIn(35, 160)
                        Text("$sVal / $dVal · $pVal уд/мин", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.align(Alignment.CenterHorizontally))
                        Text("SYS (верхнее): $sVal", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(onClick = { f1 = (sVal - 1).coerceIn(70, 230).toString() }, contentPadding = PaddingValues(0.dp), modifier = Modifier.width(42.dp)) { Text("-1") }
                            Slider(value = sVal.toFloat().coerceIn(80f, 220f), onValueChange = { f1 = kotlin.math.round(it).toInt().toString() }, valueRange = 80f..220f, modifier = Modifier.weight(1f))
                            OutlinedButton(onClick = { f1 = (sVal + 1).coerceIn(70, 230).toString() }, contentPadding = PaddingValues(0.dp), modifier = Modifier.width(42.dp)) { Text("+1") }
                        }
                        Text("DIA (нижнее): $dVal", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(onClick = { f2 = (dVal - 1).coerceIn(40, 140).toString() }, contentPadding = PaddingValues(0.dp), modifier = Modifier.width(42.dp)) { Text("-1") }
                            Slider(value = dVal.toFloat().coerceIn(50f, 130f), onValueChange = { f2 = kotlin.math.round(it).toInt().toString() }, valueRange = 50f..130f, modifier = Modifier.weight(1f))
                            OutlinedButton(onClick = { f2 = (dVal + 1).coerceIn(40, 140).toString() }, contentPadding = PaddingValues(0.dp), modifier = Modifier.width(42.dp)) { Text("+1") }
                        }
                        Text("Пульс: $pVal уд/мин", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(onClick = { f3 = (pVal - 1).coerceIn(35, 160).toString() }, contentPadding = PaddingValues(0.dp), modifier = Modifier.width(42.dp)) { Text("-1") }
                            Slider(value = pVal.toFloat().coerceIn(40f, 150f), onValueChange = { f3 = kotlin.math.round(it).toInt().toString() }, valueRange = 40f..150f, modifier = Modifier.weight(1f))
                            OutlinedButton(onClick = { f3 = (pVal + 1).coerceIn(35, 160).toString() }, contentPadding = PaddingValues(0.dp), modifier = Modifier.width(42.dp)) { Text("+1") }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedTextField(value = f1, onValueChange = { f1 = it }, label = { Text("SYS") }, modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(value = f2, onValueChange = { f2 = it }, label = { Text("DIA") }, modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(value = f3, onValueChange = { f3 = it }, label = { Text("Пульс") }, modifier = Modifier.weight(1f), singleLine = true)
                        }
                    }
                    "WEIGHT" -> {
                        val wVal = (f1.replace(",", ".").toDoubleOrNull() ?: 85.0).coerceIn(40.0, 180.0)
                        Text("${"%.1f".format(Locale.US, wVal)} кг", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.align(Alignment.CenterHorizontally))
                        Slider(
                            value = wVal.toFloat().coerceIn(60f, 130f),
                            onValueChange = { f1 = "%.1f".format(Locale.US, kotlin.math.round(it * 10.0) / 10.0) },
                            valueRange = 60f..130f
                        )
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(-0.5, -0.1, 0.1, 0.5).forEach { st ->
                                OutlinedButton(
                                    onClick = { f1 = "%.1f".format(Locale.US, (wVal + st).coerceIn(40.0, 180.0)) },
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(0.dp)
                                ) { Text(if (st > 0) "+$st" else "$st", fontSize = 13.sp) }
                            }
                        }
                        OutlinedTextField(value = f1, onValueChange = { f1 = it }, label = { Text("Вес в кг (напр. 85.4)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    }
                    "STEPS" -> {
                        val stVal = (f1.toIntOrNull() ?: 4000).coerceIn(0, 30000)
                        Text("$stVal шаг.", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.align(Alignment.CenterHorizontally))
                        Slider(
                            value = stVal.toFloat().coerceIn(0f, 20000f),
                            onValueChange = { f1 = (kotlin.math.round(it / 250f) * 250f).toInt().toString() },
                            valueRange = 0f..20000f
                        )
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(2000, 4000, 6000, 8000, 10000).forEach { v ->
                                AssistChip(onClick = { f1 = v.toString() }, label = { Text("$v", fontSize = 12.sp) })
                            }
                        }
                        OutlinedTextField(value = f1, onValueChange = { f1 = it }, label = { Text("Количество шагов") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    }
                    "SLEEP" -> {
                        val hVal = (f1.toIntOrNull() ?: 7).coerceIn(0, 14)
                        val mVal = (f2.toIntOrNull() ?: 0).coerceIn(0, 59)
                        Text("${hVal}ч ${mVal}м", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.align(Alignment.CenterHorizontally))
                        Text("Часы: $hVal", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        Slider(value = hVal.toFloat().coerceIn(0f, 12f), onValueChange = { f1 = kotlin.math.round(it).toInt().toString() }, valueRange = 0f..12f)
                        Text("Минуты:", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(0, 15, 30, 45).forEach { m ->
                                FilterChip(selected = mVal == m, onClick = { f2 = m.toString() }, label = { Text("$m мин", fontSize = 12.sp) }, modifier = Modifier.weight(1f))
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(value = f1, onValueChange = { f1 = it }, label = { Text("Часы") }, modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(value = f2, onValueChange = { f2 = it }, label = { Text("Минуты") }, modifier = Modifier.weight(1f), singleLine = true)
                        }
                    }
                }
            }
        }
    }

    if (showMedDirectoryDialog) {
        MedDirectoryDialog(
            medications = medicationsList,
            packages = packagesList,
            onEditMed = { editingMed = it },
            onSaveMed = onSaveMedItem,
            onDeleteMed = onDeleteMedItem,
            onSavePkg = onSavePackage,
            onDeletePkg = onDeletePackage,
            onAskGemini = onAskGeminiMed,
            useBackArrow = returnToAddOnBack,
            onDismiss = { showMedDirectoryDialog = false; if (returnToAddOnBack) showAddDialog = true; returnToAddOnBack = false }
        )
    }

    if (editingMed != null) {
        EditMedicationDialog(
            med = editingMed!!,
            onSave = { updated -> onSaveMedItem(updated); editingMed = null },
            onDelete = { onDeleteMedItem(editingMed!!); editingMed = null },
            onDismiss = { editingMed = null }
        )
    }

    if (showDirectoriesMenuDialog) {
        FullScreenDialog(
            title = "Справочники",
            useBackArrow = true,
            onDismiss = { showDirectoriesMenuDialog = false; showAddDialog = true; returnToAddOnBack = false }
        ) { innerPad ->
            Column(Modifier.fillMaxSize().padding(innerPad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Card(Modifier.fillMaxWidth().clickable {
                    showDirectoriesMenuDialog = false
                    returnToAddOnBack = true
                    showMedDirectoryDialog = true
                }) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("Таблетки и пакеты", fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                        Text("Редактирование препаратов, дозировок, пакетов приёма и остатков", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Card(Modifier.fillMaxWidth().clickable {
                    showDirectoriesMenuDialog = false
                    returnToAddOnBack = true
                    showFoodDirectoryDialog = true
                }) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("Еда (блюда и тарелки)", fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                        Text("Постоянные блюда (★), эталоны ХЕ и вес пустых тарелок", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }

    if (showNoteDialog) {
        var noteBody by remember { mutableStateOf("") }
        FullScreenDialog(
            title = "Заметка",
            useBackArrow = true,
            onDismiss = { showNoteDialog = false; showAddDialog = true; returnToAddOnBack = false },
            actions = {
                TextButton(onClick = {
                    if (noteBody.isNotBlank()) {
                        onAddVital(VitalType.NOTE, 0.0, null, null, noteBody.trim())
                        showNoteDialog = false
                        returnToAddOnBack = false
                    }
                }) { Text(s.save, fontWeight = FontWeight.SemiBold) }
            }
        ) { innerPad ->
            Column(Modifier.fillMaxSize().padding(innerPad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = noteBody,
                    onValueChange = { noteBody = it },
                    label = { Text("Состояние здоровья / симптомы") },
                    maxLines = 6,
                    modifier = Modifier.fillMaxWidth()
                )
                Button(onClick = {
                    if (noteBody.isNotBlank()) {
                        onAddVital(VitalType.NOTE, 0.0, null, null, noteBody.trim())
                        showNoteDialog = false
                        returnToAddOnBack = false
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text(s.save) }
            }
        }
    }

    if (showAddDialog) {
        QuickEntryDialog(
            s = s,
            userNorms = userNorms,
            initGlucose = latestGlucose?.value1 ?: 6.5,
            initSys = latestBp?.value1?.toInt() ?: 120,
            initDia = latestBp?.value2?.toInt() ?: 80,
            initPulse = latestBp?.pulse ?: 70,
            initInsulin = lastInsulinDose.toInt(),
            onOpenDirectories = { showAddDialog = false; returnToAddOnBack = true; showDirectoriesMenuDialog = true },
            onOpenFood = { showAddDialog = false; returnToAddOnBack = true; showFoodDialog = true },
            onOpenNote = { showAddDialog = false; returnToAddOnBack = true; showNoteDialog = true },
            onOpenPills = { showAddDialog = false; showQuickTakePicker = true },
            onDismiss = { showAddDialog = false },
            onSave = { type, v1, v2, p, note ->
                onAddVital(type, v1, v2, p, note)
                showAddDialog = false
            }
        )
    }

    if (showFoodDialog) {
        val recentFoods = remember(vitals, allHistoryVitals, foodDishes) {
            val savedNames = foodDishes.map { it.name.trim().lowercase() }.toSet()
            (vitals + allHistoryVitals)
                .filter { it.type == VitalType.FOOD && it.note.isNotBlank() }
                .map { entry ->
                    var clean = entry.note.trim()
                    listOf("Завтрак:", "Обед:", "Ужин:", "Перекус:").forEach { pfx ->
                        if (clean.startsWith(pfx)) clean = clean.removePrefix(pfx).trim()
                    }
                    clean to entry.value1
                }
                .filter { it.first.isNotBlank() && it.first.lowercase() !in savedNames }
                .distinctBy { it.first.lowercase() }
                .take(8)
        }
        FoodEntryDialog(
            s = s,
            useBackArrow = returnToAddOnBack,
            hasGeminiKey = initialGeminiKey.isNotBlank(),
            foodDishes = foodDishes,
            recentFoods = recentFoods,
            foodPlates = foodPlates,
            onOpenGeminiSettings = { showFoodDialog = false; settingsInitialTab = 2; showSettingsDialog = true },
            onSaveDish = onSaveFoodDish,
            onDeleteDish = onDeleteFoodDish,
            onSavePlate = onSaveFoodPlate,
            onDeletePlate = onDeleteFoodPlate,
            onAnalyzeFoodPhoto = onAnalyzeFoodPhoto,
            onAnalyzeFoodText = onAnalyzeFoodText,
            onIdentifyPlatePhoto = onIdentifyPlatePhoto,
            onDismiss = { showFoodDialog = false; if (returnToAddOnBack) showAddDialog = true; returnToAddOnBack = false },
            onSave = { xeVal, note ->
                onAddVital(VitalType.FOOD, xeVal, null, null, note)
                showFoodDialog = false
                returnToAddOnBack = false
            }
        )
    }

    if (customEntryTarget != null) {
        val (key, lbl, unit) = customEntryTarget!!
        var valStr by remember(key) { mutableStateOf("") }
        FullScreenDialog(
            title = "$lbl ${if (unit.isNotBlank()) "($unit)" else ""}".trim(),
            onDismiss = { customEntryTarget = null },
            actions = {
                TextButton(onClick = {
                    val v = valStr.replace(",", ".").toDoubleOrNull() ?: return@TextButton
                    onAddVital(VitalType.CUSTOM, v, null, null, "$key|$lbl|$unit")
                    customEntryTarget = null
                }) { Text(s.save, fontWeight = FontWeight.SemiBold) }
            }
        ) { innerPad ->
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(innerPad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                val cNum = (valStr.replace(",", ".").toDoubleOrNull() ?: 0.0).coerceIn(0.0, 200.0)
                Text("${"%.1f".format(Locale.US, cNum)} $unit".trim(), fontSize = 32.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.align(Alignment.CenterHorizontally))
                Slider(value = cNum.toFloat(), onValueChange = { valStr = "%.1f".format(Locale.US, kotlin.math.round(it * 10.0) / 10.0) }, valueRange = 0f..200f)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(-10.0, -1.0, 1.0, 10.0).forEach { st ->
                        OutlinedButton(onClick = { valStr = "%.1f".format(Locale.US, (cNum + st).coerceAtLeast(0.0)) }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(0.dp)) {
                            Text(if (st > 0) "+${st.toInt()}" else "${st.toInt()}", fontSize = 12.sp)
                        }
                    }
                }
                OutlinedTextField(value = valStr, onValueChange = { valStr = it }, label = { Text("Значение ($unit)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            }
        }
    }

    if (customHistoryTile != null) {
        val ct = customHistoryTile!!
        val list = allHistoryVitals.filter { it.type == VitalType.CUSTOM && (it.note.startsWith("${ct.id}_TOP|") || it.note.startsWith("${ct.id}_BOT|")) }
        FullScreenDialog(title = "История: ${ct.topLabel}", onDismiss = { customHistoryTile = null }) { innerPad ->
            LazyColumn(Modifier.fillMaxSize().padding(innerPad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (list.isEmpty()) item { Text(s.noData, fontSize = 14.sp) }
                else items(list) { item ->
                    val (txt, col, wt) = formatVitalRow(item, userNorms, s)
                    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${shortTimeFmt.format(Date(item.timestamp))} · $txt", fontSize = 13.sp, color = col ?: MaterialTheme.colorScheme.onSurface, fontWeight = wt)
                        Text(shortSourceLabel(item.source), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    HorizontalDivider()
                }
            }
        }
    }

    if (showTileConstructor) {
        TileConstructorDialog(
            tileOrder = tileOrder,
            customTiles = customTiles,
            onSaveOrder = onSaveTileOrder,
            onSaveCustom = onSaveCustomTiles,
            onDismiss = { showTileConstructor = false }
        )
    }

    if (showWeatherDialog) {
        WeatherFullScreenDialog(
            city = userProfile.city.ifBlank { s.cityDefault },
            dailyContext = dailyContext,
            weatherLogs = weatherLogs,
            weatherForecast = weatherForecast,
            onRefresh = onRefreshWeather,
            onDismiss = { showWeatherDialog = false }
        )
    }

    if (viewingPackage != null) {
        val pkg = viewingPackage!!
        val ids = pkg.medIdsCsv.split(",").mapNotNull { it.toLongOrNull() }.toSet()
        val pkgMeds = medicationsList.filter { it.id in ids }
        FullScreenDialog(
            title = "${pkg.name} (${pkg.scheduleTime})",
            onDismiss = { viewingPackage = null },
            actions = {
                TextButton(onClick = {
                    val txt = pkgMeds.joinToString("\n") { "• ${it.name} ${it.dosage} — ${it.countPerIntake} шт" }
                    clipboard.setText(AnnotatedString("${pkg.name} (${pkg.scheduleTime}):\n$txt"))
                }) { Text("Копировать") }
            }
        ) { innerPad ->
            LazyColumn(
                Modifier.fillMaxSize().padding(innerPad).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (pkgMeds.isEmpty()) item { Text("В пакете нет препаратов", fontSize = 14.sp) }
                else items(pkgMeds) { m ->
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("• ${m.name} ${m.dosage} — ${m.countPerIntake} шт", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        if (m.effect.isNotBlank()) Text(m.effect, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    HorizontalDivider(Modifier.padding(top = 6.dp))
                }
            }
        }
    }

    if (historyCategory != null) {
        val (hTitle, hDesc) = when (historyCategory) {
            0 -> "История: Сахар и Инсулин" to "Показания глюкометра Contour Plus (BLE), дозы инсулина и ручной ввод."
            1 -> "История: Давление и Пульс" to "Показания тонометра Omron (BLE), Health Connect и ручной ввод."
            2 -> "История: Вес и Вода" to "Взвешивания (BLE MI_SCALE / Health Connect) и выпитая вода."
            4 -> "История: Питание" to "Приёмы пищи, блюда и расчёт ХЕ."
            else -> "История: Шаги и Сон" to "Дневная сводка из Samsung Health → Health Connect или ручного ввода."
        }
        val types = when (historyCategory) {
            0 -> setOf(VitalType.GLUCOSE, VitalType.INSULIN)
            1 -> setOf(VitalType.BP)
            2 -> setOf(VitalType.WEIGHT, VitalType.WATER)
            4 -> setOf(VitalType.FOOD)
            else -> emptySet()
        }
        val filtered = allHistoryVitals.filter { it.type in types }.take(30)
        FullScreenDialog(title = hTitle, onDismiss = { historyCategory = null }) { innerPad ->
            LazyColumn(
                Modifier.fillMaxSize().padding(innerPad).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Text(hDesc, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(10.dp))
                    }
                }
                if (historyCategory == 3) {
                    if (allDailyContexts.isEmpty()) item { Text(s.noData, fontSize = 14.sp) }
                    else items(allDailyContexts) { dc ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${dc.dateKey} · Шаги: ${dc.steps} · Сон: ${dc.sleepMinutes / 60}ч ${dc.sleepMinutes % 60}м", fontSize = 13.sp)
                            Text("HC", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        HorizontalDivider()
                    }
                } else {
                    if (filtered.isEmpty()) item { Text(s.noData, fontSize = 14.sp) }
                    else items(filtered) { item ->
                        val (txt, col, wt) = formatVitalRow(item, userNorms, s)
                        Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${shortTimeFmt.format(Date(item.timestamp))} · $txt", fontSize = 13.sp, color = col ?: MaterialTheme.colorScheme.onSurface, fontWeight = wt)
                            Text(shortSourceLabel(item.source), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        HorizontalDivider()
                    }
                }
            }
        }
    }

    if (showChangelogDialog) {
        FullScreenDialog(title = s.changelogTitle, onDismiss = { showChangelogDialog = false }) { innerPad ->
            LazyColumn(
                Modifier.fillMaxSize().padding(innerPad).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Text("Полная версия: v59.261119 by mizgiroff", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text("Совместимость: Android 8.0 (API 26) и выше (целевая: Android 15 / API 35)", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                    HorizontalDivider(Modifier.padding(vertical = 6.dp))
                }
                item {
                    Text("v59.261119 (19.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("• В замерах сахара (при вводе и по длинному тапу в хронике на BLE-замер) добавлены чипы: Натощак, До еды, 30 мин / 1 ч / 1.5 ч / 2 ч / 3 ч после еды.", fontSize = 12.sp)
                    Text("• При нажатии «Принял» на напоминании (или в +Приём) для инсулинового препарата («Тожео СолоСтар») его доза в ЕД автоматически записывается на плитку «Инсулин».", fontSize = 12.sp)
                    HorizontalDivider()
                    Text("v58.261119 (19.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("• Единая подсветка плиток при выходе за норму (сахар, АД/пульс, АД < 125): подсвечивается фон всей карточки (#FFCDD2 светло-красный днём и #4A1820 ночью), цифры остаются контрастными.", fontSize = 12.sp)
                    HorizontalDivider()
                    Text("v57.261119 (19.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("• Лента «ИИ-совет» перенесена в низ страницы (под Хронологию дня, прямо над нижней панелью управления).", fontSize = 12.sp)
                    Text("• Усилен фильтр очереди тонометра Omron: если в одном сеансе пришло несколько замеров с одинаковым временем (±2 мин), берётся только последний (даже при hasTime = true).", fontSize = 12.sp)
                    HorizontalDivider()
                    Text("v56.261119 (19.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("• Исправлена подсветка плиток при АД < 125 в тёмной теме (тёмно-бордовый фон #4A1820 вместо светло-розового, чтобы белый текст был чётко виден).", fontSize = 12.sp)
                    Text("• Очередь старых замеров тонометра Omron без времени прибора фильтруется до последнего замера, а кэш дублей АД расширен до 48 часов (не сбрасывается в полночь).", fontSize = 12.sp)
                    HorizontalDivider()
                    Text("v55.261118 (18.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("• Ввод «Инсулин (ЕД)» теперь автоматически засчитывает приём инсулиновых препаратов («Тожео СолоСтар» и др.), убирает их уведомление и отменяет повторы.", fontSize = 12.sp)
                    HorizontalDivider()
                    Text("v54.261118 (18.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("• Звуковой антидубль (5 сек) для одновременных напоминаний (например, Тожео + Вечерние таблетки): уведомления выводятся для всех, но сигнал звучит один раз без наложения.", fontSize = 12.sp)
                    HorizontalDivider()
                    Text("v53.261118 (18.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("• Отключён верхний шрифтовой отступ (includeFontPadding = false + LineHeightStyle.Center) в плашках и кнопках — буквы строго по центру по вертикали.", fontSize = 12.sp)
                    Text("• В MetricTile жёсткая высота height(22.dp)/height(24.dp) заменена на heightIn(min = ...), чтобы в режиме «Крупный интерфейс» плашки не обрезались снизу.", fontSize = 12.sp)
                    HorizontalDivider()
                    Text("v52.261118 (18.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("• Усиленная защита от повторов тонометра Omron: проверка по всем замерам АД за 12 часов + дневной кэш отпечатков (удалённые дубли не возвращаются).", fontSize = 12.sp)
                    Text("• Выравнивание текста в кнопках и плашках по центру горизонтали и вертикали (особенно в режиме «Крупный интерфейс»).", fontSize = 12.sp)
                    HorizontalDivider()
                    Text("v51.261118 (18.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("• Окно фильтрации повторных замеров тонометра Omron с теми же SYS/DIA/пульсом расширено с 30 минут до 12 часов (в пределах дня) + логирование hasTime в 0x2A35.", fontSize = 12.sp)
                    HorizontalDivider()
                    Text("v50.261118 (18.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("• Защита от повторного приёма того же замера АД с тонометра Omron каждые 2 минуты (проверка совпадения SYS/DIA/пульс в окне 30 мин + 5-мин пауза переподключения).", fontSize = 12.sp)
                    HorizontalDivider()
                    Text("v49.261118 (18.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("• Считывание реального времени замера из глюкометра (0x2A18) и 15-сек переподключение в фоне.", fontSize = 12.sp)
                    Text("• Исключено дублирование будильников и повторов между пакетами и входящими в них препаратами (проверка БД перед каждым показом).", fontSize = 12.sp)
                    Text("• Ползунок паузы между сигналами при повторе (100–1000 мс, по умолч. 250 мс) + кнопка «Тест 2×».", fontSize = 12.sp)
                    HorizontalDivider()
                    Text("v48.261117 (17.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("• Полноэкранный диалог с ИИ по длинному тапу на плашку «ИИ-совет» (с контекстом всех показателей дня, историей переписки и кнопкой «Копировать»).", fontSize = 12.sp)
                    HorizontalDivider()
                    Text("v47.261117 (17.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("• Плитка «Питание» показывает название последнего блюда без префикса «Обед:».", fontSize = 12.sp)
                    Text("• Кнопка «+Принял» переименована в «+Приём», а счётчики приёмов пишутся полным словом (1 приём, 2 приёма, 5 приёмов).", fontSize = 12.sp)
                    Text("• Верхняя строка даты (< dd.MM >) и погоды выровнена по 11.sp и уплотнена (без лишних пробелов вокруг точек).", fontSize = 12.sp)
                    Text("• Живые подсказки «ИИ-совет» на главном экране (при наличии ключа Gemini) с переключателем Вкл/Выкл в Настройки → ИИ / HA.", fontSize = 12.sp)
                    HorizontalDivider()
                    Text("v46.261117 (17.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("• Уведомление и отдельный настраиваемый сигнал (мелодия + громкость) при приёме данных от приборов BLE (глюкометр, тонометр, весы).", fontSize = 12.sp)
                    Text("• Выбор дробной дозы (0.25, 0.5, 1, 1.5, 2 шт и ручной ввод) при ручном приёме лекарства в «+Принял».", fontSize = 12.sp)
                    Text("• Короткие примечания по длинному тапу теперь работают и для приёмов таблеток/пакетов в Хронологии дня (Room MIGRATION_8_9).", fontSize = 12.sp)
                    HorizontalDivider()
                    Text("v45.261117 (17.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("• Вечерняя проверка дня (по умолч. 21:00) с галочкой и выбором времени в Настройках: итог «всё принято» или список пропущенного.", fontSize = 12.sp)
                    Text("• Будильники для пакетов лекарств, автоперепланирование при старте, точный запуск повторов и кнопка перехода к разрешению точных будильников.", fontSize = 12.sp)
                    Text("• Ползунок громкости звуковых уведомлений (10%–100%).", fontSize = 12.sp)
                    Text("• Адаптивный «Крупный интерфейс»: 1 плитка в ширину, объединение нижних иконок в кнопку «Меню» и увеличенные шрифты внутри всех окон.", fontSize = 12.sp)
                    Text("• В «О программе» указана минимальная версия Android (8.0+).", fontSize = 12.sp)
                    HorizontalDivider()
                    Text("v44.261117 (17.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("• Повтор сигнала уведомлений о лекарствах каждые N мин (1→2→3→4 раза) с итоговым сообщением «Препараты не приняты».", fontSize = 12.sp)
                    Text("• Хронология дня сортируется от утра к вечеру (живая картина) с автопрокруткой вниз к свежим событиям.", fontSize = 12.sp)
                    Text("• Бегущая строка погоды справа от неподвижной даты (< dd.MM >).", fontSize = 12.sp)
                    HorizontalDivider()
                    Text("v43.261117 (17.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("• Исправлена ошибка компиляции v42 в MainActivity (переключатель дней).", fontSize = 12.sp)
                    Text("• Добавлены короткие сигналы уведомлений (Колокольчик, Пинг, Тройной, Системный, Без звука) с прослушиванием и выбором в Настройки → Интерф.", fontSize = 12.sp)
                    HorizontalDivider()
                    Text("v42.261117 (17.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("• Нижняя панель управления: логотип, версия, иконки и кнопка «+» перенесены вниз под большой палец.", fontSize = 12.sp)
                    Text("• Сверху оставлена компактная строка с переключателем дней (< dd.MM >) и погодой.", fontSize = 12.sp)
                    Text("• Во всех полноэкранных окнах и меню шапка с кнопкой «Сохранить» перенесена вниз (✕/← слева, «Сохранить» справа).", fontSize = 12.sp)
                    HorizontalDivider()
                    Text("v41.261117 (17.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("• Углублённые Настройки (4 вкладки): Профиль, Приложение, ИИ / HA (с объяснением пользы ИИ, инструкцией/ссылкой и кнопкой «Отправить замеры в HA») и Интерфейс (Дневная/Ночная тема + «Крупный интерфейс»).", fontSize = 12.sp)
                    Text("• Кнопка «Копировать» добавлена во все меню по длинному тапу (хроника, приёмы лекарств, пакеты, блюда, тарелки).", fontSize = 12.sp)
                    Text("• Обновлена контурная иконка уведомления MedMonitorService с синим акцентом и более насыщенный логотип.", fontSize = 12.sp)
                    HorizontalDivider()
                    Text("v40.261117 (17.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("• Стабилизация весов MI_SCALE (2-сек буфер): промежуточные значения вроде 92.5 кг отсеиваются, сохраняется только итоговый вес (94.3 кг).", fontSize = 12.sp)
                    HorizontalDivider()
                    Text("v39.261117 (17.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("• Автоматическое фоновое подключение и считывание весов MI_SCALE в MedMonitorService (без нажатия «Считать»).", fontSize = 12.sp)
                    HorizontalDivider()
                    Text("v38.261117 (17.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("• Надпись v38 by mizgiroff сдвинута чуть левее к MedAssist; выровнены интервалы в Хронологии дня.", fontSize = 12.sp)
                    Text("• Меню «+» в 2 ряда (1-й ряд: Справочники, Еда, Заметка — открываются в новых окнах со стрелкой «Назад»; 2-й ряд: Сахар, АД, Инсулин, Таблетки).", fontSize = 12.sp)
                    Text("• Графический ввод (ползунки, кнопки ± и быстрые чипы) добавлен во все числовые поля ввода.", fontSize = 12.sp)
                    HorizontalDivider()
                    Text("v37.261117 (17.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("• Хронология дня возвращена на главный экран под плитками.", fontSize = 12.sp)
                    Text("• 6-я плитка переделана под «Лекарства» (кнопка «+Принял», счётчик приёмов, последний препарат).", fontSize = 12.sp)
                    Text("• Кнопка «В HA» перенесена в верхнюю шапку слева от значка Bluetooth.", fontSize = 12.sp)
                    Text("• В меню «+» добавлен раздел «Справочники» (Таблетки и Еда).", fontSize = 12.sp)
                    HorizontalDivider()
                    Text("v36.261117 (17.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("• Звёздочка (★) для постоянных блюд: закрепление в начале «Частых блюд» и Справочника.", fontSize = 12.sp)
                    Text("• Умный расчёт ХЕ в ИИ: учёт доли молока в напитках, вычет мяса в смешанных блюдах, передача личных эталонов и расчёт ХЕ по тексту без фото.", fontSize = 12.sp)
                    Text("• Личная калибровка: автоматический пропорциональный пересчёт ХЕ при изменении веса Нетто.", fontSize = 12.sp)
                    Text("• Графический быстрый ввод (ползунки, кнопки ± и чипы) для Сахара, АД/Пульса, Веса, Инсулина, Шагов и Сна.", fontSize = 12.sp)
                    Text("• Время обновления (dd.MM HH:mm · HC/Ручн.) на плитке «Шаги / Сон» (Room MIGRATION_7_8).", fontSize = 12.sp)
                    HorizontalDivider()
                    Text("v35.261117 (17.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("• Исправлена дедупликация сахара по BLE: порог сравнения снижен с 0.5 до 0.05 ммоль/л (близкие замеры вроде 8.3 и 8.4 больше не отбрасываются).", fontSize = 12.sp)
                    Text("• Аккуратное сокращение текста на плитке «Хронология» без обрезки на «ммоль/».", fontSize = 12.sp)
                    HorizontalDivider()
                    Text("v34.261117 (17.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("• Сине-жёлтая волна в шапке теперь проходит по всей строке: логотип + MedAssist + v34 by mizgiroff.", fontSize = 12.sp)
                    Text("• Короткий формат имени файла сборки (MedAssist_MVP_v34_261117.zip) для удобного отображения в GitHub.", fontSize = 12.sp)
                    HorizontalDivider()
                    Text("v261116.33 (16.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("• Сетка 3×2 (6 плиток): добавлены плитки «Питание» (ХЕ за день и кнопка +Еда) и «Хронология дня» (счётчик записей и кнопка «Копировать»).", fontSize = 12.sp)
                    Text("• Хронология дня вынесена с главного экрана в отдельное полноэкранное окно без обрезки длинных названий блюд.", fontSize = 12.sp)
                    HorizontalDivider()
                    Text("v261116.32 (16.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("• Отдельное полноэкранное окно «Еда» (шапка без лишних вкладок, кнопка «Справочник»).", fontSize = 12.sp)
                    Text("• Поле «Уточнение для ИИ» для добавления продуктов к фото (напр. кабачки 50г) с пересчётом ХЕ.", fontSize = 12.sp)
                    Text("• Долгий тап по чипам «Частые блюда» и «Тарелки» для редактирования и удаления.", fontSize = 12.sp)
                    Text("• Справочник блюд и тарелок с добавлением, правкой и удалением.", fontSize = 12.sp)
                    HorizontalDivider()
                    Text("v261116.30 (16.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("+ Добавлено: быстрый выбор «Частые блюда» из истории в окне «Еда» (1 тап), убрано лишнее слово «Еда:» перед Завтрак/Обед/Ужин/Перекус в хронике, убрано дублирование названия блюда от ИИ.", fontSize = 12.sp)
                }
                item {
                    Text("v261116.29 (16.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("+ Добавлено: конструктор плиток (добавление, редактирование, скрытие стандартных и удаление пользовательских плиток с 1–2 показателями, единицами и нормами) — доступен из Настроек и при долгом нажатии на любую плитку.", fontSize = 12.sp)
                }
                item {
                    Text("v261116.28 (16.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("+ Добавлено: поддержка литров и миллилитров в «Еде» (0.5л → 500 мл, 250мл, быстрые чипы объёма 200/250/330/500 мл), компактная шапка (4 иконки 19.dp в один уровень с MedAssist, расширенная погода во всю ширину с ощущаемой температурой, влажностью и ветром), прогноз погоды на сегодня/завтра в окне «Погода».", fontSize = 12.sp)
                }
                item {
                    Text("v261116.27 (16.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("+ Добавлено: автозапуск распознавания еды сразу после съёмки или выбора фото, выбор приёма пищи (Завтрак / Обед / Ужин / Перекус) с автоподбором по времени суток, компактный однострочный вывод записей в «Хронологии дня» (полный текст по длинному тапу).", fontSize = 12.sp)
                }
                item {
                    Text("v261116.25 (16.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("+ Исправлено: автоповорот фото по EXIF (чтобы не крутило набок), увеличен предпросмотр фото до 240–380.dp и гарантированно включён автоперебор резервных моделей Gemini (3.8-flash → 3.5-flash-lite → 2.5-flash-lite → 2.5-flash).", fontSize = 12.sp)
                }
                item {
                    Text("v261116.24 (16.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("+ Добавлено: автоматический выбор резервной бесплатной модели Gemini (3.8-flash → 3.5-flash-lite → 2.5-flash-lite → 2.5-flash) при временной перегрузке сервера (HTTP 503/429).", fontSize = 12.sp)
                }
                item {
                    Text("v261116.23 (16.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("+ Добавлено: кликабельная ссылка на инструкцию по получению бесплатного Gemini API Key и быстрый переход в «Настройки → HA / ИИ» прямо из окон «Новая тарелка» и «Еда», если ключ ещё не задан.", fontSize = 12.sp)
                }
                item {
                    Text("v261116.19 (16.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("+ Добавлено: поддержка новых ключей Google AI Studio (AQ.Ab8... и AIza...) через заголовок x-goog-api-key, таймаут 35 сек и подробный лог [AI], полноэкранные окна для «Новая тарелка», «Инсулин», «Быстрый ввод» и «Состав пакета», кнопка «Распознать по фото (ИИ)» и инструкция по получению ключа прямо в Настройках.", fontSize = 12.sp)
                }
                item {
                    Text("v261116.18 (16.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("+ Добавлено: считывание веса с дисплея кухонных весов по фото в «+ Тарелка» и в «Еде», автоматический подбор сохранённой тарелки по фото блюда, расчёт нетто и ХЕ в один тап.", fontSize = 12.sp)
                }
                item {
                    Text("v261116.17 (16.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("+ Добавлено: фото и автоопределение типа/названия тарелки через базовый Gemini API в «Новой тарелке» с сохранением фото в базу, попиксельная стандартизация строк всех 4 плиток и единый формат даты dd.MM на «Шаги / Сон».", fontSize = 12.sp)
                }
                item {
                    Text("v261116.16 (16.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("+ Добавлено: полноэкранное окно «Новый замер» (+), заметная кнопка «Выход» в шапке и внизу всех вкладок настроек, полноэкранное окно «Погода и давление» с историей в БД (weather_logs), привязка краткой погоды к каждому замеру АД, просмотр состава пакета по длинному тапу в «Лекарства сегодня», умный учёт еды (справочник тарелок с вычетом тары, фото блюда и авторасчёт ХЕ через базовый Gemini API).\n~ Исправлено: сокращена дата в шапке погоды, чтобы «ясно / облачно / дождь / снег» не обрезалось.", fontSize = 12.sp)
                }
                item {
                    Text("v261116.12 (16.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("+ Добавлено: единый крупный размер (18.sp) всех 8 значений на плитках, увеличенный шрифт даты/источника (10.sp), история для плитки «Шаги / Сон» и описания на всех экранах истории, короткое примечание к записи в хронике по длинному тапу, полноэкранное компактное окно «Отметить приём», заметки о состоянии здоровья в «+», кнопка принудительного выхода (остановить BLE) в настройках.\n~ Исправлено: пауза 90 сек после BLE-чтения (устранён цикл тонометра и глюкометра), дедупликация сахара, мгновенный сброс уведомлений при отметке приёма.", fontSize = 12.sp)
                }
                item {
                    Text("v261115.11 (15.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("+ Добавлено: редактирование пакетов таблеток по нажатию в справочнике, выравнивание строки «Лекарства сегодня» с тремя овальными кнопками (+Принял, Справочник, В HA), визуально активные тактильные кнопки с анимацией сжатия при нажатии.", fontSize = 12.sp)
                }
                item {
                    Text("v261115.10 (15.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("+ Добавлено: единая хронология дня (новые события сверху), кнопка компактного копирования суточного журнала, шестерёнка привязки прибора по центру активированной плитки, единый овальный стиль кнопок в «Лекарства сегодня», предзаполнение справочника личными препаратами и пакетами.", fontSize = 12.sp)
                }
                item {
                    Text("v261115.09 (15.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("+ Добавлено: единый 4-строчный формат всех плиток (интерактивные ссылки + дата/источник сверху, значение отдельно снизу), однострочная шапка «Лекарства сегодня» с пакетами внутри «+Принял», удаление лишней записи в хронике по длительному нажатию, дедупликация АД из Health Connect.", fontSize = 12.sp)
                }
                item {
                    Text("v261115.08 (15.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text(
                        "+ Добавлено: полноэкранные окна, чистый список в «Справочнике» с кнопкой «+», графический выбор времени (TimePicker), режим приёма «По необходимости», кнопки быстрого ручного ввода на всех 4 плитках (+Сах., +АД, +Вес, +Шаги, +Сон).\n" +
                        "~ Исправлено: приём всей очереди замеров тонометра Omron без обрыва после первого пакета, парсинг времени 0x2A35, дедупликация дублей АД, автоперезапуск фонового BLE-ожидания, одинаковый компактный размер всех 4 плиток.",
                        fontSize = 12.sp
                    )
                }
                item {
                    Text("v261115.07 (15.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text(
                        "+ Добавлено: отдельный «Справочник лекарств» (пустой на старте), выбор дозировок кнопками в помощнике/Gemini, подробное описание препаратов, пакеты таблеток, редактирование по длительному нажатию.",
                        fontSize = 12.sp
                    )
                }
                item {
                    Text("v261115.06 (15.11.2026)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("+ Добавлено: фоновый сервис, напоминания, кнопка «+Инс.», раздельное время на плитках.", fontSize = 12.sp)
                }
            }
        }
    }

    if (showLogsDialog) LogsDialog(onDismiss = { showLogsDialog = false })

    if (showBleDialog) {
        DeviceManagerDialog(
            pinnedDevices = pinnedDevices,
            bleDevices = bleDevices,
            isScanning = isScanningBle,
            onStartScan = onStartBleScan,
            onPinAndConnect = onPinAndConnectDevice,
            onReadPinned = onReadPinnedDevice,
            onUnpin = onUnpinDevice,
            onSyncWatch = onSyncHealthConnect,
            onDismiss = { showBleDialog = false }
        )
    }

    if (showSettingsDialog) {
        SettingsDialog(
            s = s,
            initialUrl = initialHaUrl,
            initialToken = initialHaToken,
            initialGeminiKey = initialGeminiKey,
            initialProfile = userProfile,
            initialNorms = userNorms,
            initialLang = appLang,
            initialThemeMode = initialThemeMode,
            initialLargeUi = initialLargeUi,
            initialNotifSound = initialNotifSound,
            initialNotifRepeatMin = initialNotifRepeatMin,
            initialNotifVolume = initialNotifVolume,
            initialDailyCheckEnabled = initialDailyCheckEnabled,
            initialDailyCheckTime = initialDailyCheckTime,
            initialBleSound = initialBleSound,
            initialBleVolume = initialBleVolume,
            initialAiAdviceEnabled = initialAiAdviceEnabled,
            initialNotifGapMs = initialNotifGapMs,
            initialTab = settingsInitialTab,
            onSyncHa = onSyncHa,
            onExportBackup = onExportBackup,
            onImportBackup = onImportBackup,
            onOpenChangelog = { showSettingsDialog = false; showChangelogDialog = true },
            onForceExit = onForceExit,
            onOpenTileConstructor = { showSettingsDialog = false; showTileConstructor = true },
            onDismiss = { showSettingsDialog = false; settingsInitialTab = 0 },
            onSave = { url, tok, gKey, prof, nrm, lng, tm, lg, snd, repMin, vol, dcEn, dcTime, bSnd, bVol, aiAdv, gap ->
                onSaveSettings(url, tok, gKey, prof, nrm, lng)
                onSaveUiPrefs(tm, lg, snd, repMin, vol, dcEn, dcTime, bSnd, bVol, aiAdv, gap)
                showSettingsDialog = false
                settingsInitialTab = 0
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FullScreenDialog(
    title: String,
    onDismiss: () -> Unit,
    useBackArrow: Boolean = false,
    actions: @Composable RowScope.() -> Unit = {},
    floatingActionButton: @Composable () -> Unit = {},
    content: @Composable (PaddingValues) -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        val isLarge = LocalLargeUi.current
        val baseD = LocalDensity.current
        val dlgD = remember(baseD, isLarge) { Density(baseD.density, fontScale = if (isLarge) baseD.fontScale * 1.28f else baseD.fontScale) }
        CompositionLocalProvider(LocalDensity provides dlgD) {
        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Scaffold(
                bottomBar = {
                    Surface(color = MaterialTheme.colorScheme.surface, tonalElevation = 3.dp) {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .navigationBarsPadding()
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = onDismiss) {
                                Icon(
                                    if (useBackArrow) Icons.Default.ArrowBack else Icons.Default.Close,
                                    contentDescription = if (useBackArrow) "Назад" else "Закрыть"
                                )
                            }
                            Text(
                                title,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f).padding(horizontal = 4.dp)
                            )
                            Row(verticalAlignment = Alignment.CenterVertically, content = actions)
                        }
                    }
                },
                floatingActionButton = floatingActionButton
            ) { innerPadding ->
                Box(Modifier.fillMaxSize().statusBarsPadding()) {
                    content(innerPadding)
                }
            }
        }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TimePickerField(
    scheduleTime: String,
    onScheduleChange: (String) -> Unit
) {
    val isPrn = scheduleTime.isBlank() || scheduleTime.contains("необходим", ignoreCase = true)
    var showPicker by remember { mutableStateOf(false) }

    val parsedParts = scheduleTime.split(":")
    val initHour = parsedParts.getOrNull(0)?.toIntOrNull()?.coerceIn(0, 23) ?: 8
    val initMin = parsedParts.getOrNull(1)?.toIntOrNull()?.coerceIn(0, 59) ?: 30

    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            FilterChip(
                selected = !isPrn,
                onClick = { if (isPrn) onScheduleChange("08:30") },
                label = { Text("По графику", fontSize = 11.sp) }
            )
            FilterChip(
                selected = isPrn,
                onClick = { onScheduleChange("По необходимости") },
                label = { Text("По необходимости", fontSize = 11.sp) }
            )
        }
        if (!isPrn) {
            OutlinedButton(
                onClick = { showPicker = true },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Schedule, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Время приёма: ${"%02d:%02d".format(initHour, initMin)}", fontSize = 13.sp)
            }
        }
    }

    if (showPicker) {
        val state = rememberTimePickerState(initialHour = initHour, initialMinute = initMin, is24Hour = true)
        AlertDialog(
            onDismissRequest = { showPicker = false },
            title = { Text("Выберите время", fontSize = 16.sp) },
            text = { TimePicker(state = state) },
            confirmButton = {
                TextButton(onClick = {
                    onScheduleChange("%02d:%02d".format(state.hour, state.minute))
                    showPicker = false
                }) { Text("OK") }
            },
            dismissButton = {
                TextButton(onClick = { showPicker = false }) { Text("Отмена") }
            }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MedDirectoryDialog(
    useBackArrow: Boolean = false,
    medications: List<MedicationItem>,
    packages: List<MedPackage>,
    onEditMed: (MedicationItem) -> Unit,
    onSaveMed: (MedicationItem) -> Unit,
    onDeleteMed: (MedicationItem) -> Unit,
    onSavePkg: (MedPackage) -> Unit,
    onDeletePkg: (MedPackage) -> Unit,
    onAskGemini: suspend (String) -> MedSuggestion?,
    onDismiss: () -> Unit
) {
    var tab by remember { mutableStateOf(0) }
    var showAddMed by remember { mutableStateOf(false) }
    var showAddPkg by remember { mutableStateOf(false) }
    var editingPkg by remember { mutableStateOf<MedPackage?>(null) }
    val haptic = LocalHapticFeedback.current

    FullScreenDialog(
        title = "Справочник лекарств",
        useBackArrow = useBackArrow,
        onDismiss = onDismiss,
        actions = {
            IconButton(onClick = { if (tab == 0) showAddMed = true else showAddPkg = true }) {
                Icon(Icons.Default.Add, contentDescription = "Добавить")
            }
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { if (tab == 0) showAddMed = true else showAddPkg = true }) {
                Icon(Icons.Default.Add, contentDescription = "Добавить")
            }
        }
    ) { innerPad ->
        Column(Modifier.fillMaxSize().padding(innerPad)) {
            TabRow(selectedTabIndex = tab) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Препараты (${medications.size})", fontSize = 13.sp) })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Пакеты (${packages.size})", fontSize = 13.sp) })
            }
            if (tab == 0) {
                if (medications.isEmpty()) {
                    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Справочник препаратов пуст", fontSize = 15.sp, fontWeight = FontWeight.Medium)
                            Text("Нажмите «+», чтобы добавить препарат с помощью словаря или ИИ", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Button(onClick = { showAddMed = true }) { Text("+ Добавить препарат") }
                        }
                    }
                } else {
                    LazyColumn(
                        Modifier.fillMaxSize().padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(medications) { m ->
                            Card(
                                Modifier.fillMaxWidth().combinedClickable(
                                    onClick = {},
                                    onLongClick = {
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        onEditMed(m)
                                    }
                                )
                            ) {
                                Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                        Text("${m.name} ${m.dosage} · ${m.scheduleTime}", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                        if (m.effect.isNotBlank()) Text(m.effect, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text("По ${m.countPerIntake} шт · остаток: ${m.stockLeft} шт (удерж. для ред.)", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                                    }
                                    IconButton(onClick = { onDeleteMed(m) }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Удалить")
                                    }
                                }
                            }
                        }
                        item { Spacer(Modifier.height(72.dp)) }
                    }
                }
            } else {
                if (packages.isEmpty()) {
                    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Пакетов таблеток пока нет", fontSize = 15.sp, fontWeight = FontWeight.Medium)
                            Text("Объедините препараты (например, «Утренние таблетки»)", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Button(onClick = { showAddPkg = true }, enabled = medications.isNotEmpty()) { Text("+ Создать пакет") }
                        }
                    }
                } else {
                    LazyColumn(
                        Modifier.fillMaxSize().padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(packages) { pkg ->
                            val ids = pkg.medIdsCsv.split(",").mapNotNull { it.toLongOrNull() }.toSet()
                            val includedNames = medications.filter { it.id in ids }.joinToString { "${it.name} ${it.dosage}".trim() }
                            Card(Modifier.fillMaxWidth().clickable { editingPkg = pkg }) {
                                Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                        Text("${pkg.scheduleTime} · ${pkg.name}", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                        if (includedNames.isNotBlank()) Text(includedNames, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    IconButton(onClick = { onDeletePkg(pkg) }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Удалить")
                                    }
                                }
                            }
                        }
                        item { Spacer(Modifier.height(72.dp)) }
                    }
                }
            }
        }
    }

    if (showAddMed) {
        AddMedicationDialog(
            onAskGemini = onAskGemini,
            onSave = { m -> onSaveMed(m); showAddMed = false },
            onDismiss = { showAddMed = false }
        )
    }

    if (showAddPkg || editingPkg != null) {
        AddPackageDialog(
            initialPkg = editingPkg,
            medications = medications,
            onSave = { pkg -> onSavePkg(pkg); showAddPkg = false; editingPkg = null },
            onDelete = editingPkg?.let { pToDel -> { onDeletePkg(pToDel); editingPkg = null } },
            onDismiss = { showAddPkg = false; editingPkg = null }
        )
    }
}

@Composable
private fun AddMedicationDialog(
    onAskGemini: suspend (String) -> MedSuggestion?,
    onSave: (MedicationItem) -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf("") }
    var dosage by remember { mutableStateOf("") }
    var dosageOptions by remember { mutableStateOf<List<String>>(emptyList()) }
    var effect by remember { mutableStateOf("") }
    var countStr by remember { mutableStateOf("1") }
    var timeStr by remember { mutableStateOf("08:30") }
    var stockStr by remember { mutableStateOf("30") }
    var askAiTrigger by remember { mutableStateOf(0) }

    val dictSuggestions = remember(name) { MedDictionary.suggest(name) }

    LaunchedEffect(askAiTrigger) {
        if (askAiTrigger > 0 && name.isNotBlank()) {
            onAskGemini(name)?.let { sug ->
                name = sug.name
                dosageOptions = sug.dosages
                if (dosage.isBlank() && sug.dosages.isNotEmpty()) dosage = sug.dosages.first()
                effect = sug.effect
            }
        }
    }

    FullScreenDialog(
        title = "Добавить препарат",
        onDismiss = onDismiss,
        actions = {
            TextButton(onClick = {
                if (name.isBlank()) return@TextButton
                onSave(
                    MedicationItem(
                        name = name.trim(),
                        dosage = dosage.trim(),
                        effect = effect.trim(),
                        countPerIntake = countStr.replace(",", ".").toDoubleOrNull() ?: 1.0,
                        scheduleTime = timeStr.trim(),
                        stockLeft = stockStr.replace(",", ".").toDoubleOrNull() ?: 30.0
                    )
                )
            }) { Text("Сохранить", fontWeight = FontWeight.SemiBold) }
        }
    ) { innerPad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(innerPad).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Название препарата") }, modifier = Modifier.weight(1f), singleLine = true)
                    FilledTonalButton(onClick = { askAiTrigger++ }, contentPadding = PaddingValues(horizontal = 10.dp)) { Text("ИИ", fontSize = 13.sp) }
                }
                if (dictSuggestions.isNotEmpty()) {
                    Row(Modifier.padding(top = 6.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        dictSuggestions.forEach { sug ->
                            AssistChip(
                                onClick = {
                                    name = sug.name
                                    dosageOptions = sug.dosages
                                    dosage = sug.dosages.firstOrNull() ?: ""
                                    effect = sug.effect
                                },
                                label = { Text(sug.name, fontSize = 11.sp) }
                            )
                        }
                    }
                }
            }
            if (dosageOptions.isNotEmpty()) {
                item {
                    Text("Выберите дозировку:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        dosageOptions.forEach { d ->
                            FilterChip(selected = dosage == d, onClick = { dosage = d }, label = { Text(d, fontSize = 12.sp) })
                        }
                    }
                }
            }
            item {
                OutlinedTextField(value = dosage, onValueChange = { dosage = it }, label = { Text("Дозировка (напр. 5/1,25/10 мг)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            }
            item {
                TimePickerField(scheduleTime = timeStr, onScheduleChange = { timeStr = it })
            }
            item {
                OutlinedTextField(value = effect, onValueChange = { effect = it }, label = { Text("Подробное описание действия") }, modifier = Modifier.fillMaxWidth(), maxLines = 3)
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = countStr, onValueChange = { countStr = it }, label = { Text("Шт за раз") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(value = stockStr, onValueChange = { stockStr = it }, label = { Text("Остаток шт") }, modifier = Modifier.weight(1f), singleLine = true)
                }
            }
            item {
                Button(
                    onClick = {
                        if (name.isBlank()) return@Button
                        onSave(
                            MedicationItem(
                                name = name.trim(),
                                dosage = dosage.trim(),
                                effect = effect.trim(),
                                countPerIntake = countStr.replace(",", ".").toDoubleOrNull() ?: 1.0,
                                scheduleTime = timeStr.trim(),
                                stockLeft = stockStr.replace(",", ".").toDoubleOrNull() ?: 30.0
                            )
                        )
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Добавить в справочник") }
            }
        }
    }
}

@Composable
private fun AddPackageDialog(
    initialPkg: MedPackage? = null,
    medications: List<MedicationItem>,
    onSave: (MedPackage) -> Unit,
    onDelete: (() -> Unit)? = null,
    onDismiss: () -> Unit
) {
    var pkgName by remember(initialPkg) { mutableStateOf(initialPkg?.name ?: "") }
    var pkgTime by remember(initialPkg) { mutableStateOf(initialPkg?.scheduleTime ?: "08:30") }
    var selectedMedIds by remember(initialPkg) {
        mutableStateOf(initialPkg?.medIdsCsv?.split(",")?.mapNotNull { it.toLongOrNull() }?.toSet() ?: emptySet())
    }

    FullScreenDialog(
        title = if (initialPkg == null) "Создать пакет таблеток" else "Редактировать пакет",
        onDismiss = onDismiss,
        actions = {
            if (onDelete != null) {
                TextButton(onClick = onDelete) { Text("Удалить", color = ColorHigh) }
            }
            TextButton(onClick = {
                if (pkgName.isBlank() || selectedMedIds.isEmpty()) return@TextButton
                val updated = initialPkg?.copy(
                    name = pkgName.trim(),
                    medIdsCsv = selectedMedIds.joinToString(","),
                    scheduleTime = pkgTime.trim()
                ) ?: MedPackage(name = pkgName.trim(), medIdsCsv = selectedMedIds.joinToString(","), scheduleTime = pkgTime.trim())
                onSave(updated)
            }) { Text("Сохранить", fontWeight = FontWeight.SemiBold) }
        }
    ) { innerPad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(innerPad).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                OutlinedTextField(value = pkgName, onValueChange = { pkgName = it }, label = { Text("Название (напр. Утренние таблетки)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            }
            item {
                TimePickerField(scheduleTime = pkgTime, onScheduleChange = { pkgTime = it })
            }
            item {
                Text("Выберите препараты в пакет:", fontSize = 13.sp, fontWeight = FontWeight.Medium)
            }
            items(medications) { m ->
                val checked = m.id in selectedMedIds
                Row(
                    Modifier.fillMaxWidth().clickable {
                        selectedMedIds = if (checked) selectedMedIds - m.id else selectedMedIds + m.id
                    }.padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(checked = checked, onCheckedChange = {
                        selectedMedIds = if (checked) selectedMedIds - m.id else selectedMedIds + m.id
                    })
                    Text("${m.name} ${m.dosage} (${m.countPerIntake} шт)", fontSize = 13.sp)
                }
            }
            item {
                Button(
                    onClick = {
                        if (pkgName.isBlank() || selectedMedIds.isEmpty()) return@Button
                        val updated = initialPkg?.copy(
                            name = pkgName.trim(),
                            medIdsCsv = selectedMedIds.joinToString(","),
                            scheduleTime = pkgTime.trim()
                        ) ?: MedPackage(name = pkgName.trim(), medIdsCsv = selectedMedIds.joinToString(","), scheduleTime = pkgTime.trim())
                        onSave(updated)
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(if (initialPkg == null) "Создать пакет" else "Сохранить пакет") }
            }
        }
    }
}

@Composable
private fun EditMedicationDialog(
    med: MedicationItem,
    onSave: (MedicationItem) -> Unit,
    onDelete: () -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf(med.name) }
    var dosage by remember { mutableStateOf(med.dosage) }
    var effect by remember { mutableStateOf(med.effect) }
    var countStr by remember { mutableStateOf(med.countPerIntake.toString()) }
    var timeStr by remember { mutableStateOf(med.scheduleTime) }
    var stockStr by remember { mutableStateOf(med.stockLeft.toString()) }

    FullScreenDialog(
        title = "Редактировать препарат",
        onDismiss = onDismiss,
        actions = {
            TextButton(onClick = onDelete) { Text("Удалить", color = ColorHigh) }
            TextButton(onClick = {
                onSave(
                    med.copy(
                        name = name.trim(),
                        dosage = dosage.trim(),
                        effect = effect.trim(),
                        countPerIntake = countStr.replace(",", ".").toDoubleOrNull() ?: med.countPerIntake,
                        scheduleTime = timeStr.trim(),
                        stockLeft = stockStr.replace(",", ".").toDoubleOrNull() ?: med.stockLeft
                    )
                )
            }) { Text("Сохранить", fontWeight = FontWeight.SemiBold) }
        }
    ) { innerPad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(innerPad).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item { OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Название") }, modifier = Modifier.fillMaxWidth(), singleLine = true) }
            item { OutlinedTextField(value = dosage, onValueChange = { dosage = it }, label = { Text("Дозировка") }, modifier = Modifier.fillMaxWidth(), singleLine = true) }
            item { TimePickerField(scheduleTime = timeStr, onScheduleChange = { timeStr = it }) }
            item { OutlinedTextField(value = effect, onValueChange = { effect = it }, label = { Text("Описание действия") }, modifier = Modifier.fillMaxWidth(), maxLines = 3) }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = countStr, onValueChange = { countStr = it }, label = { Text("Шт за раз") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(value = stockStr, onValueChange = { stockStr = it }, label = { Text("Остаток шт") }, modifier = Modifier.weight(1f), singleLine = true)
                }
            }
        }
    }
}

@Composable
private fun DeviceManagerDialog(
    pinnedDevices: Map<BleDeviceRole, PinnedBleDevice>,
    bleDevices: List<ScannedBleDevice>,
    isScanning: Boolean,
    onStartScan: () -> Unit,
    onPinAndConnect: (BleDeviceRole, String, String) -> Unit,
    onReadPinned: (BleDeviceRole) -> Unit,
    onUnpin: (BleDeviceRole) -> Unit,
    onSyncWatch: () -> Unit,
    onDismiss: () -> Unit
) {
    var step by remember { mutableStateOf(0) }
    var pickedDevice by remember { mutableStateOf<ScannedBleDevice?>(null) }

    FullScreenDialog(
        title = when (step) {
            1 -> if (isScanning) "Поиск BLE-приборов..." else "Выберите прибор"
            2 -> "Укажите тип прибора"
            else -> "Подключённые приборы"
        },
        onDismiss = { if (step > 0) step = 0 else onDismiss() },
        actions = {
            if (step == 1) TextButton(onClick = onStartScan) { Text("Обновить") }
        }
    ) { innerPad ->
        when (step) {
            0 -> LazyColumn(Modifier.fillMaxSize().padding(innerPad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(BleDeviceRole.values().toList()) { role ->
                    val pinned = pinnedDevices[role]
                    Card(Modifier.fillMaxWidth()) {
                        Row(
                            Modifier.fillMaxWidth().padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(role.label, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                Text(
                                    if (pinned != null) "${pinned.name} (${pinned.address})" else "Не подключён",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (pinned != null) {
                                Row {
                                    TextButton(onClick = { onReadPinned(role); onDismiss() }) { Text("Считать", fontSize = 12.sp) }
                                    IconButton(onClick = { onUnpin(role) }, modifier = Modifier.size(32.dp)) {
                                        Icon(Icons.Default.Close, contentDescription = "Отвязать", modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }
                    }
                }
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Row(
                            Modifier.fillMaxWidth().padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text("Часы (Samsung)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                Text("Синхронизация через Health Connect", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            TextButton(onClick = { onSyncWatch(); onDismiss() }) { Text("Синхр.", fontSize = 12.sp) }
                        }
                    }
                }
                item {
                    Button(onClick = { step = 1; onStartScan() }, modifier = Modifier.fillMaxWidth()) { Text("+ Подключить прибор") }
                }
            }
            1 -> LazyColumn(Modifier.fillMaxSize().padding(innerPad).padding(16.dp)) {
                if (bleDevices.isEmpty()) item { Text("Включите прибор рядом...", fontSize = 14.sp) }
                else items(bleDevices) { dev ->
                    Column(Modifier.fillMaxWidth().clickable { pickedDevice = dev; step = 2 }.padding(vertical = 8.dp)) {
                        Text(dev.name.ifBlank { "BLE" }, fontWeight = FontWeight.Medium, fontSize = 15.sp)
                        Text("${dev.address} · RSSI ${dev.rssi}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    HorizontalDivider()
                }
            }
            else -> Column(Modifier.fillMaxSize().padding(innerPad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("${pickedDevice?.name ?: ""} (${pickedDevice?.address ?: ""})", fontSize = 13.sp)
                BleDeviceRole.values().forEach { role ->
                    FilledTonalButton(
                        onClick = { pickedDevice?.let { onPinAndConnect(role, it.name, it.address) }; onDismiss() },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Зафиксировать как: ${role.label}") }
                }
            }
        }
    }
}

private fun swapTiles(order: List<Int>, a: Int, b: Int): List<Int> {
    val mut = order.toMutableList()
    val ia = mut.indexOf(a); val ib = mut.indexOf(b)
    if (ia >= 0 && ib >= 0) { mut[ia] = b; mut[ib] = a }
    return mut
}

private fun formatVitalRow(item: VitalEntry, norms: UserNorms, s: AppStrings): Triple<String, Color?, FontWeight> {
    return when (item.type) {
        VitalType.GLUCOSE -> {
            val col = when {
                item.value1 > norms.glucoseMax -> ColorHigh
                item.value1 < norms.glucoseMin -> ColorLow
                else -> null
            }
            Triple("${s.sugar}: ${item.value1} ммоль/л", col, if (col != null) FontWeight.Bold else FontWeight.Normal)
        }
        VitalType.BP -> {
            val sys = item.value1.toInt(); val dia = item.value2?.toInt() ?: 0; val p = item.pulse
            val isHigh = sys > norms.sysMax || dia > norms.diaMax || (p != null && p > norms.pulseMax)
            val isLow = sys < norms.sysMin || dia < norms.diaMin || (p != null && p < norms.pulseMin)
            val col = when { isHigh -> ColorHigh; isLow -> ColorLow; else -> null }
            Triple("${s.bp}: $sys/$dia${p?.let { "-$it" } ?: ""}", col, if (col != null) FontWeight.Bold else FontWeight.Normal)
        }
        VitalType.INSULIN -> Triple("${s.insulin}: ${item.value1.toInt()} ЕД", null, FontWeight.Normal)
        VitalType.WATER -> Triple("${s.waterLabel}: +${item.value1.toInt()} мл", null, FontWeight.Normal)
        VitalType.WEIGHT -> Triple("${s.weightWater.substringBefore(" /")}: ${item.value1} кг", null, FontWeight.Normal)
        VitalType.FOOD -> {
            val prefix = if (listOf("Завтрак:", "Обед:", "Ужин:", "Перекус:").any { item.note.startsWith(it) }) "" else "${s.food}: "
            Triple("$prefix${item.note} (${item.value1} ХЕ)", null, FontWeight.Normal)
        }
        VitalType.NOTE -> Triple("Заметка: ${item.note}", null, FontWeight.Normal)
        VitalType.CUSTOM -> {
            val parts = item.note.split("|")
            val lbl = parts.getOrNull(1) ?: "Показатель"
            val unit = parts.getOrNull(2) ?: ""
            Triple("$lbl: ${item.value1} $unit".trim(), null, FontWeight.Normal)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MetricTile(
    modifier: Modifier = Modifier,
    elevation: androidx.compose.ui.unit.Dp = 1.dp,
    isSelected: Boolean = false,
    topActionLabel: String,
    onTopAction: () -> Unit,
    topStamp: String = "",
    value: String,
    valueColor: Color? = null,
    valueWeight: FontWeight = FontWeight.Bold,
    bottomActionLabel: String,
    onBottomAction: () -> Unit,
    bottomStamp: String = "",
    sub: String,
    subColor: Color? = null,
    subWeight: FontWeight = FontWeight.SemiBold,
    highlightBg: Boolean = false,
    onOpenDevices: () -> Unit = {},
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    Card(
        modifier = modifier.combinedClickable(onClick = onClick, onLongClick = onLongClick),
        elevation = CardDefaults.cardElevation(defaultElevation = elevation),
        border = if (isSelected) BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null,
        colors = if (highlightBg) CardDefaults.cardColors(containerColor = if (MaterialTheme.colorScheme.surface.red < 0.5f) Color(0xFF4A1820) else Color(0xFFFFCDD2)) else CardDefaults.cardColors()
    ) {
        Box(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize().padding(horizontal = 10.dp, vertical = 8.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(Modifier.fillMaxWidth().heightIn(min = 22.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    TactileTileAction(label = topActionLabel, onClick = onTopAction)
                    if (topStamp.isNotBlank()) {
                        Text(topStamp, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                    }
                }
                Text(value, fontSize = 18.sp, fontWeight = valueWeight, color = valueColor ?: MaterialTheme.colorScheme.onSurface, maxLines = 1, modifier = Modifier.heightIn(min = 24.dp))
            }
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(Modifier.fillMaxWidth().heightIn(min = 22.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    TactileTileAction(label = bottomActionLabel, onClick = onBottomAction)
                    if (bottomStamp.isNotBlank()) {
                        Text(bottomStamp, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                    }
                }
                Text(sub, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = subColor ?: MaterialTheme.colorScheme.onSurface, maxLines = 1, modifier = Modifier.heightIn(min = 24.dp))
            }
        }
            if (isSelected) {
                FilledIconButton(
                    onClick = onOpenDevices,
                    modifier = Modifier.align(Alignment.Center).size(40.dp)
                ) {
                    Icon(Icons.Default.Settings, contentDescription = "Подключить прибор")
                }
            }
        }
    }
}

@Composable
private fun WeatherFullScreenDialog(
    city: String,
    dailyContext: DailyContext?,
    weatherLogs: List<WeatherLog>,
    weatherForecast: List<WeatherForecastDay>,
    onRefresh: () -> Unit,
    onDismiss: () -> Unit
) {
    val fmt = remember { SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()) }
    val latest = weatherLogs.firstOrNull()
    val prev = weatherLogs.getOrNull(1)
    val deltaMm = if (latest != null && prev != null) latest.pressureMmHg - prev.pressureMmHg else null

    FullScreenDialog(
        title = "Погода: $city",
        onDismiss = onDismiss,
        actions = {
            TextButton(onClick = onRefresh) { Text("Обновить") }
        }
    ) { innerPad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(innerPad).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        val t = latest?.tempC ?: dailyContext?.weatherTempC
                        val p = latest?.pressureMmHg ?: dailyContext?.weatherPressureMmHg
                        val c = latest?.condition?.ifBlank { dailyContext?.weatherCondition ?: "" } ?: (dailyContext?.weatherCondition ?: "")
                        Text("${t ?: "—"}°C · ${c.ifBlank { "—" }}", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Text(
                            "Давление: ${p ?: "—"} мм рт. ст.${deltaMm?.let { if (it > 0) " (+$it)" else if (it < 0) " ($it)" else " (0)" } ?: ""}",
                            fontSize = 15.sp, fontWeight = FontWeight.Medium
                        )
                        if (latest != null) {
                            Text("Ощущается как: ${latest.feelsLikeC}°C · Влажность: ${latest.humidity}% · Ветер: ${latest.windKmh} км/ч", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
            if (weatherForecast.isNotEmpty()) {
                item {
                    Text("Прогноз:", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
                items(weatherForecast) { day ->
                    val label = if (day.date == weatherForecast.firstOrNull()?.date) "Сегодня" else "Завтра"
                    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("$label (${day.date.takeLast(5)}) · ${day.minC}..${day.maxC}°C · ${day.condition}", fontSize = 13.sp)
                        Text("осадки: ${day.precipMm} мм", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    HorizontalDivider()
                }
            }
            item {
                Text("Журнал погоды (для анализа скачков АД):", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
            if (weatherLogs.isEmpty()) {
                item { Text("История погоды пока пуста", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            } else {
                items(weatherLogs) { w ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${fmt.format(Date(w.timestamp))} · ${w.pressureMmHg} мм · ${w.tempC}°C · ${w.condition}", fontSize = 13.sp)
                        Text("${w.humidity}% · ${w.windKmh}км/ч", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}

@Composable
private fun QuickEntryDialog(
    s: AppStrings,
    userNorms: UserNorms,
    initGlucose: Double,
    initSys: Int,
    initDia: Int,
    initPulse: Int,
    initInsulin: Int,
    onOpenDirectories: () -> Unit,
    onOpenFood: () -> Unit,
    onOpenNote: () -> Unit,
    onOpenPills: () -> Unit,
    onDismiss: () -> Unit,
    onSave: (VitalType, Double, Double?, Int?, String) -> Unit
) {
    var selectedType by remember { mutableStateOf(VitalType.GLUCOSE) }
    var val1 by remember(selectedType) {
        mutableStateOf(
            when (selectedType) {
                VitalType.GLUCOSE -> "%.1f".format(Locale.US, initGlucose)
                VitalType.BP -> initSys.toString()
                VitalType.INSULIN -> initInsulin.toString()
                else -> ""
            }
        )
    }
    var val2 by remember(selectedType) { mutableStateOf(if (selectedType == VitalType.BP) initDia.toString() else "") }
    var pulse by remember(selectedType) { mutableStateOf(if (selectedType == VitalType.BP) initPulse.toString() else "") }
    var gluNote by remember(selectedType) { mutableStateOf("") }

    @Composable
    fun MenuPill(label: String, selected: Boolean = false, onClick: () -> Unit) {
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = if (selected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline),
            modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onClick)
        ) {
            Text(label, fontSize = 12.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
        }
    }

    FullScreenDialog(
        title = s.newEntry,
        onDismiss = onDismiss,
        actions = {
            TextButton(onClick = {
                val v1 = val1.replace(",", ".").toDoubleOrNull() ?: return@TextButton
                onSave(selectedType, v1, val2.replace(",", ".").toDoubleOrNull(), pulse.toIntOrNull(), if (selectedType == VitalType.GLUCOSE) gluNote else "")
            }) { Text(s.save, fontWeight = FontWeight.SemiBold) }
        }
    ) { innerPad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(innerPad).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp), horizontalAlignment = Alignment.Start) {
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        MenuPill("Справочники", onClick = onOpenDirectories)
                        MenuPill(s.food, onClick = onOpenFood)
                        MenuPill("Заметка", onClick = onOpenNote)
                    }
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        MenuPill(s.sugar, selected = selectedType == VitalType.GLUCOSE) { selectedType = VitalType.GLUCOSE }
                        MenuPill(s.bp, selected = selectedType == VitalType.BP) { selectedType = VitalType.BP }
                        MenuPill(s.insulin, selected = selectedType == VitalType.INSULIN) { selectedType = VitalType.INSULIN }
                        MenuPill("Таблетки", onClick = onOpenPills)
                    }
                }
            }
            if (selectedType == VitalType.GLUCOSE) {
                item {
                    val gVal = (val1.replace(",", ".").toDoubleOrNull() ?: initGlucose).coerceIn(2.0, 20.0)
                    val gCol = when {
                        gVal > userNorms.glucoseMax -> ColorHigh
                        gVal < userNorms.glucoseMin -> ColorLow
                        else -> MaterialTheme.colorScheme.primary
                    }
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("${"%.1f".format(Locale.US, gVal)} ммоль/л", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = gCol, modifier = Modifier.align(Alignment.CenterHorizontally))
                        Slider(value = gVal.toFloat().coerceIn(3f, 15f), onValueChange = { val1 = "%.1f".format(Locale.US, kotlin.math.round(it * 10.0) / 10.0) }, valueRange = 3f..15f)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(-0.5, -0.1, 0.1, 0.5).forEach { st ->
                                OutlinedButton(onClick = { val1 = "%.1f".format(Locale.US, (gVal + st).coerceIn(2.0, 25.0)) }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(0.dp)) {
                                    Text(if (st > 0) "+$st" else "$st", fontSize = 13.sp)
                                }
                            }
                        }
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("5.5", "6.0", "7.0", "8.0", "9.0", "10.0").forEach { v -> AssistChip(onClick = { val1 = v }, label = { Text(v, fontSize = 12.sp) }) }
                        }
                        OutlinedTextField(value = val1, onValueChange = { val1 = it }, label = { Text("Сахар (ммоль/л)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("Натощак", "До еды", "30 мин после еды", "1 ч после еды", "1.5 ч после еды", "2 ч после еды", "3 ч после еды").forEach { tag ->
                                FilterChip(
                                    selected = gluNote == tag,
                                    onClick = { gluNote = if (gluNote == tag) "" else tag },
                                    label = { Text(tag, fontSize = 11.sp) }
                                )
                            }
                        }
                    }
                }
            } else if (selectedType == VitalType.BP) {
                item {
                    val sVal = (val1.toIntOrNull() ?: initSys).coerceIn(70, 230)
                    val dVal = (val2.toIntOrNull() ?: initDia).coerceIn(40, 140)
                    val pVal = (pulse.toIntOrNull() ?: initPulse).coerceIn(35, 160)
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("$sVal / $dVal · $pVal уд/мин", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.align(Alignment.CenterHorizontally))
                        Text("SYS: $sVal", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(onClick = { val1 = (sVal - 1).coerceIn(70, 230).toString() }, contentPadding = PaddingValues(0.dp), modifier = Modifier.width(42.dp)) { Text("-1") }
                            Slider(value = sVal.toFloat().coerceIn(80f, 220f), onValueChange = { val1 = kotlin.math.round(it).toInt().toString() }, valueRange = 80f..220f, modifier = Modifier.weight(1f))
                            OutlinedButton(onClick = { val1 = (sVal + 1).coerceIn(70, 230).toString() }, contentPadding = PaddingValues(0.dp), modifier = Modifier.width(42.dp)) { Text("+1") }
                        }
                        Text("DIA: $dVal", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(onClick = { val2 = (dVal - 1).coerceIn(40, 140).toString() }, contentPadding = PaddingValues(0.dp), modifier = Modifier.width(42.dp)) { Text("-1") }
                            Slider(value = dVal.toFloat().coerceIn(50f, 130f), onValueChange = { val2 = kotlin.math.round(it).toInt().toString() }, valueRange = 50f..130f, modifier = Modifier.weight(1f))
                            OutlinedButton(onClick = { val2 = (dVal + 1).coerceIn(40, 140).toString() }, contentPadding = PaddingValues(0.dp), modifier = Modifier.width(42.dp)) { Text("+1") }
                        }
                        Text("Пульс: $pVal", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(onClick = { pulse = (pVal - 1).coerceIn(35, 160).toString() }, contentPadding = PaddingValues(0.dp), modifier = Modifier.width(42.dp)) { Text("-1") }
                            Slider(value = pVal.toFloat().coerceIn(40f, 150f), onValueChange = { pulse = kotlin.math.round(it).toInt().toString() }, valueRange = 40f..150f, modifier = Modifier.weight(1f))
                            OutlinedButton(onClick = { pulse = (pVal + 1).coerceIn(35, 160).toString() }, contentPadding = PaddingValues(0.dp), modifier = Modifier.width(42.dp)) { Text("+1") }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedTextField(value = val1, onValueChange = { val1 = it }, label = { Text("SYS") }, modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(value = val2, onValueChange = { val2 = it }, label = { Text("DIA") }, modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(value = pulse, onValueChange = { pulse = it }, label = { Text(s.pulseLabel) }, modifier = Modifier.weight(1f), singleLine = true)
                        }
                    }
                }
            } else {
                item {
                    val insNum = (val1.replace(",", ".").toDoubleOrNull() ?: initInsulin.toDouble()).coerceIn(0.0, 60.0)
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("${insNum.toInt()} ЕД", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.align(Alignment.CenterHorizontally))
                        Slider(value = insNum.toFloat(), onValueChange = { val1 = kotlin.math.round(it).toInt().toString() }, valueRange = 0f..60f)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(-5, -1, 1, 5).forEach { st ->
                                OutlinedButton(onClick = { val1 = (insNum.toInt() + st).coerceIn(0, 100).toString() }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(0.dp)) {
                                    Text(if (st > 0) "+$st" else "$st", fontSize = 13.sp)
                                }
                            }
                        }
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(4, 6, 8, 10, 38, 40).forEach { d -> AssistChip(onClick = { val1 = d.toString() }, label = { Text("$d ЕД", fontSize = 12.sp) }) }
                        }
                        OutlinedTextField(value = val1, onValueChange = { val1 = it }, label = { Text("Инсулин (ЕД)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FoodEntryDialog(
    s: AppStrings,
    useBackArrow: Boolean = false,
    hasGeminiKey: Boolean,
    foodDishes: List<FoodDish>,
    recentFoods: List<Pair<String, Double>>,
    foodPlates: List<FoodPlate>,
    onOpenGeminiSettings: () -> Unit,
    onSaveDish: (FoodDish) -> Unit,
    onDeleteDish: (FoodDish) -> Unit,
    onSavePlate: (FoodPlate) -> Unit,
    onDeletePlate: (FoodPlate) -> Unit,
    onAnalyzeFoodPhoto: suspend (String, List<FoodPlate>, Int?, String) -> FoodAnalysis?,
    onAnalyzeFoodText: suspend (String, Int?, String) -> FoodAnalysis?,
    onIdentifyPlatePhoto: suspend (String) -> PlateAnalysis?,
    onDismiss: () -> Unit,
    onSave: (Double, String) -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current

    var mealSlot by remember {
        val hr = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        mutableStateOf(
            when (hr) {
                in 5..11 -> "Завтрак"
                in 12..16 -> "Обед"
                in 17..22 -> "Ужин"
                else -> "Перекус"
            }
        )
    }
    var foodNote by remember { mutableStateOf("") }
    var xeStr by remember { mutableStateOf("") }
    var aiHint by remember { mutableStateOf("") }
    var selectedPlate by remember { mutableStateOf<FoodPlate?>(null) }
    var grossGramsStr by remember { mutableStateOf("") }
    var photoBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var photoBase64 by remember { mutableStateOf("") }
    var isAnalyzingFood by remember { mutableStateOf(false) }
    var aiStatus by remember { mutableStateOf("") }

    var showDirectory by remember { mutableStateOf(false) }
    var editingPlate by remember { mutableStateOf<FoodPlate?>(null) }
    var showNewPlateDialog by remember { mutableStateOf(false) }
    var editingDish by remember { mutableStateOf<FoodDish?>(null) }
    var selectedCalibrationDish by remember { mutableStateOf<FoodDish?>(null) }

    val grossG = run {
        val raw = grossGramsStr.trim().lowercase().replace(",", ".").replace(" ", "")
        when {
            raw.isEmpty() -> null
            raw.endsWith("мл") || raw.endsWith("ml") -> raw.replace("мл", "").replace("ml", "").toDoubleOrNull()?.toInt()
            raw.endsWith("л") || raw.endsWith("l") -> raw.replace("л", "").replace("l", "").toDoubleOrNull()?.let { kotlin.math.round(it * 1000.0).toInt() }
            else -> raw.replace("г", "").replace("g", "").toDoubleOrNull()?.toInt()
        }
    }
    val netGrams = if (grossG != null) (grossG - (selectedPlate?.tareGrams ?: 0)).coerceAtLeast(0) else null

    fun recalcFromCalibration(newGrossStr: String) {
        val cal = selectedCalibrationDish ?: return
        if (cal.defaultGrams <= 0) return
        val raw = newGrossStr.trim().lowercase().replace(",", ".").replace(" ", "")
        val g = when {
            raw.isEmpty() -> null
            raw.endsWith("мл") || raw.endsWith("ml") -> raw.replace("мл", "").replace("ml", "").toDoubleOrNull()?.toInt()
            raw.endsWith("л") || raw.endsWith("l") -> raw.replace("л", "").replace("l", "").toDoubleOrNull()?.let { kotlin.math.round(it * 1000.0).toInt() }
            else -> raw.replace("г", "").replace("g", "").toDoubleOrNull()?.toInt()
        } ?: return
        val net = (g - (selectedPlate?.tareGrams ?: 0)).coerceAtLeast(0)
        if (net > 0) {
            xeStr = "%.1f".format(Locale.US, cal.xe * net.toDouble() / cal.defaultGrams.toDouble())
        }
    }

    fun runTextFoodAi() {
        if (isAnalyzingFood || foodNote.isBlank()) return
        isAnalyzingFood = true
        aiStatus = "Считаю ХЕ по тексту..."
        scope.launch {
            val res = onAnalyzeFoodText(foodNote.trim(), netGrams, aiHint.trim())
            isAnalyzingFood = false
            if (res != null) {
                val cleanNote = res.note.trim()
                if (cleanNote.isNotBlank()) {
                    foodNote = if (cleanNote.startsWith(res.dishName, ignoreCase = true)) cleanNote else "${res.dishName} — $cleanNote"
                }
                xeStr = "%.1f".format(Locale.US, res.xe)
                aiStatus = "~${res.carbsGrams}г угл. (${xeStr} ХЕ)"
            } else {
                aiStatus = "Не удалось посчитать (проверьте Gemini API Key в Настройках)"
            }
        }
    }

    fun runFoodAi(b64: String) {
        if (isAnalyzingFood || b64.isBlank()) return
        isAnalyzingFood = true
        aiStatus = "Анализирую фото..."
        scope.launch {
            val res = onAnalyzeFoodPhoto(b64, foodPlates, netGrams, aiHint.trim())
            isAnalyzingFood = false
            if (res != null) {
                if (res.matchedPlateId != null) {
                    foodPlates.firstOrNull { it.id == res.matchedPlateId }?.let { selectedPlate = it }
                }
                if (res.grossGrams != null && res.grossGrams > 0 && grossGramsStr.isBlank()) {
                    grossGramsStr = res.grossGrams.toString()
                }
                val cleanNote = res.note.trim()
                foodNote = when {
                    cleanNote.isBlank() -> res.dishName
                    cleanNote.startsWith(res.dishName, ignoreCase = true) -> cleanNote
                    else -> "${res.dishName} — $cleanNote"
                }
                xeStr = "%.1f".format(Locale.US, res.xe)
                val plInfo = selectedPlate?.let { "Тарелка: ${it.name} · " } ?: ""
                aiStatus = "${plInfo}~${res.carbsGrams}г угл. (${xeStr} ХЕ)"
            } else {
                aiStatus = "Не удалось распознать (проверьте Gemini API Key в Настройках)"
            }
        }
    }

    fun encodeBitmap(bmp: Bitmap): String {
        val maxDim = 800
        val scale = minOf(maxDim.toFloat() / bmp.width, maxDim.toFloat() / bmp.height, 1f)
        val scaled = if (scale < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true) else bmp
        val baos = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 75, baos)
        return Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
    }

    fun decodeOrientedBitmap(uri: Uri): Bitmap? {
        val raw = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: return null
        val orientation = try {
            ctx.contentResolver.openInputStream(uri)?.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL) }
                ?: ExifInterface.ORIENTATION_NORMAL
        } catch (_: Exception) { ExifInterface.ORIENTATION_NORMAL }
        val angle = when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        if (angle == 0f) return raw
        val m = Matrix().apply { postRotate(angle) }
        return Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
    }

    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bmp ->
        if (bmp != null) {
            photoBitmap = bmp
            val b64 = encodeBitmap(bmp)
            photoBase64 = b64
            runFoodAi(b64)
        }
    }

    val galleryLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            decodeOrientedBitmap(uri)?.let { bmp ->
                photoBitmap = bmp
                val b64 = encodeBitmap(bmp)
                photoBase64 = b64
                runFoodAi(b64)
            }
        }
    }

    val allFrequentDishes = remember(foodDishes, recentFoods) {
        foodDishes + recentFoods.map { (n, xe) -> FoodDish(id = 0L, name = n, xe = xe) }
    }

    FullScreenDialog(
        title = "Еда",
        useBackArrow = useBackArrow,
        onDismiss = onDismiss,
        actions = {
            TextButton(onClick = { showDirectory = true }) { Text("Справочник") }
            TextButton(onClick = {
                val v1 = xeStr.replace(",", ".").toDoubleOrNull() ?: if (foodNote.isNotBlank()) 0.0 else return@TextButton
                val netPart = if (netGrams != null && netGrams > 0) " (${netGrams}г)" else ""
                val finalNote = "$mealSlot: ${foodNote.trim()}$netPart".trim()
                onSave(v1, finalNote)
            }) { Text(s.save, fontWeight = FontWeight.SemiBold) }
        }
    ) { innerPad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(innerPad).padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // 1. Приём пищи
            item {
                Text("1. Приём пищи", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                Row(Modifier.padding(top = 6.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Завтрак", "Обед", "Ужин", "Перекус").forEach { slot ->
                        FilterChip(selected = mealSlot == slot, onClick = { mealSlot = slot }, label = { Text(slot, fontSize = 12.sp) })
                    }
                }
            }

            // 2. Фото и ИИ-распознавание
            item {
                Text("2. Фото и ИИ-анализ", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                if (!hasGeminiKey) {
                    var showHintFood by remember { mutableStateOf(false) }
                    Card(Modifier.fillMaxWidth().padding(top = 6.dp)) {
                        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                "Gemini API Key не задан — как получить бесплатный ключ?",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.clickable { showHintFood = !showHintFood }
                            )
                            if (showHintFood) {
                                val uriHandler = LocalUriHandler.current
                                Text("1. Откройте Google AI Studio и войдите в Google.\n2. Нажмите «Create API key» (без карты).\n3. Вставьте ключ (AQ... или AIza...) в Настройки → HA / ИИ.", fontSize = 11.sp)
                                Text("→ Открыть aistudio.google.com/apikey", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.clickable { uriHandler.openUri("https://aistudio.google.com/apikey") })
                            }
                            TextButton(onClick = onOpenGeminiSettings, contentPadding = PaddingValues(0.dp), modifier = Modifier.height(26.dp)) {
                                Text("Открыть Настройки → HA / ИИ", fontSize = 11.sp)
                            }
                        }
                    }
                }
                Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { cameraLauncher.launch(null) }, modifier = Modifier.weight(1f)) { Text("Камера", fontSize = 12.sp) }
                    OutlinedButton(onClick = { galleryLauncher.launch("image/*") }, modifier = Modifier.weight(1f)) { Text("Галерея", fontSize = 12.sp) }
                }
                OutlinedTextField(
                    value = aiHint,
                    onValueChange = { aiHint = it },
                    label = { Text("Уточнение для ИИ (напр. кабачки 50г)") },
                    modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                    singleLine = true
                )
                if (photoBitmap != null) {
                    Image(
                        bitmap = photoBitmap!!.asImageBitmap(),
                        contentDescription = "Фото блюда",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp).heightIn(min = 200.dp, max = 340.dp)
                    )
                    Button(
                        onClick = { runFoodAi(photoBase64) },
                        enabled = !isAnalyzingFood,
                        modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                    ) { Text(if (isAnalyzingFood) "Распознаю..." else "Пересчитать состав и ХЕ (ИИ)") }
                    if (aiStatus.isNotBlank()) Text(aiStatus, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
                }
            }

            // 3. Тарелка и вес/объём
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("3. Тарелка и вес / объём", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                    TextButton(onClick = { showNewPlateDialog = true }, contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp), modifier = Modifier.height(28.dp)) {
                        Text("+ Тарелка", fontSize = 12.sp)
                    }
                }
                Row(Modifier.padding(top = 4.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (selectedPlate == null) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, if (selectedPlate == null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant),
                        modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { selectedPlate = null }
                    ) {
                        Text("Без тары", fontSize = 11.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
                    }
                    foodPlates.forEach { pl ->
                        val sel = selectedPlate?.id == pl.id
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (sel) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant),
                            modifier = Modifier.clip(RoundedCornerShape(8.dp)).combinedClickable(
                                onClick = { selectedPlate = pl },
                                onLongClick = {
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    editingPlate = pl
                                }
                            )
                        ) {
                            Text("${pl.name} (${pl.tareGrams}г)", fontSize = 11.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
                        }
                    }
                }
                Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = grossGramsStr,
                        onValueChange = { grossGramsStr = it; recalcFromCalibration(it) },
                        label = { Text("Вес / объём (г, мл, 0.5л)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    Text(
                        if (netGrams != null) "Нетто: $netGrams г/мл" else "Нетто: —",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                Row(Modifier.padding(top = 6.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("200 мл" to "200", "250 мл" to "250", "330 мл" to "330", "500 мл" to "500").forEach { (lbl, v) ->
                        AssistChip(onClick = { grossGramsStr = v; recalcFromCalibration(v) }, label = { Text(lbl, fontSize = 11.sp) })
                    }
                }
                val gSliderVal = (grossG ?: 0).toFloat().coerceIn(0f, 1200f)
                Slider(value = gSliderVal, onValueChange = { val nv = (kotlin.math.round(it / 10f) * 10f).toInt().toString(); grossGramsStr = nv; recalcFromCalibration(nv) }, valueRange = 0f..1200f)
            }

            // 4. Частые блюда и ручной ввод
            item {
                Text("4. Блюдо и ХЕ", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                if (allFrequentDishes.isNotEmpty()) {
                    Text("Частые блюда (долгий тап — изменить/удалить):", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
                    Row(Modifier.padding(top = 4.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        allFrequentDishes.forEach { dish ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (dish.isFavorite) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                                border = BorderStroke(1.dp, if (dish.isFavorite) Color(0xFFFFB300) else MaterialTheme.colorScheme.outlineVariant),
                                modifier = Modifier.clip(RoundedCornerShape(8.dp)).combinedClickable(
                                    onClick = {
                                        selectedCalibrationDish = dish
                                        foodNote = dish.name
                                        if (dish.defaultGrams > 0 && netGrams != null && netGrams > 0) {
                                            xeStr = "%.1f".format(Locale.US, dish.xe * netGrams.toDouble() / dish.defaultGrams.toDouble())
                                        } else {
                                            xeStr = "%.1f".format(Locale.US, dish.xe)
                                            if (dish.defaultGrams > 0 && grossGramsStr.isBlank()) {
                                                grossGramsStr = dish.defaultGrams.toString()
                                            }
                                        }
                                    },
                                    onLongClick = {
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        editingDish = dish
                                    }
                                )
                            ) {
                                val starPrefix = if (dish.isFavorite) "★ " else ""
                                Text("$starPrefix${dish.name.take(24)} (${dish.xe} ХЕ)", fontSize = 11.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
                            }
                        }
                    }
                }
                OutlinedTextField(
                    value = foodNote,
                    onValueChange = { foodNote = it; selectedCalibrationDish = null },
                    label = { Text(s.foodNameHint) },
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    maxLines = 3
                )
                if (photoBitmap == null && foodNote.isNotBlank()) {
                    OutlinedButton(
                        onClick = { runTextFoodAi() },
                        enabled = !isAnalyzingFood,
                        modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                    ) {
                        Text(if (isAnalyzingFood) "Считаю..." else "Посчитать ХЕ по тексту (ИИ)", fontSize = 12.sp)
                    }
                    if (aiStatus.isNotBlank()) Text(aiStatus, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 2.dp))
                }
                val xeNum = (xeStr.replace(",", ".").toDoubleOrNull() ?: 0.0).coerceIn(0.0, 15.0)
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("ХЕ: ${"%.1f".format(Locale.US, xeNum)}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf(-0.5, -0.1, 0.1, 0.5).forEach { st ->
                            OutlinedButton(onClick = { xeStr = "%.1f".format(Locale.US, (xeNum + st).coerceAtLeast(0.0)) }, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp), modifier = Modifier.height(30.dp)) {
                                Text(if (st > 0) "+$st" else "$st", fontSize = 11.sp)
                            }
                        }
                    }
                }
                Slider(value = xeNum.toFloat().coerceIn(0f, 12f), onValueChange = { xeStr = "%.1f".format(Locale.US, kotlin.math.round(it * 10.0) / 10.0) }, valueRange = 0f..12f)
                OutlinedTextField(
                    value = xeStr,
                    onValueChange = { xeStr = it },
                    label = { Text(s.xeHint) },
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                    singleLine = true
                )
            }
        }
    }

    if (showDirectory) {
        FoodDirectoryDialog(
            s = s,
            hasGeminiKey = hasGeminiKey,
            foodDishes = foodDishes,
            foodPlates = foodPlates,
            onOpenGeminiSettings = { showDirectory = false; onOpenGeminiSettings() },
            onSaveDish = onSaveDish,
            onDeleteDish = onDeleteDish,
            onSavePlate = onSavePlate,
            onDeletePlate = onDeletePlate,
            onIdentifyPlatePhoto = onIdentifyPlatePhoto,
            onDismiss = { showDirectory = false }
        )
    }

    if (showNewPlateDialog || editingPlate != null) {
        PlateEditorDialog(
            s = s,
            initialPlate = editingPlate,
            hasGeminiKey = hasGeminiKey,
            onOpenGeminiSettings = { showNewPlateDialog = false; editingPlate = null; onOpenGeminiSettings() },
            onIdentifyPlatePhoto = onIdentifyPlatePhoto,
            onSave = { pl ->
                onSavePlate(pl)
                if (selectedPlate?.id == pl.id) selectedPlate = pl
                showNewPlateDialog = false
                editingPlate = null
            },
            onDelete = { pl ->
                onDeletePlate(pl)
                if (selectedPlate?.id == pl.id) selectedPlate = null
                editingPlate = null
            },
            onDismiss = { showNewPlateDialog = false; editingPlate = null }
        )
    }

    if (editingDish != null) {
        DishEditorDialog(
            initialDish = editingDish!!,
            onSave = { d ->
                onSaveDish(d)
                editingDish = null
            },
            onDelete = { d ->
                if (d.id > 0L) onDeleteDish(d)
                editingDish = null
            },
            onDismiss = { editingDish = null }
        )
    }
}

@Composable
private fun FoodDirectoryDialog(
    s: AppStrings,
    useBackArrow: Boolean = false,
    hasGeminiKey: Boolean,
    foodDishes: List<FoodDish>,
    foodPlates: List<FoodPlate>,
    onOpenGeminiSettings: () -> Unit,
    onSaveDish: (FoodDish) -> Unit,
    onDeleteDish: (FoodDish) -> Unit,
    onSavePlate: (FoodPlate) -> Unit,
    onDeletePlate: (FoodPlate) -> Unit,
    onIdentifyPlatePhoto: suspend (String) -> PlateAnalysis?,
    onDismiss: () -> Unit
) {
    var tab by remember { mutableStateOf(0) }
    var editingDish by remember { mutableStateOf<FoodDish?>(null) }
    var showNewPlate by remember { mutableStateOf(false) }
    var editingPlate by remember { mutableStateOf<FoodPlate?>(null) }

    FullScreenDialog(
        title = "Справочник еды и тарелок",
        useBackArrow = useBackArrow,
        onDismiss = onDismiss,
        actions = {
            TextButton(onClick = {
                if (tab == 0) editingDish = FoodDish(name = "", xe = 0.0, defaultGrams = 0)
                else showNewPlate = true
            }) { Text("+ Добавить", fontWeight = FontWeight.SemiBold) }
        }
    ) { innerPad ->
        Column(Modifier.fillMaxSize().padding(innerPad)) {
            TabRow(selectedTabIndex = tab) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Блюда (${foodDishes.size})") })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Тарелки (${foodPlates.size})") })
            }
            LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (tab == 0) {
                    if (foodDishes.isEmpty()) {
                        item { Text("Список блюд пуст. Блюда добавляются автоматически при сохранении или кнопкой «+ Добавить».", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    }
                    items(foodDishes, key = { it.id }) { d ->
                        Row(
                            Modifier.fillMaxWidth().clickable { editingDish = d }.padding(vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { onSaveDish(d.copy(isFavorite = !d.isFavorite)) }, modifier = Modifier.size(32.dp)) {
                                Icon(
                                    if (d.isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                                    contentDescription = "Постоянное блюдо",
                                    tint = if (d.isFavorite) Color(0xFFFFB300) else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Column(Modifier.weight(1f).padding(start = 4.dp)) {
                                Text(d.name, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                                Text(
                                    "${d.xe} ХЕ" + if (d.defaultGrams > 0) " · ${d.defaultGrams} г/мл" else "",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(onClick = { onDeleteDish(d) }, modifier = Modifier.size(32.dp)) {
                                Icon(Icons.Default.Delete, contentDescription = "Удалить", modifier = Modifier.size(18.dp))
                            }
                        }
                        HorizontalDivider()
                    }
                } else {
                    if (foodPlates.isEmpty()) {
                        item { Text("Тарелок пока нет. Нажмите «+ Добавить» и сфотографируйте пустую тарелку на весах.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    }
                    items(foodPlates, key = { it.id }) { pl ->
                        Row(
                            Modifier.fillMaxWidth().clickable { editingPlate = pl }.padding(vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(pl.name, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                                Text("Тара: ${pl.tareGrams} г", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            IconButton(onClick = { onDeletePlate(pl) }, modifier = Modifier.size(32.dp)) {
                                Icon(Icons.Default.Delete, contentDescription = "Удалить", modifier = Modifier.size(18.dp))
                            }
                        }
                        HorizontalDivider()
                    }
                }
            }
        }
    }

    if (editingDish != null) {
        DishEditorDialog(
            initialDish = editingDish!!,
            onSave = { d -> onSaveDish(d); editingDish = null },
            onDelete = { d -> if (d.id > 0L) onDeleteDish(d); editingDish = null },
            onDismiss = { editingDish = null }
        )
    }

    if (showNewPlate || editingPlate != null) {
        PlateEditorDialog(
            s = s,
            initialPlate = editingPlate,
            hasGeminiKey = hasGeminiKey,
            onOpenGeminiSettings = { showNewPlate = false; editingPlate = null; onOpenGeminiSettings() },
            onIdentifyPlatePhoto = onIdentifyPlatePhoto,
            onSave = { pl -> onSavePlate(pl); showNewPlate = false; editingPlate = null },
            onDelete = { pl -> onDeletePlate(pl); editingPlate = null },
            onDismiss = { showNewPlate = false; editingPlate = null }
        )
    }
}

@Composable
private fun DishEditorDialog(
    initialDish: FoodDish,
    onSave: (FoodDish) -> Unit,
    onDelete: (FoodDish) -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember(initialDish) { mutableStateOf(initialDish.name) }
    var xeStr by remember(initialDish) { mutableStateOf(if (initialDish.xe > 0.0) initialDish.xe.toString() else "") }
    var gramsStr by remember(initialDish) { mutableStateOf(if (initialDish.defaultGrams > 0) initialDish.defaultGrams.toString() else "") }
    var isFav by remember(initialDish) { mutableStateOf(initialDish.isFavorite) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initialDish.id > 0L) "Редактировать блюдо" else "Новое блюдо") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Название блюда") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                val deXe = (xeStr.replace(",", ".").toDoubleOrNull() ?: 0.0).coerceIn(0.0, 15.0)
                Slider(value = deXe.toFloat().coerceIn(0f, 12f), onValueChange = { xeStr = "%.1f".format(Locale.US, kotlin.math.round(it * 10.0) / 10.0) }, valueRange = 0f..12f)
                OutlinedTextField(value = xeStr, onValueChange = { xeStr = it }, label = { Text("ХЕ") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                val deGr = (gramsStr.toIntOrNull() ?: 0).coerceIn(0, 1000)
                Slider(value = deGr.toFloat(), onValueChange = { gramsStr = (kotlin.math.round(it / 10f) * 10f).toInt().toString() }, valueRange = 0f..1000f)
                OutlinedTextField(value = gramsStr, onValueChange = { gramsStr = it }, label = { Text("Порция по умолч. (г/мл, необяз.)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(Modifier.fillMaxWidth().clickable { isFav = !isFav }, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Постоянное блюдо (★ в начале списка)", fontSize = 13.sp)
                    Switch(checked = isFav, onCheckedChange = { isFav = it })
                }
            }
        },
        confirmButton = {
            val cb = LocalClipboardManager.current
            Row {
                TextButton(onClick = {
                    val gTxt = if (gramsStr.isNotBlank()) " (${gramsStr}г)" else ""
                    cb.setText(AnnotatedString("${name.trim()}$gTxt · ${xeStr} ХЕ"))
                }) { Text("Копировать") }
                TextButton(onClick = {
                    val n = name.trim()
                    if (n.isBlank()) return@TextButton
                    val xeVal = xeStr.replace(",", ".").toDoubleOrNull() ?: 0.0
                    val gVal = gramsStr.toIntOrNull() ?: 0
                    onSave(initialDish.copy(name = n, xe = xeVal, defaultGrams = gVal, isFavorite = isFav))
                }) { Text("Сохранить") }
            }
        },
        dismissButton = {
            Row {
                if (initialDish.id > 0L) {
                    TextButton(onClick = { onDelete(initialDish) }) { Text("Удалить", color = ColorHigh) }
                }
                TextButton(onClick = onDismiss) { Text("Отмена") }
            }
        }
    )
}

@Composable
private fun PlateEditorDialog(
    s: AppStrings,
    initialPlate: FoodPlate?,
    hasGeminiKey: Boolean,
    onOpenGeminiSettings: () -> Unit,
    onIdentifyPlatePhoto: suspend (String) -> PlateAnalysis?,
    onSave: (FoodPlate) -> Unit,
    onDelete: (FoodPlate) -> Unit,
    onDismiss: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var pName by remember(initialPlate) { mutableStateOf(initialPlate?.name ?: "") }
    var pTare by remember(initialPlate) { mutableStateOf(initialPlate?.tareGrams?.toString() ?: "") }
    var plateBmp by remember { mutableStateOf<Bitmap?>(null) }
    var plateB64 by remember { mutableStateOf("") }
    var platePhotoPath by remember(initialPlate) { mutableStateOf(initialPlate?.photoUri ?: "") }
    var isIdPlate by remember { mutableStateOf(false) }
    var plateAiStatus by remember { mutableStateOf("") }

    fun encodeBmp(bmp: Bitmap): String {
        val maxDim = 800
        val scale = minOf(maxDim.toFloat() / bmp.width, maxDim.toFloat() / bmp.height, 1f)
        val scaled = if (scale < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true) else bmp
        val baos = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 75, baos)
        return Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
    }

    fun decodeBmp(uri: Uri): Bitmap? {
        val raw = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: return null
        val orientation = try {
            ctx.contentResolver.openInputStream(uri)?.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL) }
                ?: ExifInterface.ORIENTATION_NORMAL
        } catch (_: Exception) { ExifInterface.ORIENTATION_NORMAL }
        val angle = when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        if (angle == 0f) return raw
        val m = Matrix().apply { postRotate(angle) }
        return Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
    }

    fun runPlateAi(b64: String) {
        if (b64.isBlank() || isIdPlate) return
        isIdPlate = true
        plateAiStatus = "Распознаю тарелку и вес..."
        scope.launch {
            val res = onIdentifyPlatePhoto(b64)
            isIdPlate = false
            if (res != null) {
                if (res.name.isNotBlank()) pName = res.name
                if (res.tareGrams != null && res.tareGrams > 0) pTare = res.tareGrams.toString()
                plateAiStatus = "Готово: ${res.name} (${res.tareGrams ?: "?"} г)"
            } else {
                plateAiStatus = "Не удалось распознать (проверьте Gemini API Key и Журнал отладки)"
            }
        }
    }

    fun processPlateBitmap(bmp: Bitmap) {
        plateBmp = bmp
        val b64 = encodeBmp(bmp)
        plateB64 = b64
        try {
            val outFile = java.io.File(ctx.filesDir, "plate_${System.currentTimeMillis()}.jpg")
            java.io.FileOutputStream(outFile).use { fos -> bmp.compress(Bitmap.CompressFormat.JPEG, 80, fos) }
            platePhotoPath = outFile.absolutePath
        } catch (_: Exception) {}
        runPlateAi(b64)
    }

    val plateCamLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bmp ->
        if (bmp != null) processPlateBitmap(bmp)
    }
    val plateGalLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) decodeBmp(uri)?.let { processPlateBitmap(it) }
    }

    FullScreenDialog(
        title = if (initialPlate != null) "Редактировать тарелку" else "Новая тарелка",
        onDismiss = onDismiss,
        actions = {
            val cb = LocalClipboardManager.current
            if (pName.isNotBlank()) {
                TextButton(onClick = { cb.setText(AnnotatedString("${pName.trim()} (тара ${pTare}г)")) }) { Text("Копировать") }
            }
            if (initialPlate != null) {
                TextButton(onClick = { onDelete(initialPlate) }) { Text("Удалить", color = ColorHigh) }
            }
            TextButton(onClick = {
                val g = pTare.toIntOrNull() ?: return@TextButton
                if (pName.isNotBlank()) {
                    onSave(
                        (initialPlate ?: FoodPlate(name = "", tareGrams = 0)).copy(
                            name = pName.trim(),
                            tareGrams = g,
                            photoUri = platePhotoPath
                        )
                    )
                }
            }) { Text(s.save, fontWeight = FontWeight.SemiBold) }
        }
    ) { innerPad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(innerPad).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { plateCamLauncher.launch(null) }, modifier = Modifier.weight(1f)) { Text("Камера", fontSize = 13.sp) }
                    OutlinedButton(onClick = { plateGalLauncher.launch("image/*") }, modifier = Modifier.weight(1f)) { Text("Галерея", fontSize = 13.sp) }
                }
            }
            if (plateBmp != null) {
                item {
                    Image(bitmap = plateBmp!!.asImageBitmap(), contentDescription = "Тарелка", contentScale = ContentScale.Fit, modifier = Modifier.fillMaxWidth().heightIn(min = 220.dp, max = 360.dp))
                    Button(
                        onClick = { runPlateAi(plateB64) },
                        enabled = !isIdPlate,
                        modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                    ) { Text(if (isIdPlate) "Распознаю..." else "Распознать по фото (ИИ)") }
                }
            }
            if (!hasGeminiKey) {
                item {
                    var showHintPlate by remember { mutableStateOf(false) }
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                "Gemini API Key не задан — как получить бесплатный ключ?",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.clickable { showHintPlate = !showHintPlate }
                            )
                            if (showHintPlate) {
                                val uriHandler = LocalUriHandler.current
                                Text("1. Откройте Google AI Studio и войдите в Google.\n2. Нажмите «Create API key» (без карты).\n3. Вставьте ключ (AQ... или AIza...) в Настройки → HA / ИИ.", fontSize = 11.sp)
                                Text("→ Открыть aistudio.google.com/apikey", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.clickable { uriHandler.openUri("https://aistudio.google.com/apikey") })
                            }
                            TextButton(onClick = onOpenGeminiSettings, contentPadding = PaddingValues(0.dp), modifier = Modifier.height(26.dp)) {
                                Text("Открыть Настройки → HA / ИИ", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
            if (plateAiStatus.isNotBlank()) {
                item { Text(plateAiStatus, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary) }
            }
            item {
                OutlinedTextField(value = pName, onValueChange = { pName = it }, label = { Text("Название (напр. Белая глубокая)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            }
            item {
                val ptVal = (pTare.toIntOrNull() ?: 300).coerceIn(50, 1200)
                Slider(value = ptVal.toFloat(), onValueChange = { pTare = (kotlin.math.round(it / 5f) * 5f).toInt().toString() }, valueRange = 50f..1200f)
                OutlinedTextField(value = pTare, onValueChange = { pTare = it }, label = { Text("Вес пустой тарелки (г)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            }
        }
    }
}

@Composable
private fun SettingsDialog(
    s: AppStrings,
    initialUrl: String,
    initialToken: String,
    initialGeminiKey: String,
    initialProfile: UserProfile,
    initialNorms: UserNorms,
    initialLang: AppLang,
    initialThemeMode: Int,
    initialLargeUi: Boolean,
    initialNotifSound: String,
    initialNotifRepeatMin: Int,
    initialNotifVolume: Int,
    initialDailyCheckEnabled: Boolean,
    initialDailyCheckTime: String,
    initialBleSound: String,
    initialBleVolume: Int,
    initialAiAdviceEnabled: Boolean,
    initialNotifGapMs: Int,
    initialTab: Int = 0,
    onSyncHa: () -> Unit,
    onExportBackup: () -> Unit,
    onImportBackup: () -> Unit,
    onOpenChangelog: () -> Unit,
    onForceExit: () -> Unit,
    onOpenTileConstructor: () -> Unit,
    onDismiss: () -> Unit,
    onSave: (String, String, String, UserProfile, UserNorms, AppLang, Int, Boolean, String, Int, Int, Boolean, String, String, Int, Boolean, Int) -> Unit
) {
    var tab by remember(initialTab) { mutableStateOf(initialTab) }
    var haUrl by remember { mutableStateOf(initialUrl) }
    var haToken by remember { mutableStateOf(initialToken) }
    var geminiKey by remember { mutableStateOf(initialGeminiKey) }
    var name by remember { mutableStateOf(initialProfile.name) }
    var age by remember { mutableStateOf(initialProfile.age.toString()) }
    var height by remember { mutableStateOf(initialProfile.heightCm.toString()) }
    var targetW by remember { mutableStateOf(initialProfile.targetWeightKg.toString()) }
    var city by remember { mutableStateOf(initialProfile.city) }
    var sysMax by remember { mutableStateOf(initialNorms.sysMax.toString()) }
    var sysMin by remember { mutableStateOf(initialNorms.sysMin.toString()) }
    var gluMax by remember { mutableStateOf(initialNorms.glucoseMax.toString()) }
    var gluMin by remember { mutableStateOf(initialNorms.glucoseMin.toString()) }
    var lang by remember { mutableStateOf(initialLang) }
    var themeMode by remember { mutableStateOf(initialThemeMode) }
    var largeUi by remember { mutableStateOf(initialLargeUi) }
    var notifSound by remember { mutableStateOf(initialNotifSound) }
    var notifRepeatMin by remember { mutableStateOf(initialNotifRepeatMin) }
    var notifVolume by remember { mutableStateOf(initialNotifVolume) }
    var dailyCheckEnabled by remember { mutableStateOf(initialDailyCheckEnabled) }
    var dailyCheckTime by remember { mutableStateOf(initialDailyCheckTime) }
    var bleSound by remember { mutableStateOf(initialBleSound) }
    var bleVolume by remember { mutableStateOf(initialBleVolume) }
    var aiAdviceEnabled by remember { mutableStateOf(initialAiAdviceEnabled) }
    var notifGapMs by remember { mutableStateOf(initialNotifGapMs) }

    FullScreenDialog(
        title = s.settings,
        onDismiss = onDismiss,
        actions = {
            IconButton(onClick = onForceExit) {
                Icon(Icons.Default.PowerSettingsNew, contentDescription = "Выход", tint = ColorHigh)
            }
            TextButton(onClick = {
                onSave(
                    haUrl, haToken, geminiKey,
                    UserProfile(name, age.toIntOrNull() ?: 59, height.toIntOrNull() ?: 178, targetW.toDoubleOrNull() ?: 85.0, city),
                    initialNorms.copy(
                        sysMin = sysMin.toIntOrNull() ?: 105, sysMax = sysMax.toIntOrNull() ?: 139,
                        glucoseMin = gluMin.replace(",", ".").toDoubleOrNull() ?: 3.9,
                        glucoseMax = gluMax.replace(",", ".").toDoubleOrNull() ?: 7.8
                    ),
                    lang,
                    themeMode,
                    largeUi,
                    notifSound,
                    notifRepeatMin,
                    notifVolume,
                    dailyCheckEnabled,
                    dailyCheckTime,
                    bleSound,
                    bleVolume,
                    aiAdviceEnabled,
                    notifGapMs
                )
            }) { Text(s.save, fontWeight = FontWeight.SemiBold) }
        }
    ) { innerPad ->
        Column(Modifier.fillMaxSize().padding(innerPad)) {
            TabRow(selectedTabIndex = tab) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Профиль", fontSize = 11.sp, maxLines = 1) })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Прилож.", fontSize = 11.sp, maxLines = 1) })
                Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("ИИ / HA", fontSize = 11.sp, maxLines = 1) })
                Tab(selected = tab == 3, onClick = { tab = 3 }, text = { Text("Интерф.", fontSize = 11.sp, maxLines = 1) })
            }
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                when (tab) {
                    0 -> {
                        Text("Личные данные", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Имя") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(value = age, onValueChange = { age = it }, label = { Text("Возраст") }, modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(value = height, onValueChange = { height = it }, label = { Text("Рост см") }, modifier = Modifier.weight(1f), singleLine = true)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(value = targetW, onValueChange = { targetW = it }, label = { Text("Цель кг") }, modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(value = city, onValueChange = { city = it }, label = { Text("Город (погода)") }, modifier = Modifier.weight(1f), singleLine = true)
                        }
                        HorizontalDivider(Modifier.padding(vertical = 4.dp))
                        Text("Индивидуальные нормы", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(value = sysMin, onValueChange = { sysMin = it }, label = { Text("SYS мин") }, modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(value = sysMax, onValueChange = { sysMax = it }, label = { Text("SYS макс") }, modifier = Modifier.weight(1f), singleLine = true)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(value = gluMin, onValueChange = { gluMin = it }, label = { Text("Сахар мин") }, modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(value = gluMax, onValueChange = { gluMax = it }, label = { Text("Сахар макс") }, modifier = Modifier.weight(1f), singleLine = true)
                        }
                    }
                    1 -> {
                        Text("Язык интерфейса", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            AppLang.values().forEach { l ->
                                FilterChip(selected = lang == l, onClick = { lang = l }, label = { Text(l.code.uppercase(), fontSize = 12.sp) })
                            }
                        }
                        HorizontalDivider(Modifier.padding(vertical = 2.dp))
                        OutlinedButton(onClick = onOpenTileConstructor, modifier = Modifier.fillMaxWidth()) { Text("Конструктор плиток (добавить / ред.)", fontSize = 13.sp) }
                        OutlinedButton(onClick = onExportBackup, modifier = Modifier.fillMaxWidth()) { Text(s.exportBackup, fontSize = 13.sp) }
                        OutlinedButton(onClick = onImportBackup, modifier = Modifier.fillMaxWidth()) { Text(s.importBackup, fontSize = 13.sp) }
                        OutlinedButton(onClick = onOpenChangelog, modifier = Modifier.fillMaxWidth()) { Text("О программе и история версий", fontSize = 13.sp) }
                    }
                    2 -> {
                        val uriHandler = LocalUriHandler.current
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("Зачем нужен ИИ (Gemini)?", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                                Text(
                                    "Без ключа программа полностью работает локально (приборы BLE, дневник, лекарства, погода). Бесплатный ключ Gemini включает:\n• Распознавание блюд по фото и дисплея весов + расчёт углеводов и ХЕ.\n• Расчёт ХЕ по текстовому описанию без фото.\n• Автоопределение пустых тарелок и веса тары по фото.\n• Подбор дозировок и назначения при добавлении лекарств.",
                                    fontSize = 12.sp
                                )
                            }
                        }
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("Как бесплатно получить и настроить ключ?", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                Text(
                                    "1. Нажмите на ссылку ниже и войдите в Google-аккаунт.\n2. Нажмите «Create API key» (банковская карта не требуется, бесплатного лимита хватает на сотни фото в день).\n3. Скопируйте ключ (начинается с AIza... или AQ...) и вставьте в поле ниже.\n4. Нажмите «Сохранить» в правом верхнем углу.",
                                    fontSize = 11.sp
                                )
                                Text(
                                    "→ Открыть Google AI Studio (aistudio.google.com/apikey)",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.clickable { uriHandler.openUri("https://aistudio.google.com/apikey") }
                                )
                            }
                        }
                        OutlinedTextField(value = geminiKey, onValueChange = { geminiKey = it }, label = { Text("Gemini API Key (бесплатный)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        Row(Modifier.fillMaxWidth().clickable { aiAdviceEnabled = !aiAdviceEnabled }, horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("ИИ-подсказки дня на главном экране", fontSize = 13.sp)
                            Switch(checked = aiAdviceEnabled, onCheckedChange = { aiAdviceEnabled = it })
                        }
                        HorizontalDivider(Modifier.padding(vertical = 4.dp))
                        Text("Home Assistant (опционально)", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                        OutlinedTextField(value = haUrl, onValueChange = { haUrl = it }, label = { Text("URL HA") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(value = haToken, onValueChange = { haToken = it }, label = { Text("Token HA") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedButton(onClick = onSyncHa, modifier = Modifier.fillMaxWidth()) { Text("Отправить замеры в HA", fontSize = 13.sp) }
                    }
                    else -> {
                        Text("Тема оформления", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(0 to "Системная", 1 to "Дневная", 2 to "Ночная").forEach { (mode, lbl) ->
                                FilterChip(
                                    selected = themeMode == mode,
                                    onClick = { themeMode = mode },
                                    label = { Text(lbl, fontSize = 12.sp) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                        HorizontalDivider(Modifier.padding(vertical = 4.dp))
                        Text("Доступность и читаемость", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                        Card(Modifier.fillMaxWidth().clickable { largeUi = !largeUi }) {
                            Row(
                                Modifier.fillMaxWidth().padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f).padding(end = 8.dp)) {
                                    Text("Крупный интерфейс", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                    Text("Увеличенный шрифт (+20%) на плитках, в хронике и во всех окнах", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Switch(checked = largeUi, onCheckedChange = { largeUi = it })
                            }
                        }
                        HorizontalDivider(Modifier.padding(vertical = 4.dp))
                        val ctxSound = LocalContext.current
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("Звук уведомлений", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                            TextButton(onClick = {
                                MedReminderReceiver.playSoundWithVolume(ctxSound, notifSound, notifVolume)
                            }, contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp), modifier = Modifier.height(28.dp)) {
                                Text("Проверить", fontSize = 12.sp)
                            }
                        }
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("chime" to "Колокольчик", "ping" to "Пинг", "triple" to "Тройной", "system" to "Системный", "mute" to "Без звука").forEach { (key, lbl) ->
                                FilterChip(
                                    selected = notifSound == key,
                                    onClick = { notifSound = key },
                                    label = { Text(lbl, fontSize = 11.sp) }
                                )
                            }
                        }
                        Text("Повтор сигнала (1→2→3→4 раза, далее «Не приняты»):", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(0 to "Выкл", 3 to "3 мин", 5 to "5 мин", 10 to "10 мин", 15 to "15 мин").forEach { (mins, lbl) ->
                                FilterChip(
                                    selected = notifRepeatMin == mins,
                                    onClick = {
                                        notifRepeatMin = mins
                                        if (mins > 0 && !MedReminderReceiver.canScheduleExact(ctxSound) && android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                                            try {
                                                ctxSound.startActivity(android.content.Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${ctxSound.packageName}")))
                                            } catch (_: Exception) {}
                                        }
                                    },
                                    label = { Text(lbl, fontSize = 11.sp) }
                                )
                            }
                        }
                        Text("Громкость сигнала: $notifVolume%", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        Slider(
                            value = notifVolume.toFloat().coerceIn(10f, 100f),
                            onValueChange = { notifVolume = (kotlin.math.round(it / 5f) * 5f).toInt().coerceIn(10, 100) },
                            valueRange = 10f..100f
                        )
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("Пауза между сигналами: $notifGapMs мс", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            TextButton(onClick = {
                                MedReminderReceiver.playSoundWithVolume(ctxSound, notifSound, notifVolume, repeatCount = 2, gapMs = notifGapMs)
                            }, contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp), modifier = Modifier.height(28.dp)) {
                                Text("Тест 2×", fontSize = 12.sp)
                            }
                        }
                        Slider(
                            value = notifGapMs.toFloat().coerceIn(100f, 1000f),
                            onValueChange = { notifGapMs = (kotlin.math.round(it / 50f) * 50f).toInt().coerceIn(100, 1000) },
                            valueRange = 100f..1000f
                        )
                        val exactOk = MedReminderReceiver.canScheduleExact(ctxSound)
                        if (!exactOk && android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                            OutlinedButton(
                                onClick = {
                                    try {
                                        ctxSound.startActivity(android.content.Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${ctxSound.packageName}")))
                                    } catch (_: Exception) {}
                                },
                                modifier = Modifier.fillMaxWidth(),
                                border = BorderStroke(1.dp, ColorHigh)
                            ) { Text("Разрешить точные будильники →", color = ColorHigh, fontSize = 12.sp) }
                        } else {
                            Text("Точные будильники: Разрешены ✓", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                        }
                        HorizontalDivider(Modifier.padding(vertical = 4.dp))
                        Card(Modifier.fillMaxWidth().clickable { dailyCheckEnabled = !dailyCheckEnabled }) {
                            Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f).padding(end = 8.dp)) {
                                    Text("Вечерняя проверка дня", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                    Text("Проверка препаратов, инсулина и замеров с итоговым отчётом", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Checkbox(checked = dailyCheckEnabled, onCheckedChange = { dailyCheckEnabled = it })
                            }
                        }
                        if (dailyCheckEnabled) {
                            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf("20:00", "20:30", "21:00", "21:30", "22:00").forEach { tm ->
                                    FilterChip(selected = dailyCheckTime == tm, onClick = { dailyCheckTime = tm }, label = { Text(tm, fontSize = 11.sp) })
                                }
                            }
                            OutlinedTextField(
                                value = dailyCheckTime,
                                onValueChange = { dailyCheckTime = it },
                                label = { Text("Время вечерней проверки (ЧЧ:ММ)") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        HorizontalDivider(Modifier.padding(vertical = 4.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("Сигнал приёма данных (BLE)", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                            TextButton(onClick = {
                                MedReminderReceiver.playSoundWithVolume(ctxSound, bleSound, bleVolume)
                            }, contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp), modifier = Modifier.height(28.dp)) {
                                Text("Проверить", fontSize = 12.sp)
                            }
                        }
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("chime" to "Колокольчик", "ping" to "Пинг", "triple" to "Тройной", "system" to "Системный", "mute" to "Без звука").forEach { (key, lbl) ->
                                FilterChip(
                                    selected = bleSound == key,
                                    onClick = { bleSound = key },
                                    label = { Text(lbl, fontSize = 11.sp) }
                                )
                            }
                        }
                        Text("Громкость приёма BLE: $bleVolume%", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        Slider(
                            value = bleVolume.toFloat().coerceIn(10f, 100f),
                            onValueChange = { bleVolume = (kotlin.math.round(it / 5f) * 5f).toInt().coerceIn(10, 100) },
                            valueRange = 10f..100f
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = onForceExit, modifier = Modifier.fillMaxWidth(), border = BorderStroke(1.dp, ColorHigh)) {
                    Text("Выход из программы (остановить BLE)", color = ColorHigh, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
private fun LogsDialog(onDismiss: () -> Unit) {
    val logs by AppLogger.logs.collectAsState()
    val clipboard = LocalClipboardManager.current
    FullScreenDialog(
        title = "Журнал отладки",
        onDismiss = onDismiss,
        actions = {
            TextButton(onClick = { clipboard.setText(AnnotatedString(logs.joinToString("\n"))) }) { Text("Копировать") }
        }
    ) { innerPad ->
        LazyColumn(Modifier.fillMaxSize().padding(innerPad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            items(logs.reversed()) { line -> Text(line, fontSize = 12.sp) }
        }
    }
}

@Composable
private fun TactileTileAction(
    label: String,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.91f else 1.0f, label = "tactileTile")
    Surface(
        modifier = Modifier
            .scale(scale)
            .clip(RoundedCornerShape(50))
            .clickable(
                interactionSource = interactionSource,
                indication = LocalIndication.current,
                onClick = onClick
            ),
        shape = RoundedCornerShape(50),
        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = if (pressed) 0.9f else 0.55f),
        border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f))
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        ) {
            Text(
                text = label,
                fontSize = 11.sp,
                lineHeight = 12.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.primary,
                textAlign = TextAlign.Center,
                maxLines = 1,
                softWrap = false,
                style = LocalTextStyle.current.copy(
                    platformStyle = PlatformTextStyle(includeFontPadding = false),
                    lineHeightStyle = LineHeightStyle(
                        alignment = LineHeightStyle.Alignment.Center,
                        trim = LineHeightStyle.Trim.Both
                    )
                )
            )
        }
    }
}

@Composable
private fun TactileOutlinedPill(
    label: String,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.92f else 1.0f, label = "tactilePill")
    OutlinedButton(
        onClick = onClick,
        interactionSource = interactionSource,
        modifier = Modifier.heightIn(min = 26.dp).scale(scale),
        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                label,
                fontSize = 11.sp,
                lineHeight = 12.sp,
                textAlign = TextAlign.Center,
                maxLines = 1,
                softWrap = false,
                style = LocalTextStyle.current.copy(
                    platformStyle = PlatformTextStyle(includeFontPadding = false),
                    lineHeightStyle = LineHeightStyle(
                        alignment = LineHeightStyle.Alignment.Center,
                        trim = LineHeightStyle.Trim.Both
                    )
                )
            )
        }
    }
}

@Composable
private fun TileConstructorDialog(
    tileOrder: List<Int>,
    customTiles: List<CustomTileDef>,
    onSaveOrder: (List<Int>) -> Unit,
    onSaveCustom: (List<CustomTileDef>) -> Unit,
    onDismiss: () -> Unit
) {
    var editingTile by remember { mutableStateOf<CustomTileDef?>(null) }
    var showCreate by remember { mutableStateOf(false) }

    val stdNames = mapOf(
        0 to "Сахар / Инсулин",
        1 to "Давление / Пульс",
        2 to "Вес / Вода",
        3 to "Шаги / Сон"
    )

    FullScreenDialog(
        title = "Конструктор плиток",
        onDismiss = onDismiss,
        actions = {
            IconButton(onClick = { showCreate = true }) { Icon(Icons.Default.Add, contentDescription = "Добавить плитку") }
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showCreate = true }) { Icon(Icons.Default.Add, contentDescription = "Добавить плитку") }
        }
    ) { innerPad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(innerPad).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item { Text("Стандартные плитки (порядок и видимость):", fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
            items(listOf(0, 1, 2, 3)) { id ->
                val enabled = id in tileOrder
                Row(
                    Modifier.fillMaxWidth().clickable {
                        val next = if (enabled && tileOrder.size > 1) tileOrder - id else if (!enabled) tileOrder + id else tileOrder
                        onSaveOrder(next)
                    }.padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(checked = enabled, onCheckedChange = {
                        val next = if (enabled && tileOrder.size > 1) tileOrder - id else if (!enabled) tileOrder + id else tileOrder
                        onSaveOrder(next)
                    })
                    Text(stdNames[id] ?: "Плитка $id", fontSize = 14.sp)
                }
            }
            item {
                Spacer(Modifier.height(6.dp))
                Text("Пользовательские плитки (${customTiles.size}):", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
            if (customTiles.isEmpty()) {
                item { Text("Нажмите «+», чтобы создать свою плитку (напр. SpO2 / Температура)", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            } else {
                items(customTiles) { ct ->
                    Card(Modifier.fillMaxWidth().clickable { editingTile = ct }) {
                        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("${ct.topLabel} (${ct.topUnit}) / ${ct.bottomLabel.ifBlank { "—" }} ${ct.bottomUnit}".trim(), fontSize = 14.sp, fontWeight = FontWeight.Medium)
                                if (ct.topMin != null || ct.topMax != null) {
                                    Text("Норма: ${ct.topMin ?: "—"} .. ${ct.topMax ?: "—"}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            IconButton(onClick = { onSaveCustom(customTiles.filterNot { it.id == ct.id }) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Удалить")
                            }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(72.dp)) }
        }
    }

    if (showCreate || editingTile != null) {
        val init = editingTile
        var topL by remember(init) { mutableStateOf(init?.topLabel ?: "") }
        var topU by remember(init) { mutableStateOf(init?.topUnit ?: "") }
        var botL by remember(init) { mutableStateOf(init?.bottomLabel ?: "") }
        var botU by remember(init) { mutableStateOf(init?.bottomUnit ?: "") }
        var minStr by remember(init) { mutableStateOf(init?.topMin?.toString() ?: "") }
        var maxStr by remember(init) { mutableStateOf(init?.topMax?.toString() ?: "") }

        FullScreenDialog(
            title = if (init == null) "Новая плитка" else "Редактировать плитку",
            onDismiss = { showCreate = false; editingTile = null },
            actions = {
                TextButton(onClick = {
                    if (topL.isBlank()) return@TextButton
                    val def = CustomTileDef(
                        id = init?.id ?: "ct_${System.currentTimeMillis()}",
                        topLabel = topL.trim(),
                        topUnit = topU.trim(),
                        bottomLabel = botL.trim(),
                        bottomUnit = botU.trim(),
                        topMin = minStr.replace(",", ".").toDoubleOrNull(),
                        topMax = maxStr.replace(",", ".").toDoubleOrNull()
                    )
                    val next = if (init == null) customTiles + def else customTiles.map { if (it.id == init.id) def else it }
                    onSaveCustom(next)
                    showCreate = false; editingTile = null
                }) { Text("Сохранить", fontWeight = FontWeight.SemiBold) }
            }
        ) { innerPad ->
            Column(Modifier.fillMaxSize().padding(innerPad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = topL, onValueChange = { topL = it }, label = { Text("Верхний показатель (напр. SpO2)") }, modifier = Modifier.weight(1.4f), singleLine = true)
                    OutlinedTextField(value = topU, onValueChange = { topU = it }, label = { Text("Ед. (%)") }, modifier = Modifier.weight(0.6f), singleLine = true)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = botL, onValueChange = { botL = it }, label = { Text("Нижний (напр. Темп.)") }, modifier = Modifier.weight(1.4f), singleLine = true)
                    OutlinedTextField(value = botU, onValueChange = { botU = it }, label = { Text("Ед. (°C)") }, modifier = Modifier.weight(0.6f), singleLine = true)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = minStr, onValueChange = { minStr = it }, label = { Text("Норма мин") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(value = maxStr, onValueChange = { maxStr = it }, label = { Text("Норма макс") }, modifier = Modifier.weight(1f), singleLine = true)
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AiAdviceChatDialog(
    dayContext: String,
    initialAdvice: String,
    onAskChat: suspend (String, List<Pair<Boolean, String>>, String) -> String?,
    onDismiss: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    val messages = remember {
        mutableStateListOf<Pair<Boolean, String>>().apply {
            if (initialAdvice.isNotBlank()) add(false to initialAdvice)
        }
    }
    var inputText by remember { mutableStateOf("") }
    var isSending by remember { mutableStateOf(false) }

    fun sendMsg(txt: String) {
        val q = txt.trim()
        if (q.isBlank() || isSending) return
        val histSnapshot = messages.toList()
        messages.add(true to q)
        inputText = ""
        isSending = true
        scope.launch {
            val reply = onAskChat(dayContext, histSnapshot, q)
            isSending = false
            messages.add(false to (reply?.ifBlank { null } ?: "Не удалось получить ответ (проверьте интернет и ключ Gemini)."))
        }
    }

    FullScreenDialog(
        title = "Диалог с ИИ",
        onDismiss = onDismiss,
        actions = {
            if (messages.isNotEmpty()) {
                TextButton(onClick = {
                    val fullTxt = messages.joinToString("\n\n") { (isU, m) -> if (isU) "Вы: $m" else "ИИ: $m" }
                    clipboard.setText(AnnotatedString(fullTxt))
                }) { Text("Копировать") }
            }
        }
    ) { innerPad ->
        Column(Modifier.fillMaxSize().padding(innerPad).padding(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Card(Modifier.fillMaxWidth()) {
                Text("Контекст дня: $dayContext", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(10.dp))
            }
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(messages) { (isUser, msg) ->
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                    ) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.widthIn(max = 300.dp).combinedClickable(
                                onClick = {},
                                onLongClick = { clipboard.setText(AnnotatedString(msg)) }
                            )
                        ) {
                            Text(
                                msg,
                                fontSize = 13.sp,
                                color = if (isUser) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                            )
                        }
                    }
                }
                if (isSending) {
                    item {
                        Text("ИИ печатает...", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Почему так?", "Что лучше поесть?", "Что проверить?").forEach { q ->
                    AssistChip(onClick = { sendMsg(q) }, label = { Text(q, fontSize = 11.sp) })
                }
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    label = { Text("Ваш вопрос ИИ...") },
                    modifier = Modifier.weight(1f),
                    maxLines = 3
                )
                FilledIconButton(
                    onClick = { sendMsg(inputText) },
                    enabled = !isSending && inputText.isNotBlank()
                ) {
                    Icon(Icons.Default.Send, contentDescription = "Отправить")
                }
            }
        }
    }
}
