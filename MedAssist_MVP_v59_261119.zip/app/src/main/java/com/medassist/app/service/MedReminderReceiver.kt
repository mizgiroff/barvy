package com.medassist.app.service

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import com.medassist.app.MainActivity
import com.medassist.app.R
import com.medassist.app.data.DataSource
import com.medassist.app.data.MedDatabase
import com.medassist.app.data.MedicationEvent
import com.medassist.app.data.VitalEntry
import com.medassist.app.data.VitalType
import com.medassist.app.util.AppLogger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.util.Calendar

class MedReminderReceiver : BroadcastReceiver() {
    companion object {
        const val ACTION_SHOW_REMINDER = "com.medassist.app.SHOW_REMINDER"
        const val ACTION_MISSED_MED = "com.medassist.app.MISSED_MED"
        const val ACTION_TAKE_MED = "com.medassist.app.TAKE_MED"
        const val ACTION_DAILY_CHECK = "com.medassist.app.DAILY_CHECK"
        const val EXTRA_MED_ID = "med_id"
        const val EXTRA_PKG_ID = "pkg_id"
        const val EXTRA_PKG_MED_IDS = "pkg_med_ids"
        const val EXTRA_MED_NAME = "med_name"
        const val EXTRA_MED_DOSE = "med_dose"
        const val EXTRA_COUNT = "med_count"
        const val EXTRA_ATTEMPT = "attempt"

        fun canScheduleExact(context: Context): Boolean {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            return am.canScheduleExactAlarms()
        }

        private fun setExact(am: AlarmManager, triggerAt: Long, pi: PendingIntent) {
            try {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
            } catch (_: SecurityException) {
                am.set(AlarmManager.RTC_WAKEUP, triggerAt, pi)
            }
        }

        fun cancelRepeat(context: Context, keyId: Long) {
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            listOf(ACTION_SHOW_REMINDER, ACTION_MISSED_MED).forEach { act ->
                val intent = Intent(context, MedReminderReceiver::class.java).apply { action = act }
                val pi = PendingIntent.getBroadcast(
                    context,
                    2000 + keyId.toInt(),
                    intent,
                    PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
                )
                if (pi != null) am.cancel(pi)
            }
        }

        private fun scheduleNextRepeat(
            context: Context,
            action: String,
            medId: Long,
            pkgId: Long,
            pkgMedIds: String,
            name: String,
            dose: String,
            count: Double,
            nextAttempt: Int,
            delayMs: Long
        ) {
            val keyId = if (pkgId > 0L) 3000L + pkgId else medId
            val intent = Intent(context, MedReminderReceiver::class.java).apply {
                this.action = action
                putExtra(EXTRA_MED_ID, medId)
                putExtra(EXTRA_PKG_ID, pkgId)
                putExtra(EXTRA_PKG_MED_IDS, pkgMedIds)
                putExtra(EXTRA_MED_NAME, name)
                putExtra(EXTRA_MED_DOSE, dose)
                putExtra(EXTRA_COUNT, count)
                putExtra(EXTRA_ATTEMPT, nextAttempt)
            }
            val pi = PendingIntent.getBroadcast(
                context,
                2000 + keyId.toInt(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            setExact(am, System.currentTimeMillis() + delayMs, pi)
            AppLogger.log("ALM", "Повтор #$nextAttempt для '$name' через ${delayMs / 60000} мин")
        }

        fun scheduleForMed(context: Context, medId: Long, name: String, dose: String, count: Double, timeHHmm: String) {
            if (timeHHmm.isBlank() || timeHHmm.contains("необходим", ignoreCase = true)) {
                val intent = Intent(context, MedReminderReceiver::class.java).apply { action = ACTION_SHOW_REMINDER }
                val pi = PendingIntent.getBroadcast(context, medId.toInt(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi)
                return
            }
            val parts = timeHHmm.split(":")
            val hour = parts.getOrNull(0)?.toIntOrNull() ?: return
            val min = parts.getOrNull(1)?.toIntOrNull() ?: return

            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hour)
                set(Calendar.MINUTE, min)
                set(Calendar.SECOND, 0)
                if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
            }
            val intent = Intent(context, MedReminderReceiver::class.java).apply {
                action = ACTION_SHOW_REMINDER
                putExtra(EXTRA_MED_ID, medId)
                putExtra(EXTRA_PKG_ID, 0L)
                putExtra(EXTRA_PKG_MED_IDS, "")
                putExtra(EXTRA_MED_NAME, name)
                putExtra(EXTRA_MED_DOSE, dose)
                putExtra(EXTRA_COUNT, count)
                putExtra(EXTRA_ATTEMPT, 1)
            }
            val pi = PendingIntent.getBroadcast(context, medId.toInt(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            setExact(context.getSystemService(Context.ALARM_SERVICE) as AlarmManager, cal.timeInMillis, pi)
        }

        fun scheduleForPackage(context: Context, pkgId: Long, pkgName: String, medIdsCsv: String, timeHHmm: String) {
            val reqCode = 3000 + pkgId.toInt()
            if (timeHHmm.isBlank() || timeHHmm.contains("необходим", ignoreCase = true)) {
                val intent = Intent(context, MedReminderReceiver::class.java).apply { action = ACTION_SHOW_REMINDER }
                val pi = PendingIntent.getBroadcast(context, reqCode, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi)
                return
            }
            val parts = timeHHmm.split(":")
            val hour = parts.getOrNull(0)?.toIntOrNull() ?: return
            val min = parts.getOrNull(1)?.toIntOrNull() ?: return

            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hour)
                set(Calendar.MINUTE, min)
                set(Calendar.SECOND, 0)
                if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
            }
            val cnt = medIdsCsv.split(",").mapNotNull { it.toLongOrNull() }.size
            val intent = Intent(context, MedReminderReceiver::class.java).apply {
                action = ACTION_SHOW_REMINDER
                putExtra(EXTRA_MED_ID, 0L)
                putExtra(EXTRA_PKG_ID, pkgId)
                putExtra(EXTRA_PKG_MED_IDS, medIdsCsv)
                putExtra(EXTRA_MED_NAME, pkgName)
                putExtra(EXTRA_MED_DOSE, "$cnt преп.")
                putExtra(EXTRA_COUNT, cnt.toDouble())
                putExtra(EXTRA_ATTEMPT, 1)
            }
            val pi = PendingIntent.getBroadcast(context, reqCode, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            setExact(context.getSystemService(Context.ALARM_SERVICE) as AlarmManager, cal.timeInMillis, pi)
        }

        fun scheduleDailyCheck(context: Context, enabled: Boolean, timeHHmm: String) {
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val intent = Intent(context, MedReminderReceiver::class.java).apply { action = ACTION_DAILY_CHECK }
            val pi = PendingIntent.getBroadcast(context, 9001, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            if (!enabled) {
                am.cancel(pi)
                return
            }
            val parts = timeHHmm.split(":")
            val hour = parts.getOrNull(0)?.toIntOrNull() ?: 21
            val min = parts.getOrNull(1)?.toIntOrNull() ?: 0
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hour)
                set(Calendar.MINUTE, min)
                set(Calendar.SECOND, 0)
                if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
            }
            setExact(am, cal.timeInMillis, pi)
        }

        fun notifyBleData(context: Context, title: String, body: String) {
            val prefs = context.getSharedPreferences("medassist_prefs", Context.MODE_PRIVATE)
            val soundKey = prefs.getString("ble_notif_sound", "ping") ?: "ping"
            val volumePct = prefs.getInt("ble_notif_volume", 80)
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channelId = if (soundKey == "system") "medassist_ble_sys" else "medassist_ble_custom"
            val ch = NotificationChannel(channelId, "Приём данных с приборов BLE", NotificationManager.IMPORTANCE_HIGH).apply {
                if (soundKey != "system") setSound(null, null)
            }
            nm.createNotificationChannel(ch)
            val openPi = PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            val notif = NotificationCompat.Builder(context, channelId)
                .setSmallIcon(R.drawable.ic_stat_medassist)
                .setColor(0xFF1565C0.toInt())
                .setContentTitle(title)
                .setContentText(body)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(openPi)
                .build()
            nm.notify(8001, notif)
            if (soundKey != "mute" && soundKey != "system") {
                playSoundWithVolume(context, soundKey, volumePct)
            }
        }

        private fun playSingleBlocking(context: Context, soundKey: String, volumePct: Int): Long {
            if (soundKey == "mute") return 0L
            val vol = (volumePct / 100f).coerceIn(0.1f, 1.0f)
            return try {
                val resId = when (soundKey) {
                    "chime" -> R.raw.notif_chime
                    "ping" -> R.raw.notif_ping
                    "triple" -> R.raw.notif_triple
                    else -> 0
                }
                if (resId != 0) {
                    val afd = context.resources.openRawResourceFd(resId) ?: return 0L
                    val mp = MediaPlayer()
                    mp.setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    mp.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                    afd.close()
                    mp.setVolume(vol, vol)
                    mp.setOnCompletionListener { it.release() }
                    mp.prepare()
                    val dur = mp.duration.toLong().coerceIn(200L, 2000L)
                    mp.start()
                    dur
                } else {
                    val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                    RingtoneManager.getRingtone(context, uri)?.play()
                    500L
                }
            } catch (_: Exception) { 0L }
        }

        private val soundLock = Any()
        @Volatile private var lastMedSoundAtMs = 0L

        fun tryAcquireSoundSlot(context: Context, cooldownMs: Long = 5_000L): Boolean {
            synchronized(soundLock) {
                val prefs = context.getSharedPreferences("medassist_prefs", Context.MODE_PRIVATE)
                val now = System.currentTimeMillis()
                val last = maxOf(lastMedSoundAtMs, prefs.getLong("last_med_sound_ms", 0L))
                if (now - last < cooldownMs) return false
                lastMedSoundAtMs = now
                prefs.edit().putLong("last_med_sound_ms", now).apply()
                return true
            }
        }

        suspend fun recordInsulinVitalIfMedIsInsulin(
            context: Context,
            dao: com.medassist.app.data.MedDao,
            medName: String,
            dosage: String,
            effect: String,
            takenCount: Double,
            dateKey: String
        ) {
            val isIns = medName.contains("тожео", true) || medName.contains("инсулин", true) || effect.contains("инсулин", true)
            if (!isIns) return
            val now = System.currentTimeMillis()
            val recent = dao.getAllVitals().any { it.dateKey == dateKey && it.type == VitalType.INSULIN && kotlin.math.abs(now - it.timestamp) < 10 * 60_000L }
            if (recent) return
            val match = Regex("(\\d+(?:[.,]\\d+)?)\\s*(?:ед|u|iu|ed)", RegexOption.IGNORE_CASE).find(dosage)
            val baseUnits = match?.groupValues?.get(1)?.replace(",", ".")?.toDoubleOrNull()
                ?: context.getSharedPreferences("medassist_prefs", Context.MODE_PRIVATE).getFloat("last_ins", 40f).toDouble()
            val units = kotlin.math.round(baseUnits * takenCount * 10.0) / 10.0
            if (units > 0.0) {
                dao.insertVital(VitalEntry(timestamp = now, dateKey = dateKey, type = VitalType.INSULIN, value1 = units, source = DataSource.MANUAL, note = medName))
            }
        }

        fun playSoundWithVolume(context: Context, soundKey: String, volumePct: Int, repeatCount: Int = 1, gapMs: Int = 250) {
            if (soundKey == "mute") return
            CoroutineScope(Dispatchers.IO).launch {
                repeat(repeatCount.coerceAtLeast(1)) { idx ->
                    if (idx > 0) delay(gapMs.toLong().coerceAtLeast(50L))
                    val dur = playSingleBlocking(context, soundKey, volumePct)
                    if (idx < repeatCount - 1 && dur > 0L) delay(dur)
                }
            }
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        val prefs = context.getSharedPreferences("medassist_prefs", Context.MODE_PRIVATE)
        val soundKey = prefs.getString("notif_sound", "chime") ?: "chime"
        val volumePct = prefs.getInt("notif_volume", 80)
        val repeatMin = prefs.getInt("notif_repeat_min", 0)
        val gapMs = prefs.getInt("notif_gap_ms", 250)
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val channelId = if (soundKey == "system") "medassist_rem_sys" else "medassist_rem_custom"
        val ch = NotificationChannel(channelId, "Напоминания о лекарствах", NotificationManager.IMPORTANCE_HIGH).apply {
            if (soundKey != "system") setSound(null, null)
        }
        nm.createNotificationChannel(ch)

        if (intent.action == ACTION_DAILY_CHECK) {
            val checkEnabled = prefs.getBoolean("daily_check_enabled", true)
            val checkTime = prefs.getString("daily_check_time", "21:00") ?: "21:00"
            if (checkEnabled) scheduleDailyCheck(context, true, checkTime)

            val pendingResult = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val dao = MedDatabase.get(context).dao()
                    val todayKey = LocalDate.now().toString()
                    val meds = dao.getAllMedications().filter { it.reminderEnabled && !it.scheduleTime.contains("необходим", true) && it.scheduleTime.contains(":") }
                    val eventsToday = dao.getAllMeds().filter { it.dateKey == todayKey }
                    val vitalsToday = dao.getAllVitals().filter { it.dateKey == todayKey }
                    val ctxToday = dao.getDailyContext(todayKey)

                    val takenMedIds = eventsToday.map { it.medId }.toMutableSet()
                    val missing = mutableListOf<String>()
                    val hasInsulinToday = vitalsToday.any { it.type == VitalType.INSULIN && it.value1 > 0.0 }
                    meds.forEach { m ->
                        if (m.id !in takenMedIds) {
                            val isInsMed = m.name.contains("тожео", true) || m.name.contains("инсулин", true) || m.effect.contains("инсулин", true)
                            val covered = (isInsMed && hasInsulinToday) || eventsToday.any { it.slot.startsWith("PKG_") && it.medName.isNotBlank() }
                            if (!covered) missing.add(m.name)
                        }
                    }
                    if (vitalsToday.none { it.type == VitalType.GLUCOSE }) missing.add("Сахар")
                    if (vitalsToday.none { it.type == VitalType.BP }) missing.add("Давление")
                    if (vitalsToday.none { it.type == VitalType.WEIGHT }) missing.add("Вес")
                    if (vitalsToday.none { it.type == VitalType.WATER }) missing.add("Вода")
                    if (vitalsToday.none { it.type == VitalType.FOOD }) missing.add("Питание")
                    if ((ctxToday?.steps ?: 0L) <= 0L) missing.add("Шаги")

                    val title = if (missing.isEmpty()) "Итог дня: всё принято и замерено ✓" else "Итог дня: пропущено (${missing.size})"
                    val body = if (missing.isEmpty()) "Все плановые препараты, инсулин и замеры за $todayKey выполнены." else "Не отмечено: ${missing.joinToString(", ")}"

                    val openPi = PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
                    val notif = NotificationCompat.Builder(context, channelId)
                        .setSmallIcon(R.drawable.ic_stat_medassist)
                        .setColor(if (missing.isEmpty()) 0xFF2E7D32.toInt() else 0xFFD32F2F.toInt())
                        .setContentTitle(title)
                        .setContentText(body)
                        .setStyle(NotificationCompat.BigTextStyle().bigText(body))
                        .setPriority(NotificationCompat.PRIORITY_HIGH)
                        .setAutoCancel(true)
                        .setContentIntent(openPi)
                        .build()
                    nm.notify(9001, notif)
                    if (tryAcquireSoundSlot(context)) {
                        playSoundWithVolume(context, soundKey, volumePct)
                    }
                    AppLogger.log("CHK", "$title — $body")
                } finally {
                    pendingResult.finish()
                }
            }
            return
        }

        val medId = intent.getLongExtra(EXTRA_MED_ID, 0L)
        val pkgId = intent.getLongExtra(EXTRA_PKG_ID, 0L)
        val pkgMedIds = intent.getStringExtra(EXTRA_PKG_MED_IDS) ?: ""
        val medName = intent.getStringExtra(EXTRA_MED_NAME) ?: "Препарат"
        val medDose = intent.getStringExtra(EXTRA_MED_DOSE) ?: ""
        val count = intent.getDoubleExtra(EXTRA_COUNT, 1.0)
        val attempt = intent.getIntExtra(EXTRA_ATTEMPT, 1).coerceIn(1, 4)
        val keyId = if (pkgId > 0L) 3000L + pkgId else medId
        val notifId = 1000 + keyId.toInt()

        suspend fun isAlreadyTakenToday(dao: com.medassist.app.data.MedDao, medId: Long, pkgId: Long): Boolean {
            val todayKey = LocalDate.now().toString()
            val eventsToday = dao.getAllMeds().filter { it.dateKey == todayKey }
            if (pkgId > 0L) return eventsToday.any { it.slot == "PKG_$pkgId" }
            if (eventsToday.any { it.medId == medId }) return true
            if (medId > 0L) {
                val med = dao.getMedicationById(medId)
                if (med != null && (med.name.contains("тожео", true) || med.name.contains("инсулин", true) || med.effect.contains("инсулин", true))) {
                    val hasInsulinToday = dao.getAllVitals().any { it.dateKey == todayKey && it.type == VitalType.INSULIN && it.value1 > 0.0 }
                    if (hasInsulinToday) return true
                }
            }
            val pkgs = dao.getAllPackages()
            val takenPkgIds = eventsToday.filter { it.slot.startsWith("PKG_") }.mapNotNull { it.slot.removePrefix("PKG_").toLongOrNull() }.toSet()
            return pkgs.any { it.id in takenPkgIds && medId in it.medIdsCsv.split(",").mapNotNull { id -> id.toLongOrNull() } }
        }

        if (intent.action == ACTION_TAKE_MED) {
            nm.cancel(notifId)
            cancelRepeat(context, keyId)
            val pendingResult = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val dao = MedDatabase.get(context).dao()
                    if (isAlreadyTakenToday(dao, medId, pkgId)) {
                        AppLogger.log("MED", "Повторный приём проигнорирован (уже принято): $medName")
                        return@launch
                    }
                    if (pkgId > 0L) {
                        val ids = pkgMedIds.split(",").mapNotNull { it.toLongOrNull() }
                        ids.forEach { mid ->
                            nm.cancel(1000 + mid.toInt())
                            cancelRepeat(context, mid)
                            dao.getMedicationById(mid)?.let { m ->
                                dao.upsertMedication(m.copy(stockLeft = (m.stockLeft - m.countPerIntake).coerceAtLeast(0.0)))
                            }
                        }
                        dao.insertMedicationEvent(
                            MedicationEvent(medId = 0, dateKey = LocalDate.now().toString(), slot = "PKG_$pkgId", medName = medName, dose = "${ids.size} преп.")
                        )
                    } else {
                        val item = dao.getMedicationById(medId)
                        if (item != null) {
                            dao.upsertMedication(item.copy(stockLeft = (item.stockLeft - item.countPerIntake).coerceAtLeast(0.0)))
                        }
                        val dk = LocalDate.now().toString()
                        dao.insertMedicationEvent(
                            MedicationEvent(medId = medId, dateKey = dk, slot = "SCHEDULE", medName = medName, dose = "$count шт ($medDose)")
                        )
                        recordInsulinVitalIfMedIsInsulin(context, dao, medName, medDose, item?.effect ?: "", count, dk)
                    }
                    AppLogger.log("MED", "Принято из уведомления: $medName")
                    nm.cancel(notifId)
                } finally {
                    pendingResult.finish()
                }
            }
        } else if (intent.action == ACTION_SHOW_REMINDER) {
            val pendingResult = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val dao = MedDatabase.get(context).dao()
                    if (isAlreadyTakenToday(dao, medId, pkgId)) {
                        nm.cancel(notifId)
                        cancelRepeat(context, keyId)
                        AppLogger.log("ALM", "Напоминание отменено (уже принято): $medName")
                        return@launch
                    }
                    val takeIntent = Intent(context, MedReminderReceiver::class.java).apply {
                        action = ACTION_TAKE_MED
                        putExtra(EXTRA_MED_ID, medId)
                        putExtra(EXTRA_PKG_ID, pkgId)
                        putExtra(EXTRA_PKG_MED_IDS, pkgMedIds)
                        putExtra(EXTRA_MED_NAME, medName)
                        putExtra(EXTRA_MED_DOSE, medDose)
                        putExtra(EXTRA_COUNT, count)
                    }
                    val takePi = PendingIntent.getBroadcast(
                        context,
                        5000 + keyId.toInt(),
                        takeIntent,
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                    )
                    val openPi = PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
                    val repeatBadge = if (attempt > 1) " (повтор $attempt/4)" else ""
                    val notif = NotificationCompat.Builder(context, channelId)
                        .setSmallIcon(R.drawable.ic_stat_medassist)
                        .setColor(0xFF1565C0.toInt())
                        .setContentTitle("Пора принять: $medName$repeatBadge")
                        .setContentText(if (pkgId > 0L) "Пакет ($medDose)" else "Доза: $count шт ${if (medDose.isNotBlank()) "($medDose)" else ""}")
                        .setPriority(NotificationCompat.PRIORITY_HIGH)
                        .setOnlyAlertOnce(false)
                        .setAutoCancel(true)
                        .setContentIntent(openPi)
                        .addAction(0, "Принял", takePi)
                        .build()
                    nm.notify(notifId, notif)
                    AppLogger.log("ALM", "Напоминание #$attempt: $medName")

                    if (repeatMin > 0) {
                        val delayMs = repeatMin * 60_000L
                        if (attempt < 4) {
                            scheduleNextRepeat(context, ACTION_SHOW_REMINDER, medId, pkgId, pkgMedIds, medName, medDose, count, attempt + 1, delayMs)
                        } else {
                            scheduleNextRepeat(context, ACTION_MISSED_MED, medId, pkgId, pkgMedIds, medName, medDose, count, 4, delayMs)
                        }
                    }

                    if (soundKey != "mute" && soundKey != "system" && tryAcquireSoundSlot(context)) {
                        repeat(attempt) { idx ->
                            if (idx > 0) delay(gapMs.toLong().coerceAtLeast(50L))
                            val dur = playSingleBlocking(context, soundKey, volumePct)
                            if (idx < attempt - 1 && dur > 0L) delay(dur)
                        }
                    }
                } finally {
                    pendingResult.finish()
                }
            }
        } else if (intent.action == ACTION_MISSED_MED) {
            val pendingResult = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val dao = MedDatabase.get(context).dao()
                    if (isAlreadyTakenToday(dao, medId, pkgId)) {
                        nm.cancel(notifId)
                        cancelRepeat(context, keyId)
                        return@launch
                    }
                    val openPi = PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
                    val notif = NotificationCompat.Builder(context, channelId)
                        .setSmallIcon(R.drawable.ic_stat_medassist)
                        .setColor(0xFFD32F2F.toInt())
                        .setContentTitle("Препараты не приняты: $medName")
                        .setContentText("Пропущен плановый приём после 4 напоминаний")
                        .setPriority(NotificationCompat.PRIORITY_HIGH)
                        .setAutoCancel(true)
                        .setContentIntent(openPi)
                        .build()
                    nm.notify(notifId, notif)
                    if (tryAcquireSoundSlot(context)) {
                        playSingleBlocking(context, soundKey, volumePct)
                    }
                    dao.insertVital(VitalEntry(dateKey = LocalDate.now().toString(), type = VitalType.NOTE, value1 = 0.0, note = "Препараты не приняты: $medName", source = DataSource.MANUAL))
                    AppLogger.log("MED", "Препараты не приняты: $medName")
                } finally {
                    pendingResult.finish()
                }
            }
        }
    }
}
