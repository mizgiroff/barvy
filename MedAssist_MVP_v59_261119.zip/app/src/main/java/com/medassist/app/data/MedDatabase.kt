package com.medassist.app.data

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Dao
interface MedDao {
    @Query("SELECT * FROM vital_entries WHERE dateKey = :dateKey ORDER BY timestamp DESC")
    fun observeVitalsForDay(dateKey: String): Flow<List<VitalEntry>>

    @Query("SELECT * FROM vital_entries WHERE type IN (:types) ORDER BY timestamp DESC LIMIT 30")
    fun observeVitalsByTypes(types: List<VitalType>): Flow<List<VitalEntry>>

    @Query("SELECT * FROM vital_entries ORDER BY timestamp DESC")
    suspend fun getAllVitals(): List<VitalEntry>

    @Query("SELECT * FROM vital_entries WHERE dateKey = :dateKey AND type = :type ORDER BY timestamp DESC LIMIT 1")
    suspend fun getLatestVitalForDay(dateKey: String, type: VitalType): VitalEntry?

    @Query("SELECT COUNT(*) FROM vital_entries WHERE type = :type AND timestamp BETWEEN :fromMs AND :toMs AND ABS(value1 - :v1) < 0.05 AND (:v2 IS NULL OR ABS(COALESCE(value2, 0.0) - :v2) < 0.05)")
    suspend fun countSimilarVitalsInWindow(type: VitalType, fromMs: Long, toMs: Long, v1: Double, v2: Double?): Int

    @Query("SELECT COUNT(*) FROM vital_entries WHERE type = :type AND timestamp BETWEEN :fromMs AND :toMs AND ABS(value1 - :v1) < 0.5 AND ABS(COALESCE(value2, 0.0) - :v2) < 0.5 AND ((:pulse IS NULL AND pulse IS NULL) OR pulse = :pulse)")
    suspend fun countMatchingBpInWindow(type: VitalType, fromMs: Long, toMs: Long, v1: Double, v2: Double, pulse: Int?): Int

    @Query("SELECT * FROM daily_context WHERE dateKey = :dateKey LIMIT 1")
    fun observeDailyContext(dateKey: String): Flow<DailyContext?>

    @Query("SELECT * FROM daily_context WHERE dateKey = :dateKey LIMIT 1")
    suspend fun getDailyContext(dateKey: String): DailyContext?

    @Query("SELECT * FROM daily_context ORDER BY dateKey DESC")
    suspend fun getAllDailyContexts(): List<DailyContext>

    @Query("SELECT * FROM daily_context ORDER BY dateKey DESC LIMIT 30")
    fun observeAllDailyContexts(): Flow<List<DailyContext>>

    @Query("SELECT * FROM weather_logs ORDER BY timestamp DESC LIMIT 50")
    fun observeWeatherLogs(): Flow<List<WeatherLog>>

    @Query("SELECT * FROM weather_logs ORDER BY timestamp DESC LIMIT 1")
    suspend fun getLatestWeatherLog(): WeatherLog?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWeatherLog(log: WeatherLog): Long

    @Query("SELECT * FROM food_plates ORDER BY id ASC")
    fun observeFoodPlates(): Flow<List<FoodPlate>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertFoodPlate(plate: FoodPlate): Long

    @Delete
    suspend fun deleteFoodPlate(plate: FoodPlate)

    @Query("SELECT * FROM food_dishes ORDER BY isFavorite DESC, id DESC")
    fun observeFoodDishes(): Flow<List<FoodDish>>

    @Query("SELECT * FROM food_dishes WHERE LOWER(name) = LOWER(:name) LIMIT 1")
    suspend fun getFoodDishByName(name: String): FoodDish?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertFoodDish(dish: FoodDish): Long

    @Delete
    suspend fun deleteFoodDish(dish: FoodDish)

    @Query("SELECT * FROM medications ORDER BY scheduleTime ASC")
    fun observeMedications(): Flow<List<MedicationItem>>

    @Query("SELECT * FROM medications ORDER BY scheduleTime ASC")
    suspend fun getAllMedications(): List<MedicationItem>

    @Query("SELECT * FROM medications WHERE id = :id LIMIT 1")
    suspend fun getMedicationById(id: Long): MedicationItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMedication(item: MedicationItem): Long

    @Delete
    suspend fun deleteMedication(item: MedicationItem)

    @Query("SELECT * FROM med_packages ORDER BY scheduleTime ASC")
    fun observePackages(): Flow<List<MedPackage>>

    @Query("SELECT * FROM med_packages ORDER BY scheduleTime ASC")
    suspend fun getAllPackages(): List<MedPackage>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPackage(pkg: MedPackage): Long

    @Delete
    suspend fun deletePackage(pkg: MedPackage)

    @Query("SELECT * FROM medication_events WHERE dateKey = :dateKey ORDER BY takenAt DESC")
    fun observeMedsForDay(dateKey: String): Flow<List<MedicationEvent>>

    @Query("SELECT * FROM medication_events ORDER BY takenAt DESC")
    suspend fun getAllMeds(): List<MedicationEvent>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVital(entry: VitalEntry): Long

    @Update
    suspend fun updateVital(entry: VitalEntry)

    @Delete
    suspend fun deleteVital(entry: VitalEntry)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDailyContext(ctx: DailyContext)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMedicationEvent(event: MedicationEvent)

    @Update
    suspend fun updateMedicationEvent(event: MedicationEvent)

    @Delete
    suspend fun deleteMedicationEvent(event: MedicationEvent)
}

@Database(
    entities = [VitalEntry::class, DailyContext::class, WeatherLog::class, FoodPlate::class, FoodDish::class, MedicationItem::class, MedPackage::class, MedicationEvent::class],
    version = 9,
    exportSchema = false
)
abstract class MedDatabase : RoomDatabase() {
    abstract fun dao(): MedDao

    companion object {
        @Volatile private var INSTANCE: MedDatabase? = null

        private val MIGRATION_8_9 = object : Migration(8, 9) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE medication_events ADD COLUMN note TEXT NOT NULL DEFAULT ''")
            }
        }

        private val MIGRATION_7_8 = object : Migration(7, 8) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE food_dishes ADD COLUMN isFavorite INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE daily_context ADD COLUMN updatedAt INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE daily_context ADD COLUMN updatedSource TEXT NOT NULL DEFAULT 'HC'")
            }
        }

        private val MIGRATION_6_7 = object : Migration(6, 7) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS food_dishes (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name TEXT NOT NULL, xe REAL NOT NULL, defaultGrams INTEGER NOT NULL)")
            }
        }

        private val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE vital_entries ADD COLUMN weatherSummary TEXT NOT NULL DEFAULT ''")
                db.execSQL("CREATE TABLE IF NOT EXISTS weather_logs (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, timestamp INTEGER NOT NULL, dateKey TEXT NOT NULL, tempC INTEGER NOT NULL, feelsLikeC INTEGER NOT NULL, pressureMmHg INTEGER NOT NULL, humidity INTEGER NOT NULL, windKmh INTEGER NOT NULL, condition TEXT NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS food_plates (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name TEXT NOT NULL, tareGrams INTEGER NOT NULL, photoUri TEXT NOT NULL)")
            }
        }

        fun get(context: Context): MedDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    MedDatabase::class.java,
                    "medassist.db"
                )
                    .addMigrations(MIGRATION_5_6, MIGRATION_6_7, MIGRATION_7_8, MIGRATION_8_9)
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
    }
}
