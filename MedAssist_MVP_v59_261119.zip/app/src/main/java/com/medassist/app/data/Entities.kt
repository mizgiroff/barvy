package com.medassist.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class VitalType {
    GLUCOSE, BP, INSULIN, WATER, WEIGHT, FOOD, NOTE, CUSTOM
}

enum class DataSource {
    BLE_CONTOUR, BLE_SCALE, BLE_BP, HEALTH_CONNECT, MANUAL, HA
}

@Entity(tableName = "vital_entries")
data class VitalEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val dateKey: String,
    val type: VitalType,
    val value1: Double,
    val value2: Double? = null,
    val pulse: Int? = null,
    val note: String = "",
    val source: DataSource = DataSource.MANUAL,
    val syncedToHa: Boolean = false,
    val weatherSummary: String = ""
)

@Entity(tableName = "daily_context")
data class DailyContext(
    @PrimaryKey val dateKey: String,
    val steps: Long = 0,
    val sleepMinutes: Long = 0,
    val weatherPressureMmHg: Int? = null,
    val weatherTempC: Int? = null,
    val weatherCondition: String = "",
    val notes: String = "",
    val updatedAt: Long = 0L,
    val updatedSource: String = "HC"
)

@Entity(tableName = "weather_logs")
data class WeatherLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val dateKey: String,
    val tempC: Int,
    val feelsLikeC: Int = tempC,
    val pressureMmHg: Int,
    val humidity: Int = 0,
    val windKmh: Int = 0,
    val condition: String = ""
)

@Entity(tableName = "food_dishes")
data class FoodDish(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val xe: Double,
    val defaultGrams: Int = 0,
    val isFavorite: Boolean = false
)

@Entity(tableName = "food_plates")
data class FoodPlate(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val tareGrams: Int,
    val photoUri: String = ""
)

@Entity(tableName = "medications")
data class MedicationItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val dosage: String = "",
    val effect: String = "",
    val countPerIntake: Double = 1.0,
    val scheduleTime: String = "08:30",
    val stockLeft: Double = 30.0,
    val lowThreshold: Double = 5.0,
    val reminderEnabled: Boolean = true
)

@Entity(tableName = "med_packages")
data class MedPackage(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val medIdsCsv: String,
    val scheduleTime: String = "08:30"
)

@Entity(tableName = "medication_events")
data class MedicationEvent(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val medId: Long = 0,
    val dateKey: String,
    val slot: String,
    val medName: String,
    val dose: String,
    val takenAt: Long = System.currentTimeMillis(),
    val blockedReason: String? = null,
    val note: String = ""
)

data class UserNorms(
    val sysMin: Int = 105,
    val sysMax: Int = 139,
    val diaMin: Int = 65,
    val diaMax: Int = 89,
    val glucoseMin: Double = 3.9,
    val glucoseMax: Double = 7.8,
    val pulseMin: Int = 55,
    val pulseMax: Int = 100
)

data class UserProfile(
    val name: String = "",
    val age: Int = 59,
    val heightCm: Int = 178,
    val targetWeightKg: Double = 85.0,
    val city: String = "Львов"
)

data class CustomTileDef(
    val id: String,
    val topLabel: String,
    val topUnit: String = "",
    val bottomLabel: String = "",
    val bottomUnit: String = "",
    val topMin: Double? = null,
    val topMax: Double? = null
)
