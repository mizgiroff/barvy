package com.medassist.app

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import androidx.core.location.LocationManagerCompat
import androidx.health.connect.client.PermissionController
import androidx.lifecycle.lifecycleScope
import com.medassist.app.ble.BleDeviceRole
import com.medassist.app.ble.BpDedupCache
import com.medassist.app.ble.ContourBleManager
import com.medassist.app.data.*
import com.medassist.app.health.HealthConnectReader
import com.medassist.app.service.MedMonitorService
import com.medassist.app.service.MedReminderReceiver
import com.medassist.app.sync.FoodAnalysis
import com.medassist.app.sync.PlateAnalysis
import com.medassist.app.sync.GeminiHelper
import com.medassist.app.sync.HomeAssistantClient
import com.medassist.app.ui.LocalLargeUi
import com.medassist.app.ui.MainScreen
import com.medassist.app.ui.PinnedBleDevice
import com.medassist.app.ui.ScannedBleDevice
import com.medassist.app.ui.SplashScreen
import com.medassist.app.util.AppLang
import com.medassist.app.util.AppLogger
import com.medassist.app.weather.WeatherClient
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.Instant
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.ZoneId

class MainActivity : ComponentActivity() {
    private val scannedMap = mutableMapOf<String, BluetoothDevice>()
    private var bleDevicesState by mutableStateOf<List<ScannedBleDevice>>(emptyList())
    private var isScanningBle by mutableStateOf(false)
    private var activeScanCallback: ScanCallback? = null
    private var contourManager: ContourBleManager? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = getSharedPreferences("medassist_prefs", Context.MODE_PRIVATE)
        val db = MedDatabase.get(this).dao()
        val hcReader = HealthConnectReader(this)
        val haClient = HomeAssistantClient()
        val geminiHelper = GeminiHelper()
        val weatherClient = WeatherClient()
        val today = LocalDate.now().toString()

        suspend fun currentWeatherSummary(): String {
            val wx = db.getDailyContext(today)
            return if (wx?.weatherTempC != null) {
                "${wx.weatherPressureMmHg ?: "-"}мм ${wx.weatherTempC}°C ${wx.weatherCondition}".trim()
            } else ""
        }

        suspend fun refreshWeather() {
            weatherClient.fetchLvivWeather()?.let { wx ->
                val existing = db.getDailyContext(today)
                db.upsertDailyContext(
                    (existing ?: DailyContext(dateKey = today)).copy(
                        weatherTempC = wx.tempC, weatherPressureMmHg = wx.pressureMmHg, weatherCondition = wx.condition
                    )
                )
                val lastLog = db.getLatestWeatherLog()
                val now = System.currentTimeMillis()
                if (lastLog == null || (now - lastLog.timestamp) > 30 * 60_000L || lastLog.pressureMmHg != wx.pressureMmHg || lastLog.tempC != wx.tempC || lastLog.condition != wx.condition) {
                    db.insertWeatherLog(
                        WeatherLog(
                            timestamp = now,
                                dateKey = today,
                            tempC = wx.tempC,
                            feelsLikeC = wx.feelsLikeC,
                            pressureMmHg = wx.pressureMmHg,
                            humidity = wx.humidity,
                            windKmh = wx.windKmh,
                            condition = wx.condition
                        )
                    )
                }
            }
        }

        contourManager = ContourBleManager(
            context = this,
            onGlucoseRead = { mmol, tsMs ->
                lifecycleScope.launch {
                    val dup = db.countSimilarVitalsInWindow(VitalType.GLUCOSE, tsMs - 60_000L, tsMs + 60_000L, mmol, null)
                    if (dup == 0) {
                        val dk = Instant.ofEpochMilli(tsMs).atZone(ZoneId.systemDefault()).toLocalDate().toString()
                        db.insertVital(VitalEntry(timestamp = tsMs, dateKey = dk, type = VitalType.GLUCOSE, value1 = mmol, source = DataSource.BLE_CONTOUR))
                        if (dk == today) {
                            MedReminderReceiver.notifyBleData(this@MainActivity, "Данные приняты (Глюкометр)", "Сахар: $mmol ммоль/л")
                        }
                    }
                }
            },
            onBpRead = { sys, dia, pulse, tsMs ->
                lifecycleScope.launch {
                    val dk = Instant.ofEpochMilli(tsMs).atZone(ZoneId.systemDefault()).toLocalDate().toString()
                    val existing = db.countSimilarVitalsInWindow(VitalType.BP, tsMs - 60_000L, tsMs + 60_000L, sys, dia)
                    val matching12h = db.countMatchingBpInWindow(VitalType.BP, tsMs - 12 * 60 * 60_000L, tsMs + 60_000L, sys, dia, pulse)
                    val seenToday = BpDedupCache.isSeen(this@MainActivity, dk, sys, dia, pulse)
                    if (existing == 0 && matching12h == 0 && !seenToday) {
                        db.insertVital(VitalEntry(timestamp = tsMs, dateKey = dk, type = VitalType.BP, value1 = sys, value2 = dia, pulse = pulse, source = DataSource.BLE_BP, weatherSummary = currentWeatherSummary()))
                        BpDedupCache.markSeen(this@MainActivity, dk, sys, dia, pulse)
                        MedReminderReceiver.notifyBleData(this@MainActivity, "Данные приняты (Тонометр)", "Давление: ${sys.toInt()}/${dia.toInt()} · пульс ${pulse ?: "-"}")
                    } else {
                        AppLogger.log("BLE", "Пропущен дубль АД (12ч/кэш): ${sys.toInt()}/${dia.toInt()}-${pulse ?: 0}")
                    }
                }
            },
            onWeightRead = { kg ->
                lifecycleScope.launch {
                    val prev = db.getLatestVitalForDay(today, VitalType.WEIGHT)
                    if (prev == null || prev.value1 != kg) {
                        db.insertVital(VitalEntry(dateKey = today, type = VitalType.WEIGHT, value1 = kg, source = DataSource.BLE_SCALE))
                    MedReminderReceiver.notifyBleData(this@MainActivity, "Данные приняты (Весы)", "Вес: $kg кг")
                    }
                }
            }
        )

        try {
            ContextCompat.startForegroundService(this, Intent(this, MedMonitorService::class.java))
        } catch (e: Exception) {
            AppLogger.log("SVC", "Сервис не запущен: ${e.message}")
        }


        suspend fun runHealthSync() {
            val snap = hcReader.readTodaySnapshot()
            val existingCtx = db.getDailyContext(today)
            db.upsertDailyContext(
                (existingCtx ?: DailyContext(dateKey = today)).copy(steps = snap.steps, sleepMinutes = snap.sleepMinutes, updatedAt = System.currentTimeMillis(), updatedSource = "HC")
            )
            snap.weightKg?.let { w ->
                val prevW = db.getLatestVitalForDay(today, VitalType.WEIGHT)
                if (prevW == null || prevW.value1 != w) {
                    db.insertVital(VitalEntry(timestamp = snap.weightTimeMillis ?: System.currentTimeMillis(), dateKey = today, type = VitalType.WEIGHT, value1 = w, source = DataSource.HEALTH_CONNECT))
                }
            }
            if (snap.bpSys != null && snap.bpDia != null) {
                val bpTs = snap.bpTimeMillis ?: System.currentTimeMillis()
                val dup = db.countSimilarVitalsInWindow(VitalType.BP, bpTs - 60_000L, bpTs + 60_000L, snap.bpSys, snap.bpDia)
                if (dup == 0) {
                    db.insertVital(VitalEntry(timestamp = bpTs, dateKey = today, type = VitalType.BP, value1 = snap.bpSys, value2 = snap.bpDia, pulse = snap.bpPulse, source = DataSource.HEALTH_CONNECT, weatherSummary = currentWeatherSummary()))
                }
            }
        }

        val requestHcPermissions = registerForActivityResult(PermissionController.createRequestPermissionResultContract()) { granted ->
            AppLogger.log("HC", "Выдано разрешений: ${granted.size}")
            lifecycleScope.launch { runHealthSync() }
        }

        val requestBlePermissions = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { perms ->
            if (perms.values.all { it }) startBleScan()
            else AppLogger.log("BLE", "Не выданы разрешения Bluetooth")
        }

        val exportLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
            if (uri != null) {
                lifecycleScope.launch {
                    val json = BackupHelper.exportToJson(db)
                    contentResolver.openOutputStream(uri)?.use { it.write(json.toByteArray()) }
                    Toast.makeText(this@MainActivity, "Бэкап сохранён", Toast.LENGTH_SHORT).show()
                }
            }
        }

        val importLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                lifecycleScope.launch {
                    val text = contentResolver.openInputStream(uri)?.bufferedReader()?.readText() ?: return@launch
                    val count = BackupHelper.importFromJson(db, text)
                    Toast.makeText(this@MainActivity, "Восстановлено: $count", Toast.LENGTH_SHORT).show()
                }
            }
        }

        fun loadCustomTiles(): List<CustomTileDef> {
            val raw = prefs.getString("custom_tiles_json", "[]") ?: "[]"
            val list = mutableListOf<CustomTileDef>()
            try {
                val arr = JSONArray(raw)
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list.add(
                        CustomTileDef(
                            id = o.getString("id"),
                            topLabel = o.getString("topLabel"),
                            topUnit = o.optString("topUnit", ""),
                            bottomLabel = o.optString("bottomLabel", ""),
                            bottomUnit = o.optString("bottomUnit", ""),
                            topMin = if (o.has("topMin") && !o.isNull("topMin")) o.optDouble("topMin") else null,
                            topMax = if (o.has("topMax") && !o.isNull("topMax")) o.optDouble("topMax") else null
                        )
                    )
                }
            } catch (_: Exception) {}
            return list
        }

        fun saveCustomTiles(list: List<CustomTileDef>) {
            val arr = JSONArray()
            list.forEach { t ->
                arr.put(JSONObject().apply {
                    put("id", t.id)
                    put("topLabel", t.topLabel)
                    put("topUnit", t.topUnit)
                    put("bottomLabel", t.bottomLabel)
                    put("bottomUnit", t.bottomUnit)
                    if (t.topMin != null) put("topMin", t.topMin)
                    if (t.topMax != null) put("topMax", t.topMax)
                })
            }
            prefs.edit().putString("custom_tiles_json", arr.toString()).apply()
        }

        fun loadPinned(): Map<BleDeviceRole, PinnedBleDevice> {
            val map = mutableMapOf<BleDeviceRole, PinnedBleDevice>()
            BleDeviceRole.values().forEach { r ->
                val addr = prefs.getString("pin_${r.name}_addr", null)
                val nm = prefs.getString("pin_${r.name}_name", null)
                if (!addr.isNullOrBlank()) map[r] = PinnedBleDevice(r, nm ?: r.label, addr)
            }
            return map
        }

        AppLogger.log("APP", "MedAssist v59.261119 запущен")

        setContent {
            var uiThemeMode by remember { mutableStateOf(prefs.getInt("ui_theme_mode", 0)) }
            var uiLargeMode by remember { mutableStateOf(prefs.getBoolean("ui_large_mode", false)) }
            var uiNotifSound by remember { mutableStateOf(prefs.getString("notif_sound", "chime") ?: "chime") }
            var uiNotifRepeatMin by remember { mutableStateOf(prefs.getInt("notif_repeat_min", 0)) }
            var uiNotifVolume by remember { mutableStateOf(prefs.getInt("notif_volume", 80)) }
            var uiDailyCheckEnabled by remember { mutableStateOf(prefs.getBoolean("daily_check_enabled", true)) }
            var uiDailyCheckTime by remember { mutableStateOf(prefs.getString("daily_check_time", "21:00") ?: "21:00") }
            var uiBleSound by remember { mutableStateOf(prefs.getString("ble_notif_sound", "ping") ?: "ping") }
            var uiBleVolume by remember { mutableStateOf(prefs.getInt("ble_notif_volume", 80)) }
            var uiNotifGapMs by remember { mutableStateOf(prefs.getInt("notif_gap_ms", 250)) }
            var uiAiAdviceEnabled by remember { mutableStateOf(prefs.getBoolean("ai_advice_enabled", true)) }
            val isDark = when (uiThemeMode) {
                1 -> false
                2 -> true
                else -> isSystemInDarkTheme()
            }
            val baseDensity = LocalDensity.current
            val appDensity = remember(baseDensity, uiLargeMode) {
                Density(baseDensity.density, fontScale = if (uiLargeMode) baseDensity.fontScale * 1.28f else baseDensity.fontScale)
            }
            CompositionLocalProvider(LocalDensity provides appDensity, LocalLargeUi provides uiLargeMode) {
            MaterialTheme(colorScheme = if (isDark) darkColorScheme() else lightColorScheme()) {
                var showSplash by remember { mutableStateOf(true) }
                var splashProgress by remember { mutableStateOf(0.1f) }
                var splashStatus by remember { mutableStateOf("Инициализация базы...") }

                LaunchedEffect(Unit) {
                    val t0 = System.currentTimeMillis()
                    splashProgress = 0.35f
                    splashStatus = "Погода и Health Connect..."
                    refreshWeather()
                    if (hcReader.hasAllPermissions()) runHealthSync()
                    if (!prefs.getBoolean("seeded_v10_user_meds", false) && db.getAllMedications().isEmpty()) {
                        val idTriplixam = db.upsertMedication(MedicationItem(name = "Трипликсам", dosage = "5/1,25/5 мг", effect = "Комбинированный антигипертензивный препарат (периндоприл + индапамид + амлодипин), принимать при АД > 125", countPerIntake = 1.0, scheduleTime = "18:00", stockLeft = 30.0))
                        val idConcor = db.upsertMedication(MedicationItem(name = "Конкор кор", dosage = "2,5 мг", effect = "Бета-блокатор (бисопролол) для контроля пульса и сердцебиения", countPerIntake = 1.0, scheduleTime = "08:30", stockLeft = 30.0))
                        db.upsertMedication(MedicationItem(name = "Диакобал", dosage = "—", effect = "Нейротропный препарат / витамин B12 (мекобаламин)", countPerIntake = 1.0, scheduleTime = "По необходимости", stockLeft = 30.0, reminderEnabled = false))
                        val idEliquis = db.upsertMedication(MedicationItem(name = "Эликвис", dosage = "2,5 мг", effect = "Антикоагулянт (апиксабан) для разжижения крови и профилактики тромбозов, 2 раза в день", countPerIntake = 1.0, scheduleTime = "08:30", stockLeft = 60.0))
                        val idPreductal = db.upsertMedication(MedicationItem(name = "Предуктал", dosage = "МВ 80 мг", effect = "Кардиопротектор (триметазидин) для улучшения метаболизма миокарда, 2 раза в день", countPerIntake = 1.0, scheduleTime = "08:30", stockLeft = 60.0))
                        val idJardiance = db.upsertMedication(MedicationItem(name = "Джардинс", dosage = "10 мг", effect = "Ингибитор SGLT2 (эмпаглифлозин) для защиты почек, сердца и контроля глюкози", countPerIntake = 1.0, scheduleTime = "08:30", stockLeft = 30.0))
                        val idAlfirum = db.upsertMedication(MedicationItem(name = "Алфирум", dosage = "10 мг", effect = "Урологический препарат (альфузозин) для нормализации мочеиспускания, вечером", countPerIntake = 1.0, scheduleTime = "20:30", stockLeft = 30.0))
                        db.upsertMedication(MedicationItem(name = "Каптоприл", dosage = "25 мг", effect = "Ингибитор АПФ: скорая помощь при скачке давления / гипертоническом кризе", countPerIntake = 1.0, scheduleTime = "20:00", stockLeft = 20.0))
                        db.upsertMedication(MedicationItem(name = "Тожео СолоСтар", dosage = "38 ЕД", effect = "Базальный инсулин длительного действия (гларгин 300 ЕД/мл) для контроля глюкозы", countPerIntake = 1.0, scheduleTime = "17:00", stockLeft = 1.0, lowThreshold = 1.0))
                        db.upsertPackage(MedPackage(name = "Утренние таблетки", medIdsCsv = listOf(idConcor, idEliquis, idPreductal, idJardiance).joinToString(","), scheduleTime = "08:30"))
                        db.upsertPackage(MedPackage(name = "Вечерние таблетки", medIdsCsv = listOf(idEliquis, idPreductal, idAlfirum).joinToString(","), scheduleTime = "20:30"))
                        prefs.edit().putBoolean("seeded_v10_user_meds", true).apply()
                    }
                    val allPkgs = db.getAllPackages()
                    db.getAllMedications().filter { it.reminderEnabled }.forEach { m ->
                        val coveredByPkg = allPkgs.any { p -> p.scheduleTime == m.scheduleTime && m.id in p.medIdsCsv.split(",").mapNotNull { it.toLongOrNull() } }
                        if (coveredByPkg) {
                            MedReminderReceiver.scheduleForMed(this@MainActivity, m.id, m.name, m.dosage, m.countPerIntake, "По необходимости")
                        } else {
                            MedReminderReceiver.scheduleForMed(this@MainActivity, m.id, m.name, m.dosage, m.countPerIntake, m.scheduleTime)
                        }
                    }
                    db.observePackages().let { _ -> }
                    MedReminderReceiver.scheduleDailyCheck(this@MainActivity, prefs.getBoolean("daily_check_enabled", true), prefs.getString("daily_check_time", "21:00") ?: "21:00")
                    splashProgress = 0.8f
                    splashStatus = "Подготовка экрана..."
                    val elapsed = System.currentTimeMillis() - t0
                    if (elapsed < 2000L) delay(2000L - elapsed)
                    splashProgress = 1.0f
                    showSplash = false
                }

                if (showSplash) {
                    SplashScreen(splashProgress, splashStatus)
                } else {
                    var selectedDateKey by remember { mutableStateOf(today) }
                    val vitals by db.observeVitalsForDay(selectedDateKey).collectAsState(initial = emptyList())
                    val allHistory by db.observeVitalsByTypes(
                        listOf(VitalType.GLUCOSE, VitalType.INSULIN, VitalType.BP, VitalType.WEIGHT, VitalType.WATER, VitalType.FOOD)
                    ).collectAsState(initial = emptyList())
                    val ctx by db.observeDailyContext(selectedDateKey).collectAsState(initial = null)
                    val allDailyContexts by db.observeAllDailyContexts().collectAsState(initial = emptyList())
                    val weatherLogs by db.observeWeatherLogs().collectAsState(initial = emptyList())
                    val foodPlates by db.observeFoodPlates().collectAsState(initial = emptyList())
                    val foodDishes by db.observeFoodDishes().collectAsState(initial = emptyList())
                    val medsList by db.observeMedications().collectAsState(initial = emptyList())
                    val packagesList by db.observePackages().collectAsState(initial = emptyList())
                    LaunchedEffect(packagesList) {
                        packagesList.forEach { p ->
                            MedReminderReceiver.scheduleForPackage(this@MainActivity, p.id, p.name, p.medIdsCsv, p.scheduleTime)
                        }
                    }
                    val medEvents by db.observeMedsForDay(selectedDateKey).collectAsState(initial = emptyList())

                    var savedUrl by remember { mutableStateOf(prefs.getString("ha_url", "http://192.168.1.100:8123") ?: "") }
                    var savedToken by remember { mutableStateOf(prefs.getString("ha_token", "") ?: "") }
                    var savedGeminiKey by remember { mutableStateOf(prefs.getString("gemini_key", "") ?: "") }
                    var lastInsDose by remember { mutableStateOf(prefs.getFloat("last_ins", 38f).toDouble()) }
                    var pinnedDevices by remember { mutableStateOf(loadPinned()) }
                    var appLang by remember {
                        val code = prefs.getString("lang", "ru") ?: "ru"
                        mutableStateOf(AppLang.values().firstOrNull { it.code == code } ?: AppLang.RU)
                    }
                    var userProfile by remember {
                        mutableStateOf(
                            UserProfile(
                                name = prefs.getString("p_name", "") ?: "",
                                age = prefs.getInt("p_age", 59),
                                heightCm = prefs.getInt("p_height", 178),
                                targetWeightKg = prefs.getFloat("p_weight", 85f).toDouble(),
                                city = prefs.getString("p_city", "Львов") ?: "Львов"
                            )
                        )
                    }
                    var userNorms by remember {
                        mutableStateOf(
                            UserNorms(
                                sysMin = prefs.getInt("n_sys_min", 105),
                                sysMax = prefs.getInt("n_sys_max", 139),
                                glucoseMin = prefs.getFloat("n_glu_min", 3.9f).toDouble(),
                                glucoseMax = prefs.getFloat("n_glu_max", 7.8f).toDouble()
                            )
                        )
                    }
                    var tileOrder by remember {
                        val raw = prefs.getString("tile_order", "0,1,2,3,4,5") ?: "0,1,2,3,4,5"
                        val parsed = raw.split(",").mapNotNull { it.toIntOrNull() }.toMutableList()
                        listOf(0, 1, 2, 3, 4, 5).forEach { id -> if (id !in parsed) parsed.add(id) }
                        mutableStateOf(parsed.toList())
                    }
                    var customTiles by remember { mutableStateOf(loadCustomTiles()) }

                    MainScreen(
                        dateKey = selectedDateKey,
                        canGoNextDay = selectedDateKey < today,
                        onPrevDay = { selectedDateKey = LocalDate.parse(selectedDateKey).minusDays(1).toString() },
                        onNextDay = {
                            val nxt = LocalDate.parse(selectedDateKey).plusDays(1)
                            if (!nxt.isAfter(LocalDate.parse(today))) selectedDateKey = nxt.toString()
                        },
                        vitals = vitals,
                        allHistoryVitals = allHistory,
                        dailyContext = ctx,
                        allDailyContexts = allDailyContexts,
                        weatherLogs = weatherLogs,
                        weatherForecast = weatherClient.latestForecast,
                        foodPlates = foodPlates,
                        foodDishes = foodDishes,
                        medicationsList = medsList,
                        packagesList = packagesList,
                        medEvents = medEvents,
                        initialHaUrl = savedUrl,
                        initialHaToken = savedToken,
                        initialGeminiKey = savedGeminiKey,
                        lastInsulinDose = lastInsDose,
                        userProfile = userProfile,
                        userNorms = userNorms,
                        appLang = appLang,
                        tileOrder = tileOrder,
                        customTiles = customTiles,
                        pinnedDevices = pinnedDevices,
                        bleDevices = bleDevicesState,
                        isScanningBle = isScanningBle,
                        initialThemeMode = uiThemeMode,
                        initialLargeUi = uiLargeMode,
                        initialNotifSound = uiNotifSound,
                        initialNotifRepeatMin = uiNotifRepeatMin,
                        initialNotifVolume = uiNotifVolume,
                        initialDailyCheckEnabled = uiDailyCheckEnabled,
                        initialDailyCheckTime = uiDailyCheckTime,
                        initialBleSound = uiBleSound,
                        initialBleVolume = uiBleVolume,
                        initialAiAdviceEnabled = uiAiAdviceEnabled,
                        initialNotifGapMs = uiNotifGapMs,
                        onSaveUiPrefs = { tm, lg, snd, repMin, vol, dcEn, dcTime, bSnd, bVol, aiAdv, gap ->
                            uiThemeMode = tm
                            uiLargeMode = lg
                            uiNotifSound = snd
                            uiNotifRepeatMin = repMin
                            uiNotifVolume = vol
                            uiDailyCheckEnabled = dcEn
                            uiDailyCheckTime = dcTime
                            uiBleSound = bSnd
                            uiBleVolume = bVol
                            uiAiAdviceEnabled = aiAdv
                            uiNotifGapMs = gap
                            prefs.edit()
                                .putInt("ui_theme_mode", tm)
                                .putBoolean("ui_large_mode", lg)
                                .putString("notif_sound", snd)
                                .putInt("notif_repeat_min", repMin)
                                .putInt("notif_volume", vol)
                                .putBoolean("daily_check_enabled", dcEn)
                                .putString("daily_check_time", dcTime)
                                .putString("ble_notif_sound", bSnd)
                                .putInt("ble_notif_volume", bVol)
                                .putBoolean("ai_advice_enabled", aiAdv)
                                .putInt("notif_gap_ms", gap)
                                .apply()
                            MedReminderReceiver.scheduleDailyCheck(this@MainActivity, dcEn, dcTime)
                        },
                        onSaveSettings = { u, t, gKey, prof, nrm, lng ->
                            savedUrl = u; savedToken = t; savedGeminiKey = gKey; userProfile = prof; userNorms = nrm; appLang = lng
                            prefs.edit()
                                .putString("ha_url", u).putString("ha_token", t).putString("gemini_key", gKey)
                                .putString("lang", lng.code)
                                .putString("p_name", prof.name).putInt("p_age", prof.age)
                                .putInt("p_height", prof.heightCm).putFloat("p_weight", prof.targetWeightKg.toFloat())
                                .putString("p_city", prof.city)
                                .putInt("n_sys_min", nrm.sysMin).putInt("n_sys_max", nrm.sysMax)
                                .putFloat("n_glu_min", nrm.glucoseMin.toFloat()).putFloat("n_glu_max", nrm.glucoseMax.toFloat())
                                .apply()
                        },
                        onSaveCustomTiles = { newList -> customTiles = newList; saveCustomTiles(newList) },
                        onSaveTileOrder = { newOrder ->
                            tileOrder = newOrder
                            prefs.edit().putString("tile_order", newOrder.joinToString(",")).apply()
                        },
                        onUpdateStepsSleep = { stepsVal, sleepMinVal ->
                            lifecycleScope.launch {
                                val existingCtx = db.getDailyContext(today) ?: DailyContext(dateKey = today)
                                db.upsertDailyContext(
                                    existingCtx.copy(
                                        steps = if (stepsVal >= 0L) stepsVal else existingCtx.steps,
                                        sleepMinutes = if (sleepMinVal >= 0L) sleepMinVal else existingCtx.sleepMinutes,
                                        updatedAt = System.currentTimeMillis(),
                                        updatedSource = "Ручн."
                                    )
                                )
                            }
                        },
                        onUpdateVital = { entry -> lifecycleScope.launch { db.updateVital(entry) } },
                        onDeleteVital = { entry -> lifecycleScope.launch { db.deleteVital(entry) } },
                        onUpdateMedEvent = { ev -> lifecycleScope.launch { db.updateMedicationEvent(ev) } },
                        onDeleteMedEvent = { ev -> lifecycleScope.launch { db.deleteMedicationEvent(ev) } },
                        onAddVital = { type, v1, v2, pulse, note ->
                            if (type == VitalType.INSULIN) {
                                lastInsDose = v1
                                prefs.edit().putFloat("last_ins", v1.toFloat()).apply()
                            }
                            lifecycleScope.launch {
                                val wxSum = if (type == VitalType.BP) currentWeatherSummary() else ""
                                db.insertVital(VitalEntry(dateKey = today, type = type, value1 = v1, value2 = v2, pulse = pulse, note = note, source = DataSource.MANUAL, weatherSummary = wxSum))
                                if (type == VitalType.INSULIN && v1 > 0.0) {
                                    val nm = getSystemService(android.content.Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
                                    db.getAllMedications().filter {
                                        it.name.contains("тожео", true) || it.name.contains("инсулин", true) || it.effect.contains("инсулин", true)
                                    }.forEach { insMed ->
                                        nm.cancel(1000 + insMed.id.toInt())
                                        MedReminderReceiver.cancelRepeat(this@MainActivity, insMed.id)
                                    }
                                }
                                if (type == VitalType.FOOD && note.isNotBlank()) {
                                    var cleanDish = note.trim()
                                    listOf("Завтрак:", "Обед:", "Ужин:", "Перекус:").forEach { pfx ->
                                        if (cleanDish.startsWith(pfx)) cleanDish = cleanDish.removePrefix(pfx).trim()
                                    }
                                    var parsedGrams = 0
                                    val gMatch = Regex("""\((\d+)\s*г\)\s*$""").find(cleanDish)
                                    if (gMatch != null) {
                                        parsedGrams = gMatch.groupValues[1].toIntOrNull() ?: 0
                                        cleanDish = cleanDish.removeRange(gMatch.range).trim()
                                    }
                                    if (cleanDish.isNotBlank()) {
                                        val existingDish = db.getFoodDishByName(cleanDish)
                                        if (existingDish == null) {
                                            db.upsertFoodDish(FoodDish(name = cleanDish, xe = v1, defaultGrams = parsedGrams))
                                        } else {
                                            db.upsertFoodDish(existingDish.copy(
                                                xe = v1,
                                                defaultGrams = if (parsedGrams > 0) parsedGrams else existingDish.defaultGrams
                                            ))
                                        }
                                    }
                                }
                            }
                        },
                        onTakeMedItem = { med, takenCount ->
                            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(1000 + med.id.toInt())
                            MedReminderReceiver.cancelRepeat(this@MainActivity, med.id)
                            lifecycleScope.launch {
                                db.upsertMedication(med.copy(stockLeft = (med.stockLeft - takenCount).coerceAtLeast(0.0)))
                                db.insertMedicationEvent(MedicationEvent(medId = med.id, dateKey = today, slot = "SINGLE_${med.id}", medName = med.name, dose = "${med.dosage} ($takenCount шт)".trim()))
                                MedReminderReceiver.recordInsulinVitalIfMedIsInsulin(this@MainActivity, db, med.name, med.dosage, med.effect, takenCount, today)
                            }
                        },
                        onTakePackage = { pkg ->
                            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                            lifecycleScope.launch {
                                val ids = pkg.medIdsCsv.split(",").mapNotNull { it.toLongOrNull() }
                                ids.forEach { mid ->
                                    nm.cancel(1000 + mid.toInt())
                                    MedReminderReceiver.cancelRepeat(this@MainActivity, mid)
                                    db.getMedicationById(mid)?.let { m ->
                                        db.upsertMedication(m.copy(stockLeft = (m.stockLeft - m.countPerIntake).coerceAtLeast(0.0)))
                                    }
                                }
                                MedReminderReceiver.cancelRepeat(this@MainActivity, 3000L + pkg.id)
                                db.insertMedicationEvent(MedicationEvent(medId = 0, dateKey = today, slot = "PKG_${pkg.id}", medName = pkg.name, dose = "${ids.size} преп."))
                            }
                        },
                        onSaveMedItem = { med ->
                            lifecycleScope.launch {
                                val newId = db.upsertMedication(med)
                                if (med.reminderEnabled) {
                                    MedReminderReceiver.scheduleForMed(this@MainActivity, newId, med.name, med.dosage, med.countPerIntake, med.scheduleTime)
                                }
                            }
                        },
                        onDeleteMedItem = { med ->
                            lifecycleScope.launch { db.deleteMedication(med) }
                        },
                        onSavePackage = { pkg ->
                            lifecycleScope.launch {
                                val newId = db.upsertPackage(pkg)
                                MedReminderReceiver.scheduleForPackage(this@MainActivity, newId, pkg.name, pkg.medIdsCsv, pkg.scheduleTime)
                            }
                        },
                        onDeletePackage = { pkg ->
                            lifecycleScope.launch { db.deletePackage(pkg) }
                        },
                        onAskGeminiMed = { query -> geminiHelper.lookupMedication(savedGeminiKey, query) },
                        onAskDailyAdvice = { summary -> geminiHelper.generateDailyAdvice(savedGeminiKey, summary) },
                        onAskAdviceChat = { dayCtx, hist, msg -> geminiHelper.askAdviceChat(savedGeminiKey, dayCtx, hist, msg) },
                        onAnalyzeFoodPhoto = { b64, plates, netG, hint -> geminiHelper.analyzeFoodPhoto(savedGeminiKey, b64, plates, netG, hint, foodDishes) },
                        onAnalyzeFoodText = { txt, netG, hint -> geminiHelper.analyzeFoodText(savedGeminiKey, txt, netG, hint, foodDishes) },
                        onIdentifyPlatePhoto = { b64 -> geminiHelper.identifyPlatePhoto(savedGeminiKey, b64) },
                        onRefreshWeather = { lifecycleScope.launch { refreshWeather() } },
                        onSaveFoodPlate = { plate -> lifecycleScope.launch { db.upsertFoodPlate(plate) } },
                        onDeleteFoodPlate = { plate -> lifecycleScope.launch { db.deleteFoodPlate(plate) } },
                        onSaveFoodDish = { dish -> lifecycleScope.launch { db.upsertFoodDish(dish) } },
                        onDeleteFoodDish = { dish -> lifecycleScope.launch { db.deleteFoodDish(dish) } },
                        onSyncHealthConnect = {
                            if (hcReader.isAvailable()) requestHcPermissions.launch(hcReader.requiredPermissions)
                            else AppLogger.log("HC", "Health Connect не установлен")
                        },
                        onSyncHa = {
                            lifecycleScope.launch {
                                vitals.firstOrNull { it.type == VitalType.GLUCOSE }?.let {
                                    haClient.pushSensor(savedUrl, savedToken, "sensor.medassist_glucose", it.value1.toString(), "mmol/L")
                                }
                                vitals.firstOrNull { it.type == VitalType.BP }?.let {
                                    haClient.pushSensor(savedUrl, savedToken, "sensor.medassist_bp_sys", it.value1.toInt().toString(), "mmHg")
                                }
                                vitals.firstOrNull { it.type == VitalType.WEIGHT }?.let {
                                    haClient.pushSensor(savedUrl, savedToken, "sensor.medassist_weight", it.value1.toString(), "kg")
                                }
                                ctx?.let {
                                    haClient.pushSensor(savedUrl, savedToken, "sensor.medassist_steps", it.steps.toString(), "steps")
                                }
                            }
                        },
                        onStartBleScan = {
                            val perms = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.ACCESS_FINE_LOCATION)
                            } else {
                                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
                            }
                            requestBlePermissions.launch(perms)
                        },
                        onPinAndConnectDevice = { role, name, addr ->
                            prefs.edit().putString("pin_${role.name}_addr", addr).putString("pin_${role.name}_name", name).apply()
                            pinnedDevices = loadPinned()
                            Toast.makeText(this@MainActivity, "Зафиксирован ${role.label}", Toast.LENGTH_SHORT).show()
                            try {
                                ContextCompat.startForegroundService(this@MainActivity, Intent(this@MainActivity, MedMonitorService::class.java).setAction(MedMonitorService.ACTION_REFRESH))
                            } catch (_: Exception) {}
                            val btMgr = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
                            val dev = scannedMap[addr] ?: btMgr.adapter?.getRemoteDevice(addr)
                            if (dev != null) contourManager?.connectMeter(dev, role)
                        },
                        onReadPinnedDevice = { role ->
                            val addr = pinnedDevices[role]?.address ?: return@MainScreen
                            Toast.makeText(this@MainActivity, "Считываю ${role.label}...", Toast.LENGTH_SHORT).show()
                            val btMgr = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
                            val dev = scannedMap[addr] ?: btMgr.adapter?.getRemoteDevice(addr)
                            if (dev != null) contourManager?.connectMeter(dev, role)
                        },
                        onUnpinDevice = { role ->
                            prefs.edit().remove("pin_${role.name}_addr").remove("pin_${role.name}_name").apply()
                            pinnedDevices = loadPinned()
                        },
                        onExportBackup = { exportLauncher.launch("MedAssist_backup_${today}.json") },
                        onImportBackup = { importLauncher.launch(arrayOf("application/json", "*/*")) },
                        onForceExit = {
                            try {
                                stopService(Intent(this@MainActivity, MedMonitorService::class.java))
                                (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(MedMonitorService.NOTIF_ID)
                            } catch (_: Exception) {}
                            finishAffinity()
                        }
                    )
                }
            }
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun startBleScan() {
        val locMgr = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        if (!LocationManagerCompat.isLocationEnabled(locMgr)) {
            AppLogger.log("BLE", "ВНИМАНИЕ: Включите Геолокацию (GPS) для поиска BLE")
        }
        val btManager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val adapter: BluetoothAdapter? = btManager.adapter
        val scanner = adapter?.bluetoothLeScanner
        if (scanner == null) {
            AppLogger.log("BLE", "Bluetooth выключен")
            return
        }
        activeScanCallback?.let { try { scanner.stopScan(it) } catch (_: Exception) {} }

        scannedMap.clear()
        val rssiMap = mutableMapOf<String, Int>()
        val nameMap = mutableMapOf<String, String>()

        adapter.bondedDevices?.forEach { d ->
            scannedMap[d.address] = d
            nameMap[d.address] = (d.name ?: "Спаренное") + " [Спарен]"
            rssiMap[d.address] = 0
        }
        bleDevicesState = scannedMap.keys.map { a -> ScannedBleDevice(nameMap[a] ?: "", a, rssiMap[a] ?: 0) }
        isScanningBle = true

        val callback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val dev = result.device ?: return
                val addr = dev.address ?: return
                val rawName = result.scanRecord?.deviceName ?: dev.name ?: ""
                scannedMap[addr] = dev
                if (rawName.isNotBlank()) nameMap[addr] = rawName
                rssiMap[addr] = result.rssi
                bleDevicesState = scannedMap.keys.map { a ->
                    ScannedBleDevice(nameMap[a] ?: "BLE-устройство", a, rssiMap[a] ?: -99)
                }.sortedWith(compareByDescending<ScannedBleDevice> { !it.name.startsWith("BLE-") }.thenByDescending { it.rssi }).take(25)
            }
            override fun onScanFailed(errorCode: Int) {
                AppLogger.log("BLE", "Ошибка сканера: код $errorCode")
                isScanningBle = false
            }
        }
        activeScanCallback = callback

        val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build()
        scanner.startScan(null, settings, callback)
        Handler(Looper.getMainLooper()).postDelayed({
            try { scanner.stopScan(callback) } catch (_: Exception) {}
            isScanningBle = false
        }, 10000)
    }
}
