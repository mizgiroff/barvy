package com.medassist.app.data

import org.json.JSONArray
import org.json.JSONObject

object BackupHelper {
    suspend fun exportToJson(dao: MedDao): String {
        val root = JSONObject()
        root.put("version", 1)
        root.put("exportedAt", System.currentTimeMillis())

        val vitalsArr = JSONArray()
        dao.getAllVitals().forEach { v ->
            vitalsArr.put(JSONObject().apply {
                put("timestamp", v.timestamp)
                put("dateKey", v.dateKey)
                put("type", v.type.name)
                put("value1", v.value1)
                if (v.value2 != null) put("value2", v.value2)
                if (v.pulse != null) put("pulse", v.pulse)
                put("note", v.note)
                put("source", v.source.name)
            })
        }
        root.put("vitals", vitalsArr)

        val ctxArr = JSONArray()
        dao.getAllDailyContexts().forEach { c ->
            ctxArr.put(JSONObject().apply {
                put("dateKey", c.dateKey)
                put("steps", c.steps)
                put("sleepMinutes", c.sleepMinutes)
                if (c.weatherPressureMmHg != null) put("pressure", c.weatherPressureMmHg)
                if (c.weatherTempC != null) put("temp", c.weatherTempC)
                put("notes", c.notes)
            })
        }
        root.put("contexts", ctxArr)

        val medsArr = JSONArray()
        dao.getAllMeds().forEach { m ->
            medsArr.put(JSONObject().apply {
                put("dateKey", m.dateKey)
                put("slot", m.slot)
                put("medName", m.medName)
                put("dose", m.dose)
                put("takenAt", m.takenAt)
            })
        }
        root.put("meds", medsArr)
        return root.toString(2)
    }

    suspend fun importFromJson(dao: MedDao, jsonText: String): Int {
        val root = JSONObject(jsonText)
        var count = 0
        val vitalsArr = root.optJSONArray("vitals") ?: JSONArray()
        for (i in 0 until vitalsArr.length()) {
            val o = vitalsArr.getJSONObject(i)
            dao.insertVital(
                VitalEntry(
                    timestamp = o.getLong("timestamp"),
                    dateKey = o.getString("dateKey"),
                    type = VitalType.valueOf(o.getString("type")),
                    value1 = o.getDouble("value1"),
                    value2 = if (o.has("value2")) o.getDouble("value2") else null,
                    pulse = if (o.has("pulse")) o.getInt("pulse") else null,
                    note = o.optString("note", ""),
                    source = DataSource.valueOf(o.optString("source", "MANUAL"))
                )
            )
            count++
        }
        val ctxArr = root.optJSONArray("contexts") ?: JSONArray()
        for (i in 0 until ctxArr.length()) {
            val o = ctxArr.getJSONObject(i)
            dao.upsertDailyContext(
                DailyContext(
                    dateKey = o.getString("dateKey"),
                    steps = o.optLong("steps", 0),
                    sleepMinutes = o.optLong("sleepMinutes", 0),
                    weatherPressureMmHg = if (o.has("pressure")) o.getInt("pressure") else null,
                    weatherTempC = if (o.has("temp")) o.getInt("temp") else null,
                    notes = o.optString("notes", "")
                )
            )
        }
        val medsArr = root.optJSONArray("meds") ?: JSONArray()
        for (i in 0 until medsArr.length()) {
            val o = medsArr.getJSONObject(i)
            dao.insertMedicationEvent(
                MedicationEvent(
                    dateKey = o.getString("dateKey"),
                    slot = o.getString("slot"),
                    medName = o.getString("medName"),
                    dose = o.getString("dose"),
                    takenAt = o.getLong("takenAt")
                )
            )
        }
        return count
    }
}
