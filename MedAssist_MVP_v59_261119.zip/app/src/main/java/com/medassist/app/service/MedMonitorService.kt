package com.medassist.app.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.medassist.app.MainActivity
import com.medassist.app.R
import com.medassist.app.ble.BleDeviceRole
import com.medassist.app.ble.BpDedupCache
import com.medassist.app.ble.ContourBleManager
import com.medassist.app.data.DataSource
import com.medassist.app.data.MedDatabase
import com.medassist.app.data.VitalEntry
import com.medassist.app.data.VitalType
import com.medassist.app.util.AppLogger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

class MedMonitorService : Service() {
    companion object {
        const val CHANNEL_MONITOR = "medassist_monitor"
        const val NOTIF_ID = 101
        const val ACTION_REFRESH = "com.medassist.app.REFRESH_MONITOR"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mainHandler = Handler(Looper.getMainLooper())
    private var bleGlucose: ContourBleManager? = null
    private var bleBp: ContourBleManager? = null
    private var bleScale: ContourBleManager? = null
    private var isDestroyed = false

    private val rearmGluRunnable = Runnable { armAutoConnect(BleDeviceRole.GLUCOSE) }
    private val rearmBpRunnable = Runnable { armAutoConnect(BleDeviceRole.BP) }
    private val rearmScaleRunnable = Runnable { armAutoConnect(BleDeviceRole.SCALE) }

    private fun scheduleRearm(role: BleDeviceRole, hadData: Boolean) {
        if (isDestroyed) return
        val delayMs = when {
            role == BleDeviceRole.GLUCOSE -> 15_000L
            role == BleDeviceRole.BP && hadData -> 300_000L
            hadData -> 90_000L
            else -> 15_000L
        }
        when (role) {
            BleDeviceRole.GLUCOSE -> {
                mainHandler.removeCallbacks(rearmGluRunnable)
                mainHandler.postDelayed(rearmGluRunnable, delayMs)
            }
            BleDeviceRole.BP -> {
                mainHandler.removeCallbacks(rearmBpRunnable)
                mainHandler.postDelayed(rearmBpRunnable, delayMs)
            }
            BleDeviceRole.SCALE -> {
                mainHandler.removeCallbacks(rearmScaleRunnable)
                mainHandler.postDelayed(rearmScaleRunnable, delayMs)
            }
        }
    }

    private fun armAutoConnect(role: BleDeviceRole) {
        if (isDestroyed) return
        val prefs = getSharedPreferences("medassist_prefs", Context.MODE_PRIVATE)
        val btMgr = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val adapter = btMgr.adapter ?: return
        val addr = prefs.getString("pin_${role.name}_addr", null)
        if (addr.isNullOrBlank()) return
        try {
            val dev = adapter.getRemoteDevice(addr)
            when (role) {
                BleDeviceRole.GLUCOSE -> if (bleGlucose?.isConnected != true) {
                    bleGlucose?.connectAuto(dev, BleDeviceRole.GLUCOSE)
                    AppLogger.log("SVC", "Автоожидание глюкометра: $addr")
                }
                BleDeviceRole.BP -> if (bleBp?.isConnected != true) {
                    bleBp?.connectAuto(dev, BleDeviceRole.BP)
                    AppLogger.log("SVC", "Автоожидание тонометра: $addr")
                }
                BleDeviceRole.SCALE -> if (bleScale?.isConnected != true) {
                    bleScale?.connectAuto(dev, BleDeviceRole.SCALE)
                    AppLogger.log("SVC", "Автоожидание весов: $addr")
                }
            }
        } catch (_: SecurityException) {}
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_MONITOR, "Фоновый мониторинг приборов", NotificationManager.IMPORTANCE_LOW)
        )
        val openPi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val notif = NotificationCompat.Builder(this, CHANNEL_MONITOR)
            .setSmallIcon(R.drawable.ic_stat_medassist)
            .setColor(0xFF1565C0.toInt())
            .setContentTitle("MedAssist")
            .setContentText("Ожидание приборов и напоминания активны")
            .setOngoing(true)
            .setContentIntent(openPi)
            .build()
        startForeground(NOTIF_ID, notif)

        val dao = MedDatabase.get(this).dao()

        bleGlucose = ContourBleManager(
            this,
            onGlucoseRead = { mmol, tsMs ->
                scope.launch {
                    val existing = dao.countSimilarVitalsInWindow(VitalType.GLUCOSE, tsMs - 60_000L, tsMs + 60_000L, mmol, null)
                    if (existing == 0) {
                        val dk = Instant.ofEpochMilli(tsMs).atZone(ZoneId.systemDefault()).toLocalDate().toString()
                        dao.insertVital(VitalEntry(timestamp = tsMs, dateKey = dk, type = VitalType.GLUCOSE, value1 = mmol, source = DataSource.BLE_CONTOUR))
                        if (dk == LocalDate.now().toString()) {
                            MedReminderReceiver.notifyBleData(this@MedMonitorService, "Данные приняты (Глюкометр)", "Сахар: $mmol ммоль/л")
                        }
                    }
                }
            },
            onBpRead = { _, _, _, _ -> },
            onWeightRead = {},
            onDisconnected = { role, hadData -> scheduleRearm(role, hadData) }
        )
        bleBp = ContourBleManager(
            this,
            onGlucoseRead = { _, _ -> },
            onBpRead = { sys, dia, pulse, tsMs ->
                scope.launch {
                    val dk = Instant.ofEpochMilli(tsMs).atZone(ZoneId.systemDefault()).toLocalDate().toString()
                    val existing = dao.countSimilarVitalsInWindow(VitalType.BP, tsMs - 60_000L, tsMs + 60_000L, sys, dia)
                    val matching12h = dao.countMatchingBpInWindow(VitalType.BP, tsMs - 12 * 60 * 60_000L, tsMs + 60_000L, sys, dia, pulse)
                    val seenToday = BpDedupCache.isSeen(this@MedMonitorService, dk, sys, dia, pulse)
                    if (existing == 0 && matching12h == 0 && !seenToday) {
                        val wx = dao.getDailyContext(dk)
                        val wxStr = if (wx?.weatherTempC != null) "${wx.weatherPressureMmHg ?: "-"}мм ${wx.weatherTempC}°C ${wx.weatherCondition}".trim() else ""
                        dao.insertVital(VitalEntry(timestamp = tsMs, dateKey = dk, type = VitalType.BP, value1 = sys, value2 = dia, pulse = pulse, source = DataSource.BLE_BP, weatherSummary = wxStr))
                        BpDedupCache.markSeen(this@MedMonitorService, dk, sys, dia, pulse)
                        MedReminderReceiver.notifyBleData(this@MedMonitorService, "Данные приняты (Тонометр)", "Давление: ${sys.toInt()}/${dia.toInt()} · пульс ${pulse ?: "-"}")
                    } else {
                        AppLogger.log("BLE", "Пропущен дубль АД (12ч/кэш): ${sys.toInt()}/${dia.toInt()}-${pulse ?: 0}")
                    }
                }
            },
            onWeightRead = {},
            onDisconnected = { role, hadData -> scheduleRearm(role, hadData) }
        )

        bleScale = ContourBleManager(
            this,
            onGlucoseRead = { _, _ -> },
            onBpRead = { _, _, _, _ -> },
            onWeightRead = { kg ->
                scope.launch {
                    val now = System.currentTimeMillis()
                    val existing = dao.countSimilarVitalsInWindow(VitalType.WEIGHT, now - 60_000L, now + 60_000L, kg, null)
                    if (existing == 0) {
                        dao.insertVital(VitalEntry(timestamp = now, dateKey = LocalDate.now().toString(), type = VitalType.WEIGHT, value1 = kg, source = DataSource.BLE_SCALE))
                        MedReminderReceiver.notifyBleData(this@MedMonitorService, "Данные приняты (Весы)", "Вес: $kg кг")
                    }
                }
            },
            onDisconnected = { role, hadData -> scheduleRearm(role, hadData) }
        )

        armAutoConnect(BleDeviceRole.GLUCOSE)
        armAutoConnect(BleDeviceRole.BP)
        armAutoConnect(BleDeviceRole.SCALE)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_REFRESH) {
            armAutoConnect(BleDeviceRole.GLUCOSE)
            armAutoConnect(BleDeviceRole.BP)
            armAutoConnect(BleDeviceRole.SCALE)
        }
        return START_STICKY
    }

    override fun onDestroy() {
        isDestroyed = true
        mainHandler.removeCallbacksAndMessages(null)
        bleGlucose?.disconnect()?.enqueue()
        bleBp?.disconnect()?.enqueue()
        bleScale?.disconnect()?.enqueue()
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
