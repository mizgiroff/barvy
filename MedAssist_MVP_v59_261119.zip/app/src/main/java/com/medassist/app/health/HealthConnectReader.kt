package com.medassist.app.health

import android.content.Context
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.*
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import com.medassist.app.util.AppLogger
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit
import kotlin.math.roundToInt

data class HealthSnapshot(
    val steps: Long = 0,
    val sleepMinutes: Long = 0,
    val weightKg: Double? = null,
    val weightTimeMillis: Long? = null,
    val bpSys: Double? = null,
    val bpDia: Double? = null,
    val bpPulse: Int? = null,
    val bpTimeMillis: Long? = null
)

class HealthConnectReader(private val context: Context) {

    val requiredPermissions = setOf(
        HealthPermission.getReadPermission(StepsRecord::class),
        HealthPermission.getReadPermission(SleepSessionRecord::class),
        HealthPermission.getReadPermission(WeightRecord::class),
        HealthPermission.getReadPermission(BloodPressureRecord::class),
        HealthPermission.getReadPermission(HeartRateRecord::class),
        HealthPermission.getReadPermission(HydrationRecord::class)
    )

    fun isAvailable(): Boolean =
        HealthConnectClient.getSdkStatus(context) == HealthConnectClient.SDK_AVAILABLE

    suspend fun hasAllPermissions(): Boolean {
        if (!isAvailable()) return false
        val client = HealthConnectClient.getOrCreate(context)
        val granted = client.permissionController.getGrantedPermissions()
        return granted.containsAll(requiredPermissions)
    }

    suspend fun readTodaySnapshot(): HealthSnapshot {
        if (!isAvailable()) {
            AppLogger.log("HC", "Health Connect недоступен")
            return HealthSnapshot()
        }
        val client = HealthConnectClient.getOrCreate(context)
        val zone = ZoneId.systemDefault()
        val startOfDay = LocalDate.now().atStartOfDay(zone).toInstant()
        val now = Instant.now()

        return try {
            val stepsResp = client.readRecords(
                ReadRecordsRequest(StepsRecord::class, TimeRangeFilter.between(startOfDay, now))
            )
            val totalSteps = stepsResp.records.sumOf { it.count }

            val sleepResp = client.readRecords(
                ReadRecordsRequest(
                    SleepSessionRecord::class,
                    TimeRangeFilter.between(startOfDay.minus(12, ChronoUnit.HOURS), now)
                )
            )
            val sleepMin = sleepResp.records.sumOf {
                ChronoUnit.MINUTES.between(it.startTime, it.endTime)
            }

            // Только замеры за СЕГОДНЯ (чтобы вчерашние не дублировались в сегодня)
            val weightResp = client.readRecords(
                ReadRecordsRequest(WeightRecord::class, TimeRangeFilter.between(startOfDay, now))
            )
            val latestWeightRec = weightResp.records.lastOrNull()
            val roundedWeight = latestWeightRec?.weight?.inKilograms?.let {
                (it * 10.0).roundToInt() / 10.0
            }

            val bpResp = client.readRecords(
                ReadRecordsRequest(BloodPressureRecord::class, TimeRangeFilter.between(startOfDay, now))
            )
            val latestBp = bpResp.records.lastOrNull()

            var latestPulse: Int? = null
            if (latestBp != null) {
                val hrResp = client.readRecords(
                    ReadRecordsRequest(
                        HeartRateRecord::class,
                        TimeRangeFilter.between(
                            latestBp.time.minus(3, ChronoUnit.MINUTES),
                            latestBp.time.plus(3, ChronoUnit.MINUTES)
                        )
                    )
                )
                latestPulse = hrResp.records.lastOrNull()?.samples?.lastOrNull()?.beatsPerMinute?.toInt()
            }

            AppLogger.log(
                "HC",
                "Синхр: шаги=$totalSteps, сон=${sleepMin}м, вес=$roundedWeight, АД=${latestBp?.systolic?.inMillimetersOfMercury?.toInt()}/${latestBp?.diastolic?.inMillimetersOfMercury?.toInt()}"
            )
            HealthSnapshot(
                steps = totalSteps,
                sleepMinutes = sleepMin,
                weightKg = roundedWeight,
                weightTimeMillis = latestWeightRec?.time?.toEpochMilli(),
                bpSys = latestBp?.systolic?.inMillimetersOfMercury,
                bpDia = latestBp?.diastolic?.inMillimetersOfMercury,
                bpPulse = latestPulse,
                bpTimeMillis = latestBp?.time?.toEpochMilli()
            )
        } catch (e: Exception) {
            AppLogger.log("HC", "Ошибка чтения: ${e.message}")
            HealthSnapshot()
        }
    }
}
