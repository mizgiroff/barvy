package com.medassist.app.sync

import com.medassist.app.data.FoodDish
import com.medassist.app.data.FoodPlate
import com.medassist.app.util.AppLogger
import com.medassist.app.util.MedSuggestion
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class PlateAnalysis(val name: String, val tareGrams: Int?)
data class FoodAnalysis(
    val dishName: String,
    val xe: Double,
    val carbsGrams: Int,
    val note: String,
    val matchedPlateId: Long? = null,
    val grossGrams: Int? = null
)

/**
 * Работает на базовом бесплатном уровне Gemini API (Google AI Studio Auth Key AQ... или AIza..., без платного биллинга).
 * Автоматически переключается на резервную модель при 503 / 429 / 404.
 */
class GeminiHelper {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(35, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()
    private val jsonMedia = "application/json; charset=utf-8".toMediaType()
    private val models = listOf("gemini-3.8-flash", "gemini-3.5-flash-lite", "gemini-2.5-flash-lite", "gemini-2.5-flash")

    private suspend fun callGemini(apiKey: String, body: JSONObject, tag: String): String? {
        if (apiKey.isBlank()) {
            AppLogger.log("AI", "Не задан Gemini API Key в Настройках")
            return null
        }
        val payload = body.toString()
        for ((idx, model) in models.withIndex()) {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"
            val req = Request.Builder()
                .url(url)
                .addHeader("x-goog-api-key", apiKey.trim())
                .post(payload.toRequestBody(jsonMedia))
                .build()
            try {
                client.newCall(req).execute().use { resp ->
                    val rawResp = resp.body?.string() ?: "{}"
                    if (resp.isSuccessful) {
                        AppLogger.log("AI", "$tag OK ($model)")
                        return JSONObject(rawResp)
                            .getJSONArray("candidates").getJSONObject(0)
                            .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
                            .getString("text")
                            .replace("```json", "").replace("```", "").trim()
                    }
                    AppLogger.log("AI", "$tag $model HTTP ${resp.code}: ${rawResp.take(120)}")
                    if (resp.code !in listOf(404, 429, 500, 503)) return null
                }
            } catch (e: Exception) {
                AppLogger.log("AI", "$tag $model ошибка: ${e.message}")
            }
            if (idx < models.lastIndex) delay(600)
        }
        return null
    }

    suspend fun lookupMedication(apiKey: String, rawQuery: String): MedSuggestion? = withContext(Dispatchers.IO) {
        if (rawQuery.isBlank()) return@withContext null
        val prompt = "Пользователь ввёл название лекарства: '$rawQuery'. Исправь опечатку и верни строго JSON без markdown: {\"name\":\"Точное название\",\"dosages\":[\"дозировка 1\",\"дозировка 2\"],\"effect\":\"подробное описание на русском (фармгруппа, основное назначение, ключевые ограничения приёма, до 15 слов)\"}."
        val body = JSONObject().apply {
            put("contents", JSONArray().put(JSONObject().apply {
                put("parts", JSONArray().put(JSONObject().apply { put("text", prompt) }))
            }))
        }
        val text = callGemini(apiKey, body, "Gemini Med") ?: return@withContext null
        return@withContext try {
            val obj = JSONObject(text)
            val arr = obj.optJSONArray("dosages") ?: JSONArray()
            val dosages = (0 until arr.length()).mapNotNull { arr.optString(it).takeIf { s -> s.isNotBlank() } }
            MedSuggestion(
                name = obj.optString("name", rawQuery),
                dosages = dosages,
                effect = obj.optString("effect", "")
            )
        } catch (e: Exception) {
            AppLogger.log("AI", "JSON Med: ${e.message}")
            null
        }
    }

    private fun buildDishCalibrationHint(userDishes: List<FoodDish>): String {
        val refs = userDishes.take(15)
        if (refs.isEmpty()) return ""
        val txt = refs.joinToString("; ") { d ->
            val gPart = if (d.defaultGrams > 0) " (${d.defaultGrams}г/мл)" else ""
            "${d.name}$gPart = ${d.xe} ХЕ"
        }
        return " Личные эталоны пользователя (учитывай как ориентир): $txt."
    }

    private val foodRulesPrompt = "ВАЖНЫЕ ПРАВИЛА РАСЧЁТА: 1) Напитки с молоком (кофе с молоком, чай с молоком, капучино): сам кофе/чай/вода содержат 0 г углеводов; НЕ считай весь объём кружки как молоко — бери реальную долю молока (обычно 60-80 мл = ~0.3-0.4 ХЕ), если не указано иное. 2) Смешанные блюда (тушёная капуста с мясом, рагу с мясом, супы/борщи): обязательно вычитай долю безуглеводных компонентов (мясо, курица, рыба, бульон = 0 г угл., обычно 30-40% веса) и не применяй углеводы чистого овоща ко всему весу."

    suspend fun analyzeFoodPhoto(
        apiKey: String,
        imageBase64: String,
        plates: List<FoodPlate>,
        manualNetGrams: Int?,
        extraHint: String = "",
        userDishes: List<FoodDish> = emptyList()
    ): FoodAnalysis? = withContext(Dispatchers.IO) {
        if (imageBase64.isBlank()) return@withContext null
        val platesDesc = if (plates.isEmpty()) "База тарелок пуста."
        else "Сохранённые тарелки пользователя: " + plates.joinToString("; ") { "id=${it.id}: '${it.name}' (тара ${it.tareGrams}г)" }
        val weightHint = if (manualNetGrams != null && manualNetGrams > 0) "Пользователь уже указал точный вес/объём нетто: $manualNetGrams г/мл. Считай ХЕ строго на это количество."
        else "Если на фото виден дисплей кухонных весов, считай общий вес брутто в граммах (grossGrams), вычти вес тары подобранной тарелки и посчитай ХЕ для веса нетто."
        val hintPart = if (extraHint.isNotBlank()) " Дополнительное уточнение пользователя (обязательно учти и прибавь к общему расчёту ХЕ): ${extraHint.trim()}." else ""
        val calHint = buildDishCalibrationHint(userDishes)
        val prompt = "На фото тарелка с едой (возможно на кухонных весах). $platesDesc $weightHint$hintPart$calHint $foodRulesPrompt Определи блюдо, посчитай углеводы (1 ХЕ = 12 г углеводов) и в note укажи краткую разбивку по компонентам. Верни строго JSON без markdown: {\"matchedPlateId\":null,\"grossGrams\":null,\"dishName\":\"название\",\"carbsGrams\":45,\"xe\":3.8,\"note\":\"краткая разбивка\"}."
        val parts = JSONArray()
            .put(JSONObject().apply { put("text", prompt) })
            .put(JSONObject().apply {
                put("inline_data", JSONObject().apply {
                    put("mime_type", "image/jpeg")
                    put("data", imageBase64)
                })
            })
        val body = JSONObject().apply {
            put("contents", JSONArray().put(JSONObject().apply { put("parts", parts) }))
        }
        val text = callGemini(apiKey, body, "Gemini Food") ?: return@withContext null
        return@withContext try {
            val obj = JSONObject(text)
            val mpId = if (obj.has("matchedPlateId") && !obj.isNull("matchedPlateId")) obj.optLong("matchedPlateId") else null
            val gGrams = if (obj.has("grossGrams") && !obj.isNull("grossGrams")) obj.optInt("grossGrams") else null
            AppLogger.log("AI", "Еда распознана: ${obj.optString("dishName")} (${obj.optDouble("xe")} ХЕ)")
            FoodAnalysis(
                dishName = obj.optString("dishName", "Блюдо"),
                xe = obj.optDouble("xe", 0.0),
                carbsGrams = obj.optInt("carbsGrams", 0),
                note = obj.optString("note", ""),
                matchedPlateId = mpId,
                grossGrams = gGrams
            )
        } catch (e: Exception) {
            AppLogger.log("AI", "JSON Food: ${e.message}")
            null
        }
    }

    suspend fun analyzeFoodText(
        apiKey: String,
        dishText: String,
        manualNetGrams: Int?,
        extraHint: String = "",
        userDishes: List<FoodDish> = emptyList()
    ): FoodAnalysis? = withContext(Dispatchers.IO) {
        if (dishText.isBlank()) return@withContext null
        val weightHint = if (manualNetGrams != null && manualNetGrams > 0) "Вес/объём нетто: $manualNetGrams г/мл." else "Если вес не указан, оцени стандартную порцию."
        val hintPart = if (extraHint.isNotBlank()) " Уточнение пользователя: ${extraHint.trim()}." else ""
        val calHint = buildDishCalibrationHint(userDishes)
        val prompt = "Блюдо/напиток: '${dishText.trim()}'. $weightHint$hintPart$calHint $foodRulesPrompt Посчитай углеводы (1 ХЕ = 12 г углеводов) и в note укажи краткую разбивку по компонентам. Верни строго JSON без markdown: {\"dishName\":\"название\",\"carbsGrams\":12,\"xe\":1.0,\"note\":\"краткая разбивка\"}."
        val parts = JSONArray().put(JSONObject().apply { put("text", prompt) })
        val body = JSONObject().apply {
            put("contents", JSONArray().put(JSONObject().apply { put("parts", parts) }))
        }
        val text = callGemini(apiKey, body, "Gemini FoodText") ?: return@withContext null
        return@withContext try {
            val obj = JSONObject(text)
            AppLogger.log("AI", "Еда по тексту: ${obj.optString("dishName")} (${obj.optDouble("xe")} ХЕ)")
            FoodAnalysis(
                dishName = obj.optString("dishName", dishText.trim()),
                xe = obj.optDouble("xe", 0.0),
                carbsGrams = obj.optInt("carbsGrams", 0),
                note = obj.optString("note", "")
            )
        } catch (e: Exception) {
            AppLogger.log("AI", "JSON FoodText: ${e.message}")
            null
        }
    }

    suspend fun generateDailyAdvice(apiKey: String, summary: String): String? = withContext(Dispatchers.IO) {
        if (summary.isBlank()) return@withContext null
        val prompt = "Ты бодрый, практичный и слегка ироничный домашний помощник по здоровью. По текущим данным за сегодня ($summary) дай ОДИН короткий живой совет на русском (1-2 коротких предложения, до 160 символов, без markdown и JSON): например, если давление в норме и мало шагов — подколи пройтись/поприседать; если давление повышенное — напомни отдохнуть и про назначенный препарат от давления; если еда углеводная/жирная — посоветуй овощи/воду. Пиши по-дружески, конкретно и без занудства."
        val parts = JSONArray().put(JSONObject().apply { put("text", prompt) })
        val body = JSONObject().apply {
            put("contents", JSONArray().put(JSONObject().apply { put("parts", parts) }))
        }
        callGemini(apiKey, body, "Gemini Advice")?.trim()?.replace("\n", " ")
    }

    suspend fun askAdviceChat(
        apiKey: String,
        dayContext: String,
        history: List<Pair<Boolean, String>>,
        userMessage: String
    ): String? = withContext(Dispatchers.IO) {
        if (userMessage.isBlank()) return@withContext null
        val contents = JSONArray()
        contents.put(JSONObject().apply {
            put("role", "user")
            put("parts", JSONArray().put(JSONObject().apply {
                put("text", "Ты умный, дружелюбный и практичный помощник по здоровью в приложении MedAssist. Отвечай кратко, по делу, на русском, без markdown-звёздочек. Контекст показателей пользователя за сегодня: $dayContext")
            }))
        })
        contents.put(JSONObject().apply {
            put("role", "model")
            put("parts", JSONArray().put(JSONObject().apply {
                put("text", "Понял, учитываю сегодняшние показатели. Чем помочь?")
            }))
        })
        history.takeLast(10).forEach { (isUser, msg) ->
            contents.put(JSONObject().apply {
                put("role", if (isUser) "user" else "model")
                put("parts", JSONArray().put(JSONObject().apply { put("text", msg) }))
            })
        }
        contents.put(JSONObject().apply {
            put("role", "user")
            put("parts", JSONArray().put(JSONObject().apply { put("text", userMessage.trim()) }))
        })
        val body = JSONObject().apply { put("contents", contents) }
        callGemini(apiKey, body, "Gemini Chat")?.trim()
    }

    suspend fun identifyPlatePhoto(apiKey: String, imageBase64: String): PlateAnalysis? = withContext(Dispatchers.IO) {
        if (imageBase64.isBlank()) return@withContext null
        val prompt = "На фото пустая тарелка/посуда (возможно на кухонных весах). Определи короткое название посуды на русском (2-4 слова, например Белая глубокая тарелка) и если на дисплее весов видны цифры веса в граммах, считай целое число tareGrams. Верни строго JSON без markdown: {\"name\":\"название\",\"tareGrams\":340} (если вес не виден, tareGrams: null)."
        val parts = JSONArray()
            .put(JSONObject().apply { put("text", prompt) })
            .put(JSONObject().apply {
                put("inline_data", JSONObject().apply {
                    put("mime_type", "image/jpeg")
                    put("data", imageBase64)
                })
            })
        val body = JSONObject().apply {
            put("contents", JSONArray().put(JSONObject().apply { put("parts", parts) }))
        }
        val text = callGemini(apiKey, body, "Gemini Plate") ?: return@withContext null
        return@withContext try {
            val obj = JSONObject(text)
            val tare = if (obj.has("tareGrams") && !obj.isNull("tareGrams")) obj.optInt("tareGrams") else null
            AppLogger.log("AI", "Тарелка распознана: ${obj.optString("name")} (${tare ?: "-"}г)")
            PlateAnalysis(
                name = obj.optString("name", "").trim(),
                tareGrams = tare
            )
        } catch (e: Exception) {
            AppLogger.log("AI", "JSON Plate: ${e.message}")
            null
        }
    }
}