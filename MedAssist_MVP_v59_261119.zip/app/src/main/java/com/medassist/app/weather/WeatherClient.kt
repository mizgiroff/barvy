package com.medassist.app.weather

import com.medassist.app.util.AppLogger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import kotlin.math.roundToInt

data class WeatherForecastDay(
    val date: String,
    val minC: Int,
    val maxC: Int,
    val precipMm: Double,
    val condition: String
)

data class LvivWeather(
    val tempC: Int,
    val feelsLikeC: Int,
    val pressureMmHg: Int,
    val humidity: Int,
    val windKmh: Int,
    val condition: String,
    val forecast: List<WeatherForecastDay> = emptyList()
)

class WeatherClient {
    private val client = OkHttpClient()

    @Volatile
    var latestForecast: List<WeatherForecastDay> = emptyList()
        private set

    suspend fun fetchLvivWeather(): LvivWeather? = withContext(Dispatchers.IO) {
        val url = "https://api.open-meteo.com/v1/forecast?latitude=49.8397&longitude=24.0297&current=temperature_2m,apparent_temperature,relative_humidity_2m,surface_pressure,wind_speed_10m,weather_code&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum&forecast_days=2&timezone=auto"
        val req = Request.Builder().url(url).build()
        return@withContext try {
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext null
                val root = JSONObject(resp.body?.string() ?: return@withContext null)
                val current = root.getJSONObject("current")
                val temp = current.getDouble("temperature_2m").roundToInt()
                val feels = current.optDouble("apparent_temperature", temp.toDouble()).roundToInt()
                val humidity = current.optDouble("relative_humidity_2m", 0.0).roundToInt()
                val wind = current.optDouble("wind_speed_10m", 0.0).roundToInt()
                val hpa = current.getDouble("surface_pressure")
                val mmHg = (hpa * 0.750062).roundToInt()
                val wmo = current.optInt("weather_code", 0)
                val cond = wmoToText(wmo)

                val fc = mutableListOf<WeatherForecastDay>()
                val daily = root.optJSONObject("daily")
                if (daily != null) {
                    val dates = daily.optJSONArray("time")
                    val mins = daily.optJSONArray("temperature_2m_min")
                    val maxs = daily.optJSONArray("temperature_2m_max")
                    val precs = daily.optJSONArray("precipitation_sum")
                    val codes = daily.optJSONArray("weather_code")
                    if (dates != null && mins != null && maxs != null) {
                        for (i in 0 until dates.length()) {
                            fc.add(
                                WeatherForecastDay(
                                    date = dates.optString(i),
                                    minC = mins.optDouble(i).roundToInt(),
                                    maxC = maxs.optDouble(i).roundToInt(),
                                    precipMm = precs?.optDouble(i, 0.0) ?: 0.0,
                                    condition = wmoToText(codes?.optInt(i, 0) ?: 0)
                                )
                            )
                        }
                    }
                }
                latestForecast = fc
                AppLogger.log("WX", "Погода: ${temp}°C (ощущ. ${feels}°C), $mmHg мм, $humidity%, ${wind}км/ч, $cond")
                LvivWeather(temp, feels, mmHg, humidity, wind, cond, fc)
            }
        } catch (e: Exception) {
            AppLogger.log("WX", "Ошибка погоды: ${e.message}")
            null
        }
    }

    private fun wmoToText(code: Int): String = when (code) {
        0 -> "ясно"
        1, 2, 3 -> "облачно"
        45, 48 -> "туман"
        51, 53, 55, 56, 57 -> "морось"
        61, 63, 65, 66, 67, 80, 81, 82 -> "дождь"
        71, 73, 75, 77, 85, 86 -> "снег"
        95, 96, 99 -> "гроза"
        else -> "переменно"
    }
}
