package com.barvy.wallpaper

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.OutOfQuotaPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.math.roundToInt

class WallpaperWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        val repo = WallpaperRepository(applicationContext)
        val hasFine = ContextCompat.checkSelfPermission(
            applicationContext,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val hasCoarse = ContextCompat.checkSelfPermission(
            applicationContext,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasFine && !hasCoarse) {
            repo.recordStatus(StatusMsgType.NO_PERM)
            return Result.success()
        }

        val location = getBestLocation(applicationContext)
        if (location == null) {
            repo.recordStatus(StatusMsgType.GPS_FAILED)
            return Result.retry()
        }

        GeofenceManager.registerNearestGeofences(
            applicationContext,
            location.latitude,
            location.longitude
        )

        val catalog = repo.loadCatalog()
        val status = repo.getStatus()
        val match = GeoMatcher.findNearestWithinRadius(
            lat = location.latitude,
            lon = location.longitude,
            catalog = catalog,
            radiusMeters = repo.getRadiusMeters(),
            lastAppliedId = status.lastAppliedId.takeIf { it > 0 }
        )

        if (match == null) {
            val nearest = GeoMatcher.findNearestAny(location.latitude, location.longitude, catalog)
            if (nearest != null) {
                val km = String.format(Locale.US, "%.1f", nearest.distanceMeters / 1000.0)
                repo.recordStatus(StatusMsgType.NONE_IN_RADIUS_NEAREST, item = nearest.item, kmText = km)
            } else {
                repo.recordStatus(StatusMsgType.NONE_IN_RADIUS)
            }
            return Result.success()
        }

        if (match.item.id == status.lastAppliedId) {
            repo.recordStatus(
                StatusMsgType.UP_TO_DATE,
                item = match.item,
                distanceMeters = match.distanceMeters.roundToInt()
            )
            return Result.success()
        }

        val ok = repo.applyLockScreenWallpaper(match.item, match.distanceMeters.roundToInt())
        if (!ok) {
            repo.recordStatus(StatusMsgType.DOWNLOAD_FAILED, item = match.item)
            return Result.retry()
        }

        return Result.success()
    }

    companion object {
        private const val UNIQUE_WORK_NAME = "barvy_geo_wallpaper_work"
        private const val IMMEDIATE_WORK_NAME = "barvy_geo_immediate_work"

        fun schedulePeriodic(context: Context) {
            val request = PeriodicWorkRequestBuilder<WallpaperWorker>(15, TimeUnit.MINUTES)
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                UNIQUE_WORK_NAME,
                ExistingPeriodicWorkPolicy.UPDATE,
                request
            )
        }

        fun cancelPeriodic(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(UNIQUE_WORK_NAME)
        }

        fun triggerImmediate(context: Context) {
            val request = OneTimeWorkRequestBuilder<WallpaperWorker>()
                .setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST)
                .build()
            WorkManager.getInstance(context).enqueueUniqueWork(
                IMMEDIATE_WORK_NAME,
                ExistingWorkPolicy.REPLACE,
                request
            )
        }

        @Suppress("MissingPermission")
        suspend fun getBestLocation(context: Context): Location? {
            val fused = LocationServices.getFusedLocationProviderClient(context)
            val high = suspendCancellableCoroutine<Location?> { cont ->
                val cts = CancellationTokenSource()
                fused.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, cts.token)
                    .addOnSuccessListener { loc -> cont.resume(loc) }
                    .addOnFailureListener { cont.resume(null) }
                cont.invokeOnCancellation { cts.cancel() }
            }
            if (high != null) return high

            val balanced = suspendCancellableCoroutine<Location?> { cont ->
                val cts = CancellationTokenSource()
                fused.getCurrentLocation(Priority.PRIORITY_BALANCED_POWER_ACCURACY, cts.token)
                    .addOnSuccessListener { loc -> cont.resume(loc) }
                    .addOnFailureListener { cont.resume(null) }
                cont.invokeOnCancellation { cts.cancel() }
            }
            if (balanced != null) return balanced

            val last = suspendCancellableCoroutine<Location?> { cont ->
                fused.lastLocation
                    .addOnSuccessListener { loc -> cont.resume(loc) }
                    .addOnFailureListener { cont.resume(null) }
            }
            if (last != null) return last

            val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
            return lm?.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                ?: lm?.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
        }
    }
}
