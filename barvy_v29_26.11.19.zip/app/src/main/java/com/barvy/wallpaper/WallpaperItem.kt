package com.barvy.wallpaper

import org.json.JSONArray

data class WallpaperItem(
    val id: Int,
    val city: String,
    val description: String,
    val fileId: String,
    val filename: String,
    val lat: Double,
    val lon: Double,
    val cityEn: String = city,
    val descriptionEn: String = description
) {
    fun cityFor(lang: AppLang): String = if (lang == AppLang.EN) cityEn else city

    fun descriptionFor(lang: AppLang): String = if (lang == AppLang.EN) descriptionEn else description

    fun primaryDownloadUrl(): String =
        "https://drive.google.com/uc?export=download&id=$fileId"

    fun fallbackDownloadUrl(): String =
        "https://lh3.googleusercontent.com/d/$fileId=w1440"

    companion object {
        fun parseJson(jsonText: String): List<WallpaperItem> {
            val array = JSONArray(jsonText)
            val result = ArrayList<WallpaperItem>(array.length())
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val cityUk = obj.getString("city")
                val descUk = obj.getString("description")
                result.add(
                    WallpaperItem(
                        id = obj.getInt("id"),
                        city = cityUk,
                        description = descUk,
                        fileId = obj.getString("fileId"),
                        filename = obj.getString("filename"),
                        lat = obj.getDouble("lat"),
                        lon = obj.getDouble("lon"),
                        cityEn = obj.optString("cityEn", cityUk),
                        descriptionEn = obj.optString("descriptionEn", descUk)
                    )
                )
            }
            return result
        }
    }
}
