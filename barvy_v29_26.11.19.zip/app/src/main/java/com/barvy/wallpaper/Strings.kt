package com.barvy.wallpaper

import java.util.Locale

enum class AppLang(val code: String) {
    UK("uk"),
    EN("en");

    companion object {
        fun fromCode(code: String?): AppLang {
            return if (code == "en") EN else UK
        }

        fun defaultForSystem(): AppLang {
            val sys = Locale.getDefault().language
            return if (sys == "en") EN else UK
        }
    }
}

data class UiStrings(
    val headerTitle: String,
    val autoSwitchTitle: String,
    val autoSwitchSubtitle: String,
    val drivingModeTitle: String,
    val drivingModeSubtitle: String,
    val lastCheckPrefix: String,
    val checkNowButton: String,
    val catalogHeader: (Int, Int) -> String,
    val catalogSubtitle: String,
    val filterAll: String,
    val setLockScreenButton: String,
    val notCheckedYet: String,
    val initialPrompt: String,
    val noLocationPermission: String,
    val needLocationPermission: String,
    val gpsFailed: String,
    val noneInRadiusWithNearest: (String, String) -> String,
    val noneInRadius: String,
    val alreadyUpToDate: (String, Int) -> String,
    val downloadFailed: (String) -> String,
    val wallpaperApplied: (String, String) -> String,
    val cacheClearedNote: String,
    val permissionsCardTitle: String,
    val permissionsCardSubtitle: String,
    val permGeoFgTitle: String,
    val permGeoFgDesc: String,
    val permGeoBgTitle: String,
    val permGeoBgDesc: String,
    val permBatteryTitle: String,
    val permBatteryDesc: String,
    val permNotifTitle: String,
    val permNotifDesc: String,
    val statusGranted: String,
    val statusNeeded: String,
    val openAppSettingsButton: String,
    val requestBatteryIgnoreButton: String,
    val drivingNotifChannel: String,
    val drivingNotifTitle: String,
    val drivingNotifText: String,
    val hideGuide: String,
    val showGuide: String
)

object AppStrings {
    fun get(lang: AppLang): UiStrings = when (lang) {
        AppLang.UK -> UiStrings(
            headerTitle = "Barvy • Львів і область",
            autoSwitchTitle = "Автозміна (радіус 1 км)",
            autoSwitchSubtitle = "Лише екран блокування • v29_26.11.19",
            drivingModeTitle = "Режим поїздки (GPS у дорозі)",
            drivingModeSubtitle = "Постійний точний GPS для миттєвої зміни в авто",
            lastCheckPrefix = "Остання перевірка",
            checkNowButton = "Перевірити геолокацію зараз",
            catalogHeader = { shown, total -> "Каталог ($shown із $total)" },
            catalogSubtitle = "Львівська область",
            filterAll = "Усі",
            setLockScreenButton = "Поставити на екран блокування",
            notCheckedYet = "Ще не перевірялось",
            initialPrompt = "Натисніть «Перевірити геолокацію зараз» або увімкніть автозміну",
            noLocationPermission = "Немає дозволу на геолокацію",
            needLocationPermission = "Для автозміни потрібен дозвіл на геолокацію",
            gpsFailed = "Не вдалося отримати GPS-координати",
            noneInRadiusWithNearest = { city, km -> "У радіусі 1 км об'єктів немає. Найближчий: $city ($km км)" },
            noneInRadius = "У радіусі 1 км об'єктів не знайдено",
            alreadyUpToDate = { city, m -> "Ви поруч із «$city» ($m м) — заставка актуальна" },
            downloadFailed = { name -> "Помилка завантаження фото: $name. Перевірте інтернет." },
            wallpaperApplied = { city, fname -> "Встановлено на екран блокування: $city ($fname)" },
            cacheClearedNote = "Оновлено каталог v29: старий кеш очищено, підтягуються підписані фото.",
            permissionsCardTitle = "Налаштування дозволів і фонової роботи",
            permissionsCardSubtitle = "Чому це потрібно для автозміни без відкриття програми",
            permGeoFgTitle = "1. Точна геолокація",
            permGeoFgDesc = "Дозволяє визначати, біля якої пам'ятки ви зараз перебуваєте (радіус 1 км).",
            permGeoBgTitle = "2. Геолокація у фоні («Дозволити завжди»)",
            permGeoBgDesc = "Найважливіший дозвіл! Без «Дозволити завжди» Android блокує геозони та перевірки, коли екран вимкнено або програма згорнута. Відкрийте Налаштування → Дозволи → Геолокація → Дозволити завжди.",
            permBatteryTitle = "3. Батарея («Без обмежень»)",
            permBatteryDesc = "Забороняє системі присипляти Barvy у дорозі. Налаштування → Батарея → Без обмежень.",
            permNotifTitle = "4. Сповіщення (Android 13+)",
            permNotifDesc = "Потрібні для тихого індикатора «Режиму поїздки» під час руху на авто.",
            statusGranted = "Надано",
            statusNeeded = "Потрібно",
            openAppSettingsButton = "Налаштування програми",
            requestBatteryIgnoreButton = "Вимкнути економію батареї",
            drivingNotifChannel = "Режим поїздки Barvy",
            drivingNotifTitle = "Barvy • Режим поїздки",
            drivingNotifText = "Відстеження пам'яток у радіусі 1 км",
            hideGuide = "Сховати підказку",
            showGuide = "Як налаштувати автозміну?"
        )

        AppLang.EN -> UiStrings(
            headerTitle = "Barvy • Lviv & Oblast",
            autoSwitchTitle = "Auto-switch (1 km radius)",
            autoSwitchSubtitle = "Lock screen only • v29_26.11.19",
            drivingModeTitle = "Driving Mode (Live GPS)",
            drivingModeSubtitle = "Continuous high-accuracy GPS for instant switching on the road",
            lastCheckPrefix = "Last check",
            checkNowButton = "Check location now",
            catalogHeader = { shown, total -> "Catalog ($shown of $total)" },
            catalogSubtitle = "Lviv Oblast",
            filterAll = "All",
            setLockScreenButton = "Set on lock screen",
            notCheckedYet = "Not checked yet",
            initialPrompt = "Tap \"Check location now\" or enable Auto-switch",
            noLocationPermission = "Location permission not granted",
            needLocationPermission = "Location permission is required for auto-switch",
            gpsFailed = "Failed to get GPS coordinates",
            noneInRadiusWithNearest = { city, km -> "No landmarks within 1 km. Nearest: $city ($km km)" },
            noneInRadius = "No landmarks found within 1 km",
            alreadyUpToDate = { city, m -> "Near \"$city\" ($m m) — wallpaper is up to date" },
            downloadFailed = { name -> "Failed to download photo: $name. Check internet." },
            wallpaperApplied = { city, fname -> "Lock screen updated: $city ($fname)" },
            cacheClearedNote = "Catalog v29 updated: old cache cleared, signed photos enabled.",
            permissionsCardTitle = "Permissions & Background Setup",
            permissionsCardSubtitle = "Why each setting is needed for hands-free wallpaper switching",
            permGeoFgTitle = "1. Precise Location",
            permGeoFgDesc = "Identifies which landmark is within 1 km of your current position.",
            permGeoBgTitle = "2. Background Location (\"Allow all the time\")",
            permGeoBgDesc = "Crucial! Without \"Allow all the time\", Android blocks geofences and background checks when the screen is off. Go to App Settings → Permissions → Location → Allow all the time.",
            permBatteryTitle = "3. Battery (\"Unrestricted\")",
            permBatteryDesc = "Prevents Android from putting Barvy to sleep while driving. Go to App Settings → Battery → Unrestricted.",
            permNotifTitle = "4. Notifications (Android 13+)",
            permNotifDesc = "Required to display the quiet \"Driving Mode\" status notification while on the road.",
            statusGranted = "Granted",
            statusNeeded = "Required",
            openAppSettingsButton = "Open App Settings",
            requestBatteryIgnoreButton = "Disable battery optimization",
            drivingNotifChannel = "Barvy Driving Mode",
            drivingNotifTitle = "Barvy • Driving Mode",
            drivingNotifText = "Tracking landmarks within 1 km",
            hideGuide = "Hide guide",
            showGuide = "How to set up auto-switch?"
        )
    }
}
