package com.barvy.wallpaper

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

enum class AccessTier(val code: String) {
    FREE_REGION("FREE_REGION"),
    COUNTRY("COUNTRY"),
    FIVE_COUNTRIES("FIVE_COUNTRIES"),
    WORLD("WORLD"),
    VIP("VIP");

    companion object {
        fun fromCode(code: String?): AccessTier =
            entries.firstOrNull { it.code == code } ?: FREE_REGION
    }
}

enum class StatusMsgType {
    INITIAL,
    CACHE_CLEARED,
    NO_PERM,
    NEED_PERM,
    GPS_FAILED,
    NONE_IN_RADIUS,
    NONE_IN_RADIUS_NEAREST,
    UP_TO_DATE,
    DOWNLOAD_FAILED,
    APPLIED
}

data class AppStatus(
    val autoEnabled: Boolean,
    val drivingModeEnabled: Boolean,
    val radiusKm: Int,
    val language: AppLang,
    val theme: AppTheme,
    val lastAppliedId: Int,
    val lastAppliedCity: String,
    val lastAppliedDesc: String,
    val lastAppliedFileId: String,
    val lastDistanceMeters: Int,
    val lastCheckedTime: String,
    val lastMessage: String
)

class WallpaperRepository(private val context: Context) {

    private val prefs = context.getSharedPreferences("barvy_prefs", Context.MODE_PRIVATE)

    private val client = OkHttpClient.Builder()
        .followRedirects(true)
        .followSslRedirects(true)
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    init {
        clearOldCacheIfNeeded()
    }

    private fun clearOldCacheIfNeeded() {
        val savedVersion = prefs.getInt(KEY_CATALOG_VERSION, 0)
        if (savedVersion < CURRENT_CATALOG_VERSION) {
            val dir = File(context.filesDir, "wallpapers")
            if (dir.exists()) {
                dir.listFiles()?.forEach { it.delete() }
            }
            prefs.edit()
                .putInt(KEY_CATALOG_VERSION, CURRENT_CATALOG_VERSION)
                .putInt("last_applied_id", -1)
                .putString("last_applied_file_id", "")
                .putString(KEY_MSG_TYPE, StatusMsgType.CACHE_CLEARED.name)
                .apply()
        }
    }

    fun hasLanguageChosen(): Boolean = prefs.contains(KEY_LANGUAGE)

    fun getTheme(): AppTheme = AppTheme.fromCode(prefs.getString(KEY_THEME, AppTheme.SYSTEM.code))

    fun setTheme(theme: AppTheme) {
        prefs.edit().putString(KEY_THEME, theme.code).apply()
    }

    fun getOrCreateDeviceId(): String {
        val existing = prefs.getString(KEY_DEVICE_ID, null)
        if (!existing.isNullOrBlank()) return existing
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val p1 = (1..4).map { chars.random() }.joinToString("")
        val p2 = (1..4).map { chars.random() }.joinToString("")
        val generated = "BRV-$p1-$p2"
        prefs.edit().putString(KEY_DEVICE_ID, generated).apply()
        return generated
    }

    fun getAccessTier(): AccessTier = AccessTier.fromCode(prefs.getString(KEY_ACCESS_TIER, AccessTier.FREE_REGION.code))

    fun getLockedFreeRegion(): String? = prefs.getString(KEY_LOCKED_FREE_REGION, null)?.takeIf { it.isNotBlank() }

    fun setLockedFreeRegion(region: String) {
        if (getLockedFreeRegion() == null && region.isNotBlank()) {
            prefs.edit().putString(KEY_LOCKED_FREE_REGION, region).apply()
        }
    }

    fun getLockedCountries(): Set<String> = prefs.getStringSet(KEY_LOCKED_COUNTRIES, emptySet()) ?: emptySet()

    fun setLockedCountries(codes: Set<String>) {
        prefs.edit().putStringSet(KEY_LOCKED_COUNTRIES, codes).apply()
    }

    fun isItemUnlocked(item: WallpaperItem): Boolean {
        return when (getAccessTier()) {
            AccessTier.VIP, AccessTier.WORLD -> true
            AccessTier.FIVE_COUNTRIES -> item.countryCode in getLockedCountries()
            AccessTier.COUNTRY -> getLockedCountries().firstOrNull()?.let { item.countryCode == it } ?: false
            AccessTier.FREE_REGION -> {
                val locked = getLockedFreeRegion()
                locked != null && item.region == locked
            }
        }
    }

    fun filterUnlocked(catalog: List<WallpaperItem>): List<WallpaperItem> {
        val tier = getAccessTier()
        if (tier == AccessTier.VIP || tier == AccessTier.WORLD) return catalog
        val lockedReg = getLockedFreeRegion()
        if (tier == AccessTier.FREE_REGION && lockedReg == null) {
            return emptyList()
        }
        return catalog.filter { isItemUnlocked(it) }
    }

    fun activateVipCode(rawCode: String): Pair<Boolean, String> {
        val code = rawCode.trim().uppercase()
        if (code.isBlank()) return Pair(false, "Empty code")
        val devId = getOrCreateDeviceId()
        return try {
            val req = Request.Builder()
                .url(REMOTE_VIP_URL)
                .header("User-Agent", "BarvyAndroid/45")
                .build()
            val body = client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return Pair(false, "HTTP ${resp.code}")
                resp.body?.string() ?: return Pair(false, "Empty response")
            }
            val arr = org.json.JSONArray(body)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val entryCode = obj.optString("code", "").trim().uppercase()
                val entryDev = obj.optString("deviceId", "").trim().uppercase()
                val status = obj.optString("status", "")
                val tierCode = obj.optString("tier", "VIP").trim().uppercase()
                if (status == "Отозван") continue
                val codeMatch = entryCode == code
                val devMatch = entryDev.isNotBlank() && entryDev == devId
                if (codeMatch && (entryDev.isBlank() || devMatch)) {
                    val mappedTier = when (tierCode) {
                        "WORLD" -> AccessTier.WORLD
                        "FIVE_COUNTRIES" -> AccessTier.FIVE_COUNTRIES
                        "COUNTRY" -> AccessTier.COUNTRY
                        else -> AccessTier.VIP
                    }
                    prefs.edit()
                        .putString(KEY_ACCESS_TIER, mappedTier.code)
                        .putString(KEY_ACTIVE_VIP_CODE, entryCode)
                        .apply()
                    return Pair(true, mappedTier.code)
                }
            }
            Pair(false, "Not found")
        } catch (e: Exception) {
            Pair(false, e.message ?: "Error")
        }
    }

    fun getLanguage(): AppLang {
        val saved = prefs.getString(KEY_LANGUAGE, null)
        return if (saved != null) AppLang.fromCode(saved) else AppLang.defaultForSystem()
    }

    fun setLanguage(lang: AppLang) {
        prefs.edit().putString(KEY_LANGUAGE, lang.code).apply()
    }

    fun strings(): UiStrings = AppStrings.get(getLanguage())

    fun getRadiusKm(): Int = prefs.getInt(KEY_RADIUS_KM, 1).coerceIn(1, 5)

    fun getRadiusMeters(): Double = getRadiusKm() * 1000.0

    fun setRadiusKm(km: Int) {
        prefs.edit().putInt(KEY_RADIUS_KM, km.coerceIn(1, 5)).apply()
    }

    private fun otaCatalogFile(): File = File(context.filesDir, "catalog_ota.json")

    fun loadCatalog(): List<WallpaperItem> {
        cachedCatalog?.let { return it }
        return synchronized(catalogLock) {
            cachedCatalog?.let { return@synchronized it }
            val ota = otaCatalogFile()
            if (ota.exists() && ota.length() > 100) {
                try {
                    val parsed = WallpaperItem.parseJson(ota.readText(Charsets.UTF_8))
                    if (parsed.isNotEmpty()) {
                        cachedCatalog = parsed
                        return@synchronized parsed
                    }
                } catch (_: Exception) {
                    // Fallback to bundled asset
                }
            }
            val text = context.assets.open("catalog.json").bufferedReader().use { it.readText() }
            WallpaperItem.parseJson(text).also { cachedCatalog = it }
        }
    }

    fun syncCatalog(force: Boolean = false): Pair<Boolean, Int> {
        val now = System.currentTimeMillis()
        val lastSync = prefs.getLong(KEY_LAST_SYNC_TS, 0L)
        if (!force && (now - lastSync) < 12 * 3600 * 1000L) {
            return Pair(false, loadCatalog().size)
        }
        return try {
            val idxReq = Request.Builder()
                .url(REMOTE_COUNTRIES_URL)
                .header("User-Agent", "BarvyAndroid/43")
                .build()
            val countriesJson = client.newCall(idxReq).execute().use { resp ->
                if (!resp.isSuccessful) return Pair(false, loadCatalog().size)
                resp.body?.string() ?: return Pair(false, loadCatalog().size)
            }
            val cArr = org.json.JSONArray(countriesJson)
            val merged = mutableListOf<WallpaperItem>()
            for (i in 0 until cArr.length()) {
                val cObj = cArr.getJSONObject(i)
                val catUrl = cObj.optString("catalogUrl", "")
                if (catUrl.isBlank()) continue
                val catReq = Request.Builder()
                    .url(catUrl)
                    .header("User-Agent", "BarvyAndroid/43")
                    .build()
                client.newCall(catReq).execute().use { resp ->
                    if (resp.isSuccessful) {
                        val body = resp.body?.string()
                        if (!body.isNullOrBlank()) {
                            merged.addAll(WallpaperItem.parseJson(body))
                        }
                    }
                }
            }
            if (merged.isEmpty()) return Pair(false, loadCatalog().size)
            val outArr = org.json.JSONArray()
            merged.forEach { outArr.put(it.toJsonObject()) }
            otaCatalogFile().writeText(outArr.toString(), Charsets.UTF_8)
            synchronized(catalogLock) {
                cachedCatalog = merged
            }
            prefs.edit().putLong(KEY_LAST_SYNC_TS, now).apply()
            Pair(true, merged.size)
        } catch (_: Exception) {
            Pair(false, loadCatalog().size)
        }
    }

    fun getStatus(): AppStatus {
        val lang = getLanguage()
        val radiusKm = getRadiusKm()
        val s = AppStrings.get(lang)
        val cityUk = prefs.getString("last_applied_city_uk", "") ?: ""
        val cityEn = prefs.getString("last_applied_city_en", cityUk) ?: cityUk
        val descUk = prefs.getString("last_applied_desc_uk", "") ?: ""
        val descEn = prefs.getString("last_applied_desc_en", descUk) ?: descUk

        val localizedAppliedCity = if (lang != AppLang.UK && lang != AppLang.RU) cityEn else cityUk
        val localizedAppliedDesc = if (lang != AppLang.UK && lang != AppLang.RU) descEn else descUk

        val msgTypeName = prefs.getString(KEY_MSG_TYPE, StatusMsgType.INITIAL.name)
        val msgType = try {
            StatusMsgType.valueOf(msgTypeName ?: StatusMsgType.INITIAL.name)
        } catch (_: Exception) {
            StatusMsgType.INITIAL
        }

        val msgCityUk = prefs.getString("last_msg_city_uk", "") ?: ""
        val msgCityEn = prefs.getString("last_msg_city_en", msgCityUk) ?: msgCityUk
        val localizedMsgCity = if (lang != AppLang.UK && lang != AppLang.RU) msgCityEn else msgCityUk
        val msgDistM = prefs.getInt("last_msg_dist_m", 0)
        val msgKm = prefs.getString("last_msg_km", "0.0") ?: "0.0"
        val msgFilename = prefs.getString("last_msg_filename", "") ?: ""

        val formattedMsg = when (msgType) {
            StatusMsgType.INITIAL -> s.initialPrompt
            StatusMsgType.CACHE_CLEARED -> s.cacheClearedNote
            StatusMsgType.NO_PERM -> s.noLocationPermission
            StatusMsgType.NEED_PERM -> s.needLocationPermission
            StatusMsgType.GPS_FAILED -> s.gpsFailed
            StatusMsgType.NONE_IN_RADIUS -> s.noneInRadius(radiusKm)
            StatusMsgType.NONE_IN_RADIUS_NEAREST -> s.noneInRadiusWithNearest(radiusKm, localizedMsgCity, msgKm)
            StatusMsgType.UP_TO_DATE -> s.alreadyUpToDate(localizedMsgCity, msgDistM)
            StatusMsgType.DOWNLOAD_FAILED -> s.downloadFailed(msgFilename)
            StatusMsgType.APPLIED -> s.wallpaperApplied(localizedMsgCity, msgFilename)
        }

        val checkedTs = prefs.getLong("last_checked_ts", 0L)
        val checkedStr = if (checkedTs > 0L) {
            SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()).format(Date(checkedTs))
        } else {
            prefs.getString("last_checked_time", null) ?: s.notCheckedYet
        }

        return AppStatus(
            autoEnabled = prefs.getBoolean("auto_enabled", false),
            drivingModeEnabled = prefs.getBoolean(KEY_DRIVING_MODE, false),
            radiusKm = radiusKm,
            language = lang,
            theme = getTheme(),
            lastAppliedId = prefs.getInt("last_applied_id", -1),
            lastAppliedCity = localizedAppliedCity,
            lastAppliedDesc = localizedAppliedDesc,
            lastAppliedFileId = prefs.getString("last_applied_file_id", "") ?: "",
            lastDistanceMeters = prefs.getInt("last_distance_m", -1),
            lastCheckedTime = checkedStr,
            lastMessage = formattedMsg
        )
    }

    fun setAutoEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("auto_enabled", enabled).apply()
    }

    fun setDrivingModeEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_DRIVING_MODE, enabled).apply()
    }

    fun recordStatus(
        type: StatusMsgType,
        item: WallpaperItem? = null,
        distanceMeters: Int = 0,
        kmText: String = "",
        filename: String = ""
    ) {
        val now = System.currentTimeMillis()
        val editor = prefs.edit()
            .putLong("last_checked_ts", now)
            .putString("last_checked_time", SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()).format(Date(now)))
            .putString(KEY_MSG_TYPE, type.name)
            .putInt("last_msg_dist_m", distanceMeters)
            .putString("last_msg_km", kmText)
            .putString("last_msg_filename", filename.ifEmpty { item?.filename ?: "" })
        if (item != null) {
            editor.putString("last_msg_city_uk", item.city)
            editor.putString("last_msg_city_en", item.cityEn)
        }
        editor.apply()
    }

    fun getCachedFile(fileId: String): File {
        val dir = File(context.filesDir, "wallpapers").apply { if (!exists()) mkdirs() }
        return File(dir, "$fileId.jpg")
    }

    fun downloadIfNeeded(item: WallpaperItem): File? {
        val cacheKey = item.fileId.ifBlank { "item_${item.id}" }
        val target = getCachedFile(cacheKey)
        if (target.exists() && target.length() > 10_000) {
            return target
        }

        val urls = item.downloadUrls()
        for (url in urls) {
            try {
                val request = Request.Builder()
                    .url(url)
                    .header("User-Agent", "BarvyAndroid/30")
                    .build()
                client.newCall(request).execute().use { resp ->
                    val contentType = resp.header("Content-Type") ?: ""
                    if (resp.isSuccessful && contentType.startsWith("image")) {
                        val bytes = resp.body?.bytes()
                        if (bytes != null && bytes.size > 10_000) {
                            target.writeBytes(bytes)
                            return target
                        }
                    }
                }
            } catch (_: Exception) {
                // Try fallback URL
            }
        }
        return null
    }

    fun applyLockScreenWallpaper(item: WallpaperItem, distanceMeters: Int = 0): Boolean {
        val file = downloadIfNeeded(item) ?: return false
        val bitmap: Bitmap = BitmapFactory.decodeFile(file.absolutePath) ?: return false

        val wm = WallpaperManager.getInstance(context)
        wm.setBitmap(bitmap, null, true, WallpaperManager.FLAG_LOCK)
        bitmap.recycle()

        val now = System.currentTimeMillis()
        prefs.edit()
            .putInt("last_applied_id", item.id)
            .putString("last_applied_city_uk", item.city)
            .putString("last_applied_city_en", item.cityEn)
            .putString("last_applied_desc_uk", item.description)
            .putString("last_applied_desc_en", item.descriptionEn)
            .putString("last_applied_file_id", item.fileId)
            .putInt("last_distance_m", distanceMeters)
            .putLong("last_checked_ts", now)
            .putString("last_checked_time", SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()).format(Date(now)))
            .putString(KEY_MSG_TYPE, StatusMsgType.APPLIED.name)
            .putString("last_msg_city_uk", item.city)
            .putString("last_msg_city_en", item.cityEn)
            .putString("last_msg_filename", item.filename)
            .apply()
        return true
    }

    companion object {
        private val catalogLock = Any()
        @Volatile
        private var cachedCatalog: List<WallpaperItem>? = null

        const val CURRENT_CATALOG_VERSION = 30
        private const val KEY_CATALOG_VERSION = "catalog_version"
        private const val KEY_LANGUAGE = "app_language"
        private const val KEY_DRIVING_MODE = "driving_mode_enabled"
        private const val KEY_MSG_TYPE = "last_msg_type"
        private const val KEY_RADIUS_KM = "radius_km"
        private const val KEY_THEME = "app_theme"
        private const val KEY_LAST_SYNC_TS = "last_ota_sync_ts"
        private const val REMOTE_COUNTRIES_URL = "https://raw.githubusercontent.com/mizgiroff/barvy-data/main/countries.json"
        private const val REMOTE_VIP_URL = "https://raw.githubusercontent.com/mizgiroff/barvy-data/main/vip_codes.json"
        private const val KEY_DEVICE_ID = "barvy_device_id"
        private const val KEY_ACCESS_TIER = "barvy_access_tier"
        private const val KEY_LOCKED_FREE_REGION = "barvy_locked_free_region"
        private const val KEY_LOCKED_COUNTRIES = "barvy_locked_countries"
        private const val KEY_ACTIVE_VIP_CODE = "barvy_active_vip_code"
    }
}
