# ProGuard rules for Barvy
