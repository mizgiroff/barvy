package com.barvy.wallpaper

import android.Manifest
import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingRequest
import com.google.android.gms.location.LocationServices

object GeofenceManager {
    private const val MAX_GEOFENCES = 95

    private fun getGeofencePendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, GeofenceReceiver::class.java)
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }
        return PendingIntent.getBroadcast(context, 1001, intent, flags)
    }

    @SuppressLint("MissingPermission")
    fun registerNearestGeofences(context: Context, lat: Double? = null, lon: Double? = null) {
        val hasFine = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        if (!hasFine) return

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val hasBg = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.ACCESS_BACKGROUND_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
            if (!hasBg) return
        }

        val repo = WallpaperRepository(context)
        val catalog = repo.loadCatalog()
        if (catalog.isEmpty()) return

        val selected = if (lat != null && lon != null) {
            catalog.sortedBy { GeoMatcher.distanceMeters(lat, lon, it.lat, it.lon) }
                .take(MAX_GEOFENCES)
        } else {
            catalog.take(MAX_GEOFENCES)
        }

        val geofences = selected.map { item ->
            Geofence.Builder()
                .setRequestId("barvy_${item.id}")
                .setCircularRegion(item.lat, item.lon, GeoMatcher.DEFAULT_RADIUS_METERS.toFloat())
                .setExpirationDuration(Geofence.NEVER_EXPIRE)
                .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER or Geofence.GEOFENCE_TRANSITION_DWELL)
                .setLoiteringDelay(10_000)
                .build()
        }

        val request = GeofencingRequest.Builder()
            .setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER)
            .addGeofences(geofences)
            .build()

        val client = LocationServices.getGeofencingClient(context)
        val pi = getGeofencePendingIntent(context)
        client.removeGeofences(pi).addOnCompleteListener {
            client.addGeofences(request, pi)
        }
    }

    fun clearGeofences(context: Context) {
        val client = LocationServices.getGeofencingClient(context)
        client.removeGeofences(getGeofencePendingIntent(context))
    }
}
