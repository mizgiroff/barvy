package com.barvy.wallpaper

import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

data class GeoMatch(
    val item: WallpaperItem,
    val distanceMeters: Double
)

object GeoMatcher {
    const val DEFAULT_RADIUS_METERS = 1000.0
    private const val EARTH_RADIUS_METERS = 6_371_000.0

    fun distanceMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val rLat1 = Math.toRadians(lat1)
        val rLat2 = Math.toRadians(lat2)

        val a = sin(dLat / 2).pow(2) +
            cos(rLat1) * cos(rLat2) * sin(dLon / 2).pow(2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return EARTH_RADIUS_METERS * c
    }

    fun findNearestWithinRadius(
        lat: Double,
        lon: Double,
        catalog: List<WallpaperItem>,
        radiusMeters: Double = DEFAULT_RADIUS_METERS,
        lastAppliedId: Int? = null
    ): GeoMatch? {
        val withinRadius = catalog
            .map { item -> GeoMatch(item, distanceMeters(lat, lon, item.lat, item.lon)) }
            .filter { it.distanceMeters <= radiusMeters }
            .sortedBy { it.distanceMeters }

        if (withinRadius.isEmpty()) return null

        val minDistance = withinRadius.first().distanceMeters
        val coLocated = withinRadius.filter { it.distanceMeters - minDistance < 15.0 }
        if (coLocated.size > 1 && lastAppliedId != null) {
            val alternative = coLocated.firstOrNull { it.item.id != lastAppliedId }
            if (alternative != null) return alternative
        }
        return withinRadius.first()
    }

    fun findNearestAny(lat: Double, lon: Double, catalog: List<WallpaperItem>): GeoMatch? {
        return catalog
            .map { item -> GeoMatch(item, distanceMeters(lat, lon, item.lat, item.lon)) }
            .minByOrNull { it.distanceMeters }
    }
}
