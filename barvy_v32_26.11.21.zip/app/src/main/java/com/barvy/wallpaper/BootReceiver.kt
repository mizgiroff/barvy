package com.barvy.wallpaper

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action == Intent.ACTION_BOOT_COMPLETED || action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            val repo = WallpaperRepository(context)
            val status = repo.getStatus()
            if (status.autoEnabled) {
                WallpaperWorker.schedulePeriodic(context)
                GeofenceManager.registerNearestGeofences(context)
            }
            if (status.drivingModeEnabled) {
                DrivingLocationService.start(context)
            }
        }
    }
}
