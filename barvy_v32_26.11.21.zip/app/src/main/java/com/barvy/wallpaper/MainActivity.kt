package com.barvy.wallpaper

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.BaselineShift
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.roundToInt

private val UkraineBlue = Color(0xFF0057B7)
private val UkraineGold = Color(0xFFFFD700)
private val OkGreen = Color(0xFF1B7F3A)
private val WarnAmber = Color(0xFFB45309)
private const val ALL_KEY = "__ALL__"

data class OblastOption(
    val key: String,
    val nameUk: String,
    val nameEn: String,
    val count: Int
) {
    fun nameFor(lang: AppLang): String = if (lang == AppLang.EN) nameEn else nameUk
}

data class PermissionSnapshot(
    val hasFgLocation: Boolean,
    val hasBgLocation: Boolean,
    val ignoringBattery: Boolean,
    val hasNotifications: Boolean
)

fun checkPermissions(context: Context): PermissionSnapshot {
    val fg = ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.ACCESS_FINE_LOCATION
    ) == PackageManager.PERMISSION_GRANTED
    val bg = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_BACKGROUND_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
    } else true
    val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
    val battery = pm?.isIgnoringBatteryOptimizations(context.packageName) ?: true
    val notif = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
    } else true
    return PermissionSnapshot(fg, bg, battery, notif)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val repo = WallpaperRepository(applicationContext)
        val initialStatus = repo.getStatus()
        if (initialStatus.autoEnabled) {
            WallpaperWorker.schedulePeriodic(applicationContext)
            GeofenceManager.registerNearestGeofences(applicationContext)
        }
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = UkraineBlue,
                    secondary = UkraineGold,
                    background = Color(0xFFF6F8FB)
                )
            ) {
                BarvyScreen(repo)
            }
        }
    }
}

@Composable
fun BarvyScreen(repo: WallpaperRepository) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    val catalog = remember { repo.loadCatalog() }

    var status by remember { mutableStateOf(repo.getStatus()) }
    val s = remember(status.language) { AppStrings.get(status.language) }

    val oblastOptions = remember(catalog) {
        catalog.groupBy { it.oblast }.map { (oblUk, list) ->
            OblastOption(
                key = oblUk,
                nameUk = oblUk,
                nameEn = list.first().oblastEn,
                count = list.size
            )
        }.sortedByDescending { it.count }
    }

    var selectedOblastKey by remember { mutableStateOf(ALL_KEY) }
    var selectedCityKey by remember { mutableStateOf(ALL_KEY) }
    var oblastMenuExpanded by remember { mutableStateOf(false) }

    var busyItemId by remember { mutableStateOf<Int?>(null) }
    var isCheckingLocation by remember { mutableStateOf(false) }
    var permSnap by remember { mutableStateOf(checkPermissions(context)) }
    var showGuide by remember {
        mutableStateOf(!permSnap.hasBgLocation || !permSnap.ignoringBattery)
    }
    var showVersionDialog by remember { mutableStateOf(false) }

    val shimmerAnim = remember { Animatable(0f) }
    var shimmerActive by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(3000)
            shimmerAnim.snapTo(0f)
            shimmerActive = true
            shimmerAnim.animateTo(1f, animationSpec = tween(durationMillis = 1400))
            shimmerActive = false
            delay(25600)
        }
    }

    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                permSnap = checkPermissions(context)
                status = repo.getStatus()
            }
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    val notifPermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ ->
        permSnap = checkPermissions(context)
        repo.setDrivingModeEnabled(true)
        DrivingLocationService.start(context)
        status = repo.getStatus()
    }

    val bgPermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ ->
        permSnap = checkPermissions(context)
        repo.setAutoEnabled(true)
        WallpaperWorker.schedulePeriodic(context)
        GeofenceManager.registerNearestGeofences(context)
        status = repo.getStatus()
    }

    val fgPermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        permSnap = checkPermissions(context)
        val granted = perms[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            perms[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (granted) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && !permSnap.hasBgLocation) {
                bgPermLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
                return@rememberLauncherForActivityResult
            }
            repo.setAutoEnabled(true)
            WallpaperWorker.schedulePeriodic(context)
            GeofenceManager.registerNearestGeofences(context)
            status = repo.getStatus()
        } else {
            repo.recordStatus(StatusMsgType.NEED_PERM)
            status = repo.getStatus()
        }
    }

    val regionFiltered = remember(catalog, selectedOblastKey) {
        if (selectedOblastKey == ALL_KEY) catalog
        else catalog.filter { it.oblast == selectedOblastKey }
    }

    val cityOptions = remember(regionFiltered, status.language) {
        regionFiltered
            .distinctBy { it.city }
            .map { it.city to it.cityFor(status.language) }
    }

    val filteredItems = remember(regionFiltered, selectedCityKey) {
        if (selectedCityKey == ALL_KEY) regionFiltered
        else regionFiltered.filter { it.city == selectedCityKey }
    }

    val selectedOblastLabel = remember(selectedOblastKey, oblastOptions, status.language, s) {
        if (selectedOblastKey == ALL_KEY) {
            "${s.allRegions} (${catalog.size})"
        } else {
            val found = oblastOptions.firstOrNull { it.key == selectedOblastKey }
            if (found != null) "${found.nameFor(status.language)} (${found.count})" else s.allRegions
        }
    }

    if (showVersionDialog) {
        AlertDialog(
            onDismissRequest = { showVersionDialog = false },
            title = { Text(s.versionDialogTitle) },
            text = { Text(s.versionDialogBody) },
            confirmButton = {
                TextButton(onClick = { showVersionDialog = false }) {
                    Text(s.okButton)
                }
            }
        )
    }

    Scaffold { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen)
                            .drawWithContent {
                                drawContent()
                                if (shimmerActive) {
                                    val w = size.width
                                    val x = shimmerAnim.value * (w + 160f) - 80f
                                    drawRect(
                                        brush = Brush.linearGradient(
                                            colors = listOf(
                                                Color.Transparent,
                                                Color(0xFF0057B7).copy(alpha = 0.85f),
                                                Color(0xFFFFDD00).copy(alpha = 0.9f),
                                                Color.Transparent
                                            ),
                                            start = Offset(x - 70f, 0f),
                                            end = Offset(x + 70f, size.height)
                                        ),
                                        blendMode = BlendMode.SrcAtop
                                    )
                                }
                            },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(14.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(UkraineBlue)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Box(
                            modifier = Modifier
                                .size(14.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(UkraineGold)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Barvy",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = buildAnnotatedString {
                                withStyle(
                                    SpanStyle(
                                        fontSize = 10.sp,
                                        baselineShift = BaselineShift.Superscript,
                                        color = UkraineBlue
                                    )
                                ) { append("v.32 by mizgiroff") }
                            },
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.clickable { showVersionDialog = true }
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(
                            selected = status.language == AppLang.UK,
                            onClick = {
                                repo.setLanguage(AppLang.UK)
                                status = repo.getStatus()
                            },
                            label = { Text("UA", maxLines = 1, softWrap = false) }
                        )
                        FilterChip(
                            selected = status.language == AppLang.EN,
                            onClick = {
                                repo.setLanguage(AppLang.EN)
                                status = repo.getStatus()
                            },
                            label = { Text("EN", maxLines = 1, softWrap = false) }
                        )
                    }
                }
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = s.autoSwitchTitle,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = s.autoSwitchSubtitle,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.Gray
                                )
                            }
                            Switch(
                                checked = status.autoEnabled,
                                onCheckedChange = { enable ->
                                    if (enable) {
                                        fgPermLauncher.launch(
                                            arrayOf(
                                                Manifest.permission.ACCESS_FINE_LOCATION,
                                                Manifest.permission.ACCESS_COARSE_LOCATION
                                            )
                                        )
                                    } else {
                                        repo.setAutoEnabled(false)
                                        WallpaperWorker.cancelPeriodic(context)
                                        GeofenceManager.clearGeofences(context)
                                        status = repo.getStatus()
                                    }
                                }
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = s.drivingModeTitle,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = s.drivingModeSubtitle,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.Gray
                                )
                            }
                            Switch(
                                checked = status.drivingModeEnabled,
                                onCheckedChange = { enable ->
                                    if (enable) {
                                        if (!permSnap.hasFgLocation) {
                                            fgPermLauncher.launch(
                                                arrayOf(
                                                    Manifest.permission.ACCESS_FINE_LOCATION,
                                                    Manifest.permission.ACCESS_COARSE_LOCATION
                                                )
                                            )
                                        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !permSnap.hasNotifications) {
                                            notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                        } else {
                                            repo.setDrivingModeEnabled(true)
                                            DrivingLocationService.start(context)
                                            status = repo.getStatus()
                                        }
                                    } else {
                                        repo.setDrivingModeEnabled(false)
                                        DrivingLocationService.stop(context)
                                        status = repo.getStatus()
                                    }
                                }
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = status.lastMessage,
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            text = "${s.lastCheckPrefix}: ${status.lastCheckedTime}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray
                        )

                        if (status.lastAppliedFileId.isNotEmpty()) {
                            val cachedFile = repo.getCachedFile(status.lastAppliedFileId)
                            if (cachedFile.exists()) {
                                val bmp = remember(status.lastAppliedFileId) {
                                    BitmapFactory.decodeFile(cachedFile.absolutePath)
                                }
                                if (bmp != null) {
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Image(
                                        bitmap = bmp.asImageBitmap(),
                                        contentDescription = status.lastAppliedDesc,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(180.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = {
                                if (isCheckingLocation) return@Button
                                if (!permSnap.hasFgLocation) {
                                    fgPermLauncher.launch(
                                        arrayOf(
                                            Manifest.permission.ACCESS_FINE_LOCATION,
                                            Manifest.permission.ACCESS_COARSE_LOCATION
                                        )
                                    )
                                    return@Button
                                }
                                isCheckingLocation = true
                                scope.launch {
                                    withContext(Dispatchers.IO) {
                                        val loc = WallpaperWorker.getBestLocation(context)
                                        if (loc == null) {
                                            repo.recordStatus(StatusMsgType.GPS_FAILED)
                                        } else {
                                            GeofenceManager.registerNearestGeofences(
                                                context,
                                                loc.latitude,
                                                loc.longitude
                                            )
                                            val match = GeoMatcher.findNearestWithinRadius(
                                                lat = loc.latitude,
                                                lon = loc.longitude,
                                                catalog = catalog,
                                                radiusMeters = GeoMatcher.DEFAULT_RADIUS_METERS,
                                                lastAppliedId = status.lastAppliedId.takeIf { it > 0 }
                                            )
                                            if (match == null) {
                                                val nearest = GeoMatcher.findNearestAny(loc.latitude, loc.longitude, catalog)
                                                if (nearest != null) {
                                                    val km = String.format(Locale.US, "%.1f", nearest.distanceMeters / 1000.0)
                                                    repo.recordStatus(StatusMsgType.NONE_IN_RADIUS_NEAREST, item = nearest.item, kmText = km)
                                                } else {
                                                    repo.recordStatus(StatusMsgType.NONE_IN_RADIUS)
                                                }
                                            } else {
                                                val ok = repo.applyLockScreenWallpaper(
                                                    match.item,
                                                    match.distanceMeters.roundToInt()
                                                )
                                                if (!ok) {
                                                    repo.recordStatus(StatusMsgType.DOWNLOAD_FAILED, item = match.item)
                                                }
                                            }
                                        }
                                    }
                                    status = repo.getStatus()
                                    isCheckingLocation = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = UkraineBlue),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            if (isCheckingLocation) {
                                CircularProgressIndicator(
                                    color = Color.White,
                                    modifier = Modifier.size(18.dp),
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                            }
                            Text(s.checkNowButton)
                        }

                        TextButton(
                            onClick = { showGuide = !showGuide },
                            modifier = Modifier.align(Alignment.End)
                        ) {
                            Text(if (showGuide) s.hideGuide else s.showGuide)
                        }
                    }
                }
            }

            if (showGuide) {
                item {
                    PermissionsGuideCard(
                        s = s,
                        permSnap = permSnap,
                        onOpenSettings = {
                            val intent = Intent(
                                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.fromParts("package", context.packageName, null)
                            )
                            context.startActivity(intent)
                        },
                        onRequestBatteryIgnore = {
                            val intent = Intent(
                                Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                                Uri.parse("package:${context.packageName}")
                            )
                            context.startActivity(intent)
                        }
                    )
                }
            }

            item {
                Text(
                    text = s.catalogHeader(filteredItems.size, catalog.size),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(
                        onClick = { oblastMenuExpanded = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${s.regionLabel}: $selectedOblastLabel",
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = null
                            )
                        }
                    }
                    DropdownMenu(
                        expanded = oblastMenuExpanded,
                        onDismissRequest = { oblastMenuExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("${s.allRegions} (${catalog.size})") },
                            onClick = {
                                selectedOblastKey = ALL_KEY
                                selectedCityKey = ALL_KEY
                                oblastMenuExpanded = false
                            }
                        )
                        oblastOptions.forEach { option ->
                            DropdownMenuItem(
                                text = { Text("${option.nameFor(status.language)} (${option.count})") },
                                onClick = {
                                    selectedOblastKey = option.key
                                    selectedCityKey = ALL_KEY
                                    oblastMenuExpanded = false
                                }
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = selectedCityKey == ALL_KEY,
                        onClick = { selectedCityKey = ALL_KEY },
                        label = { Text(s.filterAll) }
                    )
                    cityOptions.forEach { (cityKey, cityLabel) ->
                        FilterChip(
                            selected = selectedCityKey == cityKey,
                            onClick = { selectedCityKey = cityKey },
                            label = { Text(cityLabel) }
                        )
                    }
                }
            }

            items(filteredItems, key = { it.id }) { item ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "${item.cityFor(status.language)} • ${item.oblastFor(status.language)} • №${item.id}",
                            style = MaterialTheme.typography.labelLarge,
                            color = UkraineBlue,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = item.descriptionFor(status.language),
                            style = MaterialTheme.typography.bodyMedium,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "GPS: ${item.lat}, ${item.lon}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = {
                                if (busyItemId != null) return@OutlinedButton
                                busyItemId = item.id
                                scope.launch {
                                    val ok = withContext(Dispatchers.IO) {
                                        repo.applyLockScreenWallpaper(item, 0)
                                    }
                                    if (!ok) {
                                        repo.recordStatus(StatusMsgType.DOWNLOAD_FAILED, item = item)
                                    }
                                    status = repo.getStatus()
                                    busyItemId = null
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            if (busyItemId == item.id) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                            }
                            Text(s.setLockScreenButton)
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(16.dp)) }
        }
    }
}

@Composable
private fun PermissionsGuideCard(
    s: UiStrings,
    permSnap: PermissionSnapshot,
    onOpenSettings: () -> Unit,
    onRequestBatteryIgnore: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFBEB)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = s.permissionsCardTitle,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = UkraineBlue
            )
            Text(
                text = s.permissionsCardSubtitle,
                style = MaterialTheme.typography.bodySmall,
                color = Color.DarkGray
            )
            PermRow(s.permGeoFgTitle, s.permGeoFgDesc, permSnap.hasFgLocation, s.statusGranted, s.statusNeeded)
            PermRow(s.permGeoBgTitle, s.permGeoBgDesc, permSnap.hasBgLocation, s.statusGranted, s.statusNeeded)
            PermRow(s.permBatteryTitle, s.permBatteryDesc, permSnap.ignoringBattery, s.statusGranted, s.statusNeeded)
            PermRow(s.permNotifTitle, s.permNotifDesc, permSnap.hasNotifications, s.statusGranted, s.statusNeeded)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onOpenSettings,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(s.openAppSettingsButton, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                if (!permSnap.ignoringBattery) {
                    Button(
                        onClick = onRequestBatteryIgnore,
                        colors = ButtonDefaults.buttonColors(containerColor = UkraineBlue),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(s.requestBatteryIgnoreButton, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }
}

@Composable
private fun PermRow(
    title: String,
    desc: String,
    granted: Boolean,
    okLabel: String,
    needLabel: String
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f)
            )
            Text(
                text = if (granted) "✓ $okLabel" else "! $needLabel",
                style = MaterialTheme.typography.labelMedium,
                color = if (granted) OkGreen else WarnAmber,
                fontWeight = FontWeight.Bold
            )
        }
        Text(
            text = desc,
            style = MaterialTheme.typography.bodySmall,
            color = Color(0xFF374151)
        )
    }
}
