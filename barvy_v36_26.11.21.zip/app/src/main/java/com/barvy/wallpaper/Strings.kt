package com.barvy.wallpaper

import java.util.Locale

enum class AppTheme(val code: String) {
    SYSTEM("system"),
    LIGHT("light"),
    DARK("dark");

    companion object {
        fun fromCode(code: String?): AppTheme = when (code) {
            "light" -> LIGHT
            "dark" -> DARK
            else -> SYSTEM
        }
    }
}

enum class AppLang(val code: String) {
    UK("uk"),
    EN("en");

    companion object {
        fun fromCode(code: String?): AppLang {
            return if (code == "en") EN else UK
        }

        fun defaultForSystem(): AppLang {
            val sys = Locale.getDefault().language
            return if (sys == "en") EN else UK
        }
    }
}

data class UiStrings(
    val headerTitle: String,
    val autoSwitchTitle: (Int) -> String,
    val radiusLabel: String,
    val radiusKmChip: (Int) -> String,
    val autoSwitchSubtitle: String,
    val drivingModeTitle: String,
    val drivingModeSubtitle: String,
    val lastCheckPrefix: String,
    val checkNowButton: String,
    val catalogHeader: (Int, Int) -> String,
    val regionLabel: String,
    val allRegions: String,
    val freeBadge: String,
    val filterAll: String,
    val setLockScreenButton: String,
    val notCheckedYet: String,
    val initialPrompt: String,
    val noLocationPermission: String,
    val needLocationPermission: String,
    val gpsFailed: String,
    val noneInRadiusWithNearest: (Int, String, String) -> String,
    val noneInRadius: (Int) -> String,
    val alreadyUpToDate: (String, Int) -> String,
    val downloadFailed: (String) -> String,
    val wallpaperApplied: (String, String) -> String,
    val cacheClearedNote: String,
    val permissionsCardTitle: String,
    val permissionsCardSubtitle: String,
    val permGeoFgTitle: String,
    val permGeoFgDesc: String,
    val permGeoBgTitle: String,
    val permGeoBgDesc: String,
    val permBatteryTitle: String,
    val permBatteryDesc: String,
    val permNotifTitle: String,
    val permNotifDesc: String,
    val statusGranted: String,
    val statusNeeded: String,
    val openAppSettingsButton: String,
    val requestBatteryIgnoreButton: String,
    val drivingNotifChannel: String,
    val drivingNotifTitle: String,
    val drivingNotifText: String,
    val hideGuide: String,
    val showGuide: String,
    val versionDialogTitle: String,
    val versionDialogBody: String,
    val okButton: String,
    val settingsTitle: String,
    val settingsLanguageLabel: String,
    val settingsThemeLabel: String,
    val themeSystem: String,
    val themeLight: String,
    val themeDark: String,
    val chooseLangTitle: String
)

object AppStrings {
    fun get(lang: AppLang): UiStrings = when (lang) {
        AppLang.UK -> UiStrings(
            headerTitle = "Barvy • Україна",
            autoSwitchTitle = { km -> "Автозміна (радіус $km км)" },
            radiusLabel = "Радіус:",
            radiusKmChip = { km -> "$km км" },
            autoSwitchSubtitle = "Лише екран блокування • v36_26.11.21",
            drivingModeTitle = "Режим поїздки (GPS у дорозі)",
            drivingModeSubtitle = "Постійний точний GPS для миттєвої зміни в авто",
            lastCheckPrefix = "Остання перевірка",
            checkNowButton = "Перевірити геолокацію зараз",
            catalogHeader = { shown, total -> "Каталог ($shown із $total)" },
            regionLabel = "Область",
            allRegions = "Усі області",
            freeBadge = "Безкоштовно",
            filterAll = "Усі міста",
            setLockScreenButton = "Поставити на екран блокування",
            notCheckedYet = "Ще не перевірялось",
            initialPrompt = "Натисніть «Перевірити геолокацію зараз» або увімкніть автозміну",
            noLocationPermission = "Немає дозволу на геолокацію",
            needLocationPermission = "Для автозміни потрібен дозвіл на геолокацію",
            gpsFailed = "Не вдалося отримати GPS-координати",
            noneInRadiusWithNearest = { r, city, km -> "У радіусі $r км об'єктів немає. Найближчий: $city ($km км)" },
            noneInRadius = { r -> "У радіусі $r км об'єктів не знайдено" },
            alreadyUpToDate = { city, m -> "Ви поруч із «$city» ($m м) — заставка актуальна" },
            downloadFailed = { name -> "Помилка завантаження фото: $name. Перевірте інтернет." },
            wallpaperApplied = { city, fname -> "Встановлено на екран блокування: $city ($fname)" },
            cacheClearedNote = "Оновлено каталог v30: додано Львівську та Закарпатську області.",
            permissionsCardTitle = "Налаштування дозволів і фонової роботи",
            permissionsCardSubtitle = "Чому це потрібно для автозміни без відкриття програми",
            permGeoFgTitle = "1. Точна геолокація",
            permGeoFgDesc = "Дозволяє визначати, біля якої пам'ятки ви зараз перебуваєте (радіус 1 км).",
            permGeoBgTitle = "2. Геолокація у фоні («Дозволити завжди»)",
            permGeoBgDesc = "Найважливіший дозвіл! Без «Дозволити завжди» Android блокує геозони та перевірки, коли екран вимкнено або програма згорнута. Відкрийте Налаштування → Дозволи → Геолокація → Дозволити завжди.",
            permBatteryTitle = "3. Батарея («Без обмежень»)",
            permBatteryDesc = "Забороняє системі присипляти Barvy у дорозі. Налаштування → Батарея → Без обмежень.",
            permNotifTitle = "4. Сповіщення (Android 13+)",
            permNotifDesc = "Потрібні для тихого індикатора «Режиму поїздки» під час руху на авто.",
            statusGranted = "Надано",
            statusNeeded = "Потрібно",
            openAppSettingsButton = "Налаштування програми",
            requestBatteryIgnoreButton = "Вимкнути економію батареї",
            drivingNotifChannel = "Режим поїздки Barvy",
            drivingNotifTitle = "Barvy • Режим поїздки",
            drivingNotifText = "Відстеження пам'яток у радіусі 1 км",
            hideGuide = "Сховати підказку",
            showGuide = "Як налаштувати автозміну?",
            versionDialogTitle = "Barvy • Версія",
            versionDialogBody = "Повна версія: v36_26.11.21 (код 36)\nАвтор: mizgiroff\nКаталог: 601 пам'яток (Львівська та Закарпатська області)",
            okButton = "ОК",
            settingsTitle = "Налаштування",
            settingsLanguageLabel = "Мова",
            settingsThemeLabel = "Тема",
            themeSystem = "Системна",
            themeLight = "День",
            themeDark = "Ніч",
            chooseLangTitle = "Оберіть мову / Choose language"
        )

        AppLang.EN -> UiStrings(
            headerTitle = "Barvy • Ukraine",
            autoSwitchTitle = { km -> "Auto-switch ($km km radius)" },
            radiusLabel = "Radius:",
            radiusKmChip = { km -> "$km km" },
            autoSwitchSubtitle = "Lock screen only • v36_26.11.21",
            drivingModeTitle = "Driving Mode (Live GPS)",
            drivingModeSubtitle = "Continuous high-accuracy GPS for instant switching on the road",
            lastCheckPrefix = "Last check",
            checkNowButton = "Check location now",
            catalogHeader = { shown, total -> "Catalog ($shown of $total)" },
            regionLabel = "Region",
            allRegions = "All Oblasts",
            freeBadge = "Free",
            filterAll = "All cities",
            setLockScreenButton = "Set on lock screen",
            notCheckedYet = "Not checked yet",
            initialPrompt = "Tap \"Check location now\" or enable Auto-switch",
            noLocationPermission = "Location permission not granted",
            needLocationPermission = "Location permission is required for auto-switch",
            gpsFailed = "Failed to get GPS coordinates",
            noneInRadiusWithNearest = { r, city, km -> "No landmarks within $r km. Nearest: $city ($km km)" },
            noneInRadius = { r -> "No landmarks found within $r km" },
            alreadyUpToDate = { city, m -> "Near \"$city\" ($m m) — wallpaper is up to date" },
            downloadFailed = { name -> "Failed to download photo: $name. Check internet." },
            wallpaperApplied = { city, fname -> "Lock screen updated: $city ($fname)" },
            cacheClearedNote = "Catalog v30 updated: Lviv and Zakarpattia oblasts loaded.",
            permissionsCardTitle = "Permissions & Background Setup",
            permissionsCardSubtitle = "Why each setting is needed for hands-free wallpaper switching",
            permGeoFgTitle = "1. Precise Location",
            permGeoFgDesc = "Identifies which landmark is within 1 km of your current position.",
            permGeoBgTitle = "2. Background Location (\"Allow all the time\")",
            permGeoBgDesc = "Crucial! Without \"Allow all the time\", Android blocks geofences and background checks when the screen is off. Go to App Settings → Permissions → Location → Allow all the time.",
            permBatteryTitle = "3. Battery (\"Unrestricted\")",
            permBatteryDesc = "Prevents Android from putting Barvy to sleep while driving. Go to App Settings → Battery → Unrestricted.",
            permNotifTitle = "4. Notifications (Android 13+)",
            permNotifDesc = "Required to display the quiet \"Driving Mode\" status notification while on the road.",
            statusGranted = "Granted",
            statusNeeded = "Required",
            openAppSettingsButton = "Open App Settings",
            requestBatteryIgnoreButton = "Disable battery optimization",
            drivingNotifChannel = "Barvy Driving Mode",
            drivingNotifTitle = "Barvy • Driving Mode",
            drivingNotifText = "Tracking landmarks within 1 km",
            hideGuide = "Hide guide",
            showGuide = "How to set up auto-switch?",
            versionDialogTitle = "Barvy • Version",
            versionDialogBody = "Full version: v36_26.11.21 (code 36)\nAuthor: mizgiroff\nCatalog: 601 landmarks (Lviv & Zakarpattia Oblasts)",
            okButton = "OK",
            settingsTitle = "Settings",
            settingsLanguageLabel = "Language",
            settingsThemeLabel = "Theme",
            themeSystem = "System",
            themeLight = "Light",
            themeDark = "Dark",
            chooseLangTitle = "Choose language / Оберіть мову"
        )
    }
}
