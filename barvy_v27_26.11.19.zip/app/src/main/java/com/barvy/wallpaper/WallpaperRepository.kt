package com.barvy.wallpaper

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

data class AppStatus(
    val autoEnabled: Boolean,
    val drivingModeEnabled: Boolean,
    val language: AppLang,
    val lastAppliedId: Int,
    val lastAppliedCity: String,
    val lastAppliedDesc: String,
    val lastAppliedFileId: String,
    val lastDistanceMeters: Int,
    val lastCheckedTime: String,
    val lastMessage: String
)

class WallpaperRepository(private val context: Context) {

    private val prefs = context.getSharedPreferences("barvy_prefs", Context.MODE_PRIVATE)

    private val client = OkHttpClient.Builder()
        .followRedirects(true)
        .followSslRedirects(true)
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    init {
        clearOldCacheIfNeeded()
    }

    private fun clearOldCacheIfNeeded() {
        val savedVersion = prefs.getInt(KEY_CATALOG_VERSION, 0)
        if (savedVersion < CURRENT_CATALOG_VERSION) {
            val dir = File(context.filesDir, "wallpapers")
            if (dir.exists()) {
                dir.listFiles()?.forEach { it.delete() }
            }
            val s = AppStrings.get(getLanguage())
            prefs.edit()
                .putInt(KEY_CATALOG_VERSION, CURRENT_CATALOG_VERSION)
                .putInt("last_applied_id", -1)
                .putString("last_applied_file_id", "")
                .putString("last_message", s.cacheClearedNote)
                .apply()
        }
    }

    fun getLanguage(): AppLang {
        val saved = prefs.getString(KEY_LANGUAGE, null)
        return if (saved != null) AppLang.fromCode(saved) else AppLang.defaultForSystem()
    }

    fun setLanguage(lang: AppLang) {
        prefs.edit().putString(KEY_LANGUAGE, lang.code).apply()
    }

    fun strings(): UiStrings = AppStrings.get(getLanguage())

    fun loadCatalog(): List<WallpaperItem> {
        val text = context.assets.open("catalog_lviv.json").bufferedReader().use { it.readText() }
        return WallpaperItem.parseJson(text)
    }

    fun getStatus(): AppStatus {
        val lang = getLanguage()
        val s = AppStrings.get(lang)
        return AppStatus(
            autoEnabled = prefs.getBoolean("auto_enabled", false),
            drivingModeEnabled = prefs.getBoolean(KEY_DRIVING_MODE, false),
            language = lang,
            lastAppliedId = prefs.getInt("last_applied_id", -1),
            lastAppliedCity = prefs.getString("last_applied_city", "") ?: "",
            lastAppliedDesc = prefs.getString("last_applied_desc", "") ?: "",
            lastAppliedFileId = prefs.getString("last_applied_file_id", "") ?: "",
            lastDistanceMeters = prefs.getInt("last_distance_m", -1),
            lastCheckedTime = prefs.getString("last_checked_time", s.notCheckedYet) ?: s.notCheckedYet,
            lastMessage = prefs.getString("last_message", s.initialPrompt) ?: s.initialPrompt
        )
    }

    fun setAutoEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("auto_enabled", enabled).apply()
    }

    fun setDrivingModeEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_DRIVING_MODE, enabled).apply()
    }

    fun recordCheckMessage(message: String) {
        prefs.edit()
            .putString("last_checked_time", nowFormatted())
            .putString("last_message", message)
            .apply()
    }

    fun getCachedFile(fileId: String): File {
        val dir = File(context.filesDir, "wallpapers").apply { if (!exists()) mkdirs() }
        return File(dir, "$fileId.jpg")
    }

    fun downloadIfNeeded(item: WallpaperItem): File? {
        val target = getCachedFile(item.fileId)
        if (target.exists() && target.length() > 10_000) {
            return target
        }

        val urls = listOf(item.primaryDownloadUrl(), item.fallbackDownloadUrl())
        for (url in urls) {
            try {
                val request = Request.Builder()
                    .url(url)
                    .header("User-Agent", "BarvyAndroid/26")
                    .build()
                client.newCall(request).execute().use { resp ->
                    val contentType = resp.header("Content-Type") ?: ""
                    if (resp.isSuccessful && contentType.startsWith("image")) {
                        val bytes = resp.body?.bytes()
                        if (bytes != null && bytes.size > 10_000) {
                            target.writeBytes(bytes)
                            return target
                        }
                    }
                }
            } catch (_: Exception) {
                // Try fallback URL
            }
        }
        return null
    }

    fun applyLockScreenWallpaper(item: WallpaperItem, distanceMeters: Int = 0): Boolean {
        val file = downloadIfNeeded(item) ?: return false
        val bitmap: Bitmap = BitmapFactory.decodeFile(file.absolutePath) ?: return false

        val wm = WallpaperManager.getInstance(context)
        wm.setBitmap(bitmap, null, true, WallpaperManager.FLAG_LOCK)
        bitmap.recycle()

        val s = strings()
        prefs.edit()
            .putInt("last_applied_id", item.id)
            .putString("last_applied_city", item.city)
            .putString("last_applied_desc", item.description)
            .putString("last_applied_file_id", item.fileId)
            .putInt("last_distance_m", distanceMeters)
            .putString("last_checked_time", nowFormatted())
            .putString("last_message", s.wallpaperApplied(item.city, item.filename))
            .apply()
        return true
    }

    private fun nowFormatted(): String {
        return SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()).format(Date())
    }

    companion object {
        const val CURRENT_CATALOG_VERSION = 26
        private const val KEY_CATALOG_VERSION = "catalog_version"
        private const val KEY_LANGUAGE = "app_language"
        private const val KEY_DRIVING_MODE = "driving_mode_enabled"
    }
}
