package com.barvy.wallpaper

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class GeoMatcherTest {

    @Test
    fun distanceBetweenLvivOperaAndRynokIsWithinOneKm() {
        val dist = GeoMatcher.distanceMeters(49.8442, 24.0262, 49.8417, 24.0316)
        assertTrue("Expected ~470 m, got $dist", dist in 400.0..550.0)
    }

    @Test
    fun matchesNearestWithinOneKmAndIgnoresFarCity() {
        val opera = WallpaperItem(1, "Львов", "Оперный театр", "id1", "a.jpg", 49.8442, 24.0262)
        val drohobych = WallpaperItem(2, "Дрогобыч", "Ратуша", "id2", "b.jpg", 49.3500, 23.5050)
        val catalog = listOf(opera, drohobych)

        // User near Lviv Opera
        val matchNear = GeoMatcher.findNearestWithinRadius(49.8450, 24.0270, catalog)
        assertNotNull(matchNear)
        assertEquals(1, matchNear!!.item.id)

        // User far away (e.g. Kyiv)
        val matchFar = GeoMatcher.findNearestWithinRadius(50.4501, 30.5234, catalog)
        assertNull(matchFar)
    }

    @Test
    fun catalogAssetJsonIsValidAndHasLvivEntries() {
        val assetFile = File("src/main/assets/catalog_lviv.json")
        assertTrue("catalog_lviv.json must exist", assetFile.exists())
        val items = WallpaperItem.parseJson(assetFile.readText())
        assertTrue("Expected at least 90 Lviv & Oblast items", items.size >= 90)
        assertTrue(items.all { it.fileId.isNotBlank() && it.lat in 48.0..51.0 && it.lon in 22.0..26.0 })
    }
}
